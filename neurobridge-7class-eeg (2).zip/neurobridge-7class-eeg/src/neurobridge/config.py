"""Declarative configuration.

A session is fully described by one YAML file. That is what makes the work
reproducible in the sense a reviewer cares about: the artefact you attach to
the paper is not "our code", it is the exact configuration that produced the
numbers, and it is short enough to print in an appendix.

Two design choices worth defending:

* **Roles, not channel names.** ``channels: {role: alpha_posterior}`` resolves
  against whatever montage the connected device reports. The same file runs on
  a Unicorn and on a Muse, and the resolution -- including any substitution and
  its fidelity -- is written into the session manifest.

* **Fail at load, not at runtime.** Every reference is checked when the config
  is parsed: unknown stage types, impossible filter bands, windows too short
  for the requested frequency resolution. A misconfiguration should surface
  before a class of children is sitting in front of it, not thirty seconds in.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .core.montage import Montage
from .core.types import DeviceInfo
from .registry import available, build, get


class ConfigError(ValueError):
    """Raised with an actionable message when a config cannot be realised."""


DEFAULTS: dict[str, Any] = {
    "session": {"paradigm": "alpha", "privacy_tier": "derived",
                "participant": "SCH-0000", "mains": 60.0},
    "acquisition": {"source": {"type": "synthetic"}},
    "preprocess": {"l_freq": 1.0, "h_freq": 45.0, "notch": 60.0, "order": 4},
    "epoching": {"window": 1.0, "step": 0.25, "history": 8.0},
    "pipeline": {"transforms": [], "extractor": None, "decoder": None},
    "transport": {"host": "127.0.0.1", "port": 8765, "queue_size": 64},
    "education": {"grade_band": "9-12", "target_success": 0.75},
    "logging": {"dir": "sessions", "raw": False},
}


def _deep_merge(base: dict, override: dict) -> dict:
    out = dict(base)
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


@dataclass
class Config:
    """Parsed, validated session configuration."""

    raw: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.data = _deep_merge(DEFAULTS, self.raw)
        self._validate_static()

    # -- construction ------------------------------------------------------

    @classmethod
    def from_file(cls, path: str | Path) -> "Config":
        p = Path(path)
        text = p.read_text(encoding="utf-8")
        if p.suffix in (".yaml", ".yml"):
            try:
                import yaml
            except ImportError as exc:
                raise ConfigError(
                    "reading YAML configs needs PyYAML: pip install pyyaml, "
                    "or use a .json config instead"
                ) from exc
            data = yaml.safe_load(text)
        elif p.suffix == ".json":
            data = json.loads(text)
        else:
            raise ConfigError(f"unsupported config format {p.suffix!r}")
        if not isinstance(data, dict):
            raise ConfigError("config root must be a mapping")
        return cls(data)

    @classmethod
    def from_dict(cls, data: dict) -> "Config":
        return cls(data)

    def __getitem__(self, key: str) -> Any:
        return self.data[key]

    def get(self, path: str, default: Any = None) -> Any:
        """Dotted lookup: ``cfg.get('epoching.window')``."""
        node: Any = self.data
        for part in path.split("."):
            if not isinstance(node, dict) or part not in node:
                return default
            node = node[part]
        return node

    # -- validation --------------------------------------------------------

    def _validate_static(self) -> None:
        """Checks that do not need a connected device."""
        pre, ep = self.data["preprocess"], self.data["epoching"]

        if pre.get("l_freq") and pre.get("h_freq") and pre["l_freq"] >= pre["h_freq"]:
            raise ConfigError(
                f"preprocess.l_freq ({pre['l_freq']}) must be below h_freq "
                f"({pre['h_freq']})"
            )
        if ep["window"] <= 0 or ep["step"] <= 0:
            raise ConfigError("epoching.window and epoching.step must be positive")
        if ep.get("history", 0) < ep["window"]:
            raise ConfigError(
                f"epoching.history ({ep.get('history')}) must be at least the "
                f"window length ({ep['window']})"
            )
        if ep["step"] > ep["window"]:
            raise ConfigError(
                f"epoching.step ({ep['step']}) exceeds window ({ep['window']}), "
                f"which discards data between windows. Set step <= window."
            )

        mains = self.get("session.mains")
        if mains not in (50.0, 60.0, 50, 60, None):
            raise ConfigError(
                f"session.mains is {mains}; it must be 50 or 60 Hz. This is not "
                f"a detail -- the wrong value leaves line noise in every channel."
            )

        for kind, key in (("transform", "transforms"),):
            for spec in self.data["pipeline"].get(key) or []:
                self._check_type(kind, spec)
        for kind, key in (("extractor", "extractor"), ("decoder", "decoder")):
            spec = self.data["pipeline"].get(key)
            if spec:
                self._check_type(kind, spec)
        self._check_type("source", self.data["acquisition"]["source"])

        tier = self.get("session.privacy_tier")
        if tier not in ("derived", "features", "raw"):
            raise ConfigError(
                f"session.privacy_tier must be 'derived', 'features' or 'raw'; "
                f"got {tier!r}"
            )
        if tier == "raw" and not self.get("logging.raw"):
            raise ConfigError(
                "privacy_tier 'raw' streams raw EEG over the network. If that "
                "is intended, set logging.raw: true to acknowledge it explicitly."
            )

    @staticmethod
    def _check_type(kind: str, spec: dict) -> None:
        if not isinstance(spec, dict) or "type" not in spec:
            raise ConfigError(f"{kind} spec must be a mapping with a 'type': {spec!r}")
        try:
            get(kind, spec["type"])
        except KeyError:
            raise ConfigError(
                f"unknown {kind} type {spec['type']!r}. Available: "
                f"{available(kind)}"
            ) from None

    def validate_against_device(self, device: DeviceInfo) -> dict[str, Any]:
        """Device-dependent checks. Returns the montage resolution report."""
        ep = self.data["epoching"]
        nyq = device.sfreq / 2.0
        pre = self.data["preprocess"]
        if pre.get("h_freq") and pre["h_freq"] >= nyq:
            raise ConfigError(
                f"preprocess.h_freq ({pre['h_freq']} Hz) is at or above Nyquist "
                f"({nyq} Hz) for this device's {device.sfreq} Hz sampling rate"
            )
        if pre.get("notch") and pre["notch"] >= nyq:
            raise ConfigError(
                f"preprocess.notch ({pre['notch']} Hz) exceeds Nyquist ({nyq} Hz)"
            )

        # Frequency resolution vs the narrowest band requested.
        df = 1.0 / ep["window"]
        extractor = self.data["pipeline"].get("extractor") or {}
        bands = extractor.get("bands")
        if bands:
            for name, (lo, hi) in bands.items():
                if (hi - lo) < 2 * df:
                    raise ConfigError(
                        f"band {name!r} is {hi - lo:.1f} Hz wide but a "
                        f"{ep['window']} s window gives only {df:.2f} Hz "
                        f"resolution. Lengthen the window to at least "
                        f"{2 / (hi - lo):.2f} s."
                    )

        montage = Montage(device.ch_names)
        roles = self._requested_roles()
        report = montage.report(roles) if roles else {}
        for role, info in report.items():
            if info["fidelity"] == 0.0:
                raise ConfigError(
                    f"this config needs the {role!r} role, but {device.name} "
                    f"has no usable electrode for it (channels: "
                    f"{list(device.ch_names)})"
                )
        return report

    def _requested_roles(self) -> list[str]:
        roles: list[str] = []

        def scan(node: Any) -> None:
            if isinstance(node, dict):
                if "role" in node and isinstance(node["role"], str):
                    roles.append(node["role"])
                for v in node.values():
                    scan(v)
            elif isinstance(node, list):
                for v in node:
                    scan(v)

        scan(self.data["pipeline"])
        return sorted(set(roles))

    # -- realisation -------------------------------------------------------

    def resolve_channels(self, spec: Any, device: DeviceInfo) -> list[str] | None:
        """Turn ``{'role': 'ssvep'}`` or ``['O1','O2']`` into concrete names."""
        if spec is None:
            return None
        if isinstance(spec, list):
            device.pick(spec)                     # raises if absent
            return list(spec)
        if isinstance(spec, dict) and "role" in spec:
            match = Montage(device.ch_names).resolve(
                spec["role"], max_channels=spec.get("max_channels", 4)
            )
            if not match.ok:
                raise ConfigError(match.note)
            return list(match.names)
        raise ConfigError(f"cannot interpret channel spec {spec!r}")

    def build_pipeline(self, device: DeviceInfo):
        """Instantiate the Pipeline described by this config."""
        from .core.pipeline import Pipeline

        def prepare(spec: dict) -> dict:
            spec = dict(spec)
            if "channels" in spec:
                spec["channels"] = self.resolve_channels(spec["channels"], device)
            return spec

        p = self.data["pipeline"]
        transforms = [build("transform", prepare(s)) for s in (p.get("transforms") or [])]
        extractor = build("extractor", prepare(p["extractor"])) if p.get("extractor") else None
        decoder = build("decoder", prepare(p["decoder"])) if p.get("decoder") else None
        return Pipeline(transforms, extractor, decoder,
                        name=self.get("session.paradigm", "pipeline"))

    def build_source(self):
        return build("source", self.data["acquisition"]["source"])

    def to_dict(self) -> dict:
        return json.loads(json.dumps(self.data, default=str))
