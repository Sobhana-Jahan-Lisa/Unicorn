"""Command-line interface.

Four subcommands, each corresponding to something a teacher or researcher
actually needs to do before or after a lesson:

    neurobridge run CONFIG        start a session and serve the browser client
    neurobridge check CONFIG      validate a config against a connected device
    neurobridge devices           list what this machine can talk to
    neurobridge diff A B          compare two session manifests

``check`` exists because the failure mode that matters is discovering a
misconfiguration with a class already seated. It resolves every role, runs one
window through the pipeline, and prints the latency budget -- all without
recording anything.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
import webbrowser
from pathlib import Path


def _serve_web(directory: Path, host: str, port: int):
    """Serve the client over HTTP so the page and the socket share an origin.

    Opening ``index.html`` from disk works in most browsers, but ``file://``
    is an opaque origin and some browsers, extensions and corporate policies
    block a WebSocket opened from one. Serving the same files over
    ``http://127.0.0.1`` removes that whole class of problem, and gives the
    classroom a single URL to type instead of a file path.
    """
    import functools
    import http.server
    import threading

    class Quiet(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *args):
            pass                                    # keep the console readable

    handler = functools.partial(Quiet, directory=str(directory))
    httpd = http.server.ThreadingHTTPServer((host, port), handler)
    threading.Thread(target=httpd.serve_forever, daemon=True,
                     name="web").start()
    return httpd


def _run(args: argparse.Namespace) -> int:
    from . import Session

    session = Session(args.config)
    session.start()

    web_dir = Path(__file__).resolve().parents[2] / "web"
    page = web_dir / "index.html"
    host = session.config["transport"]["host"]
    port = session.config["transport"]["port"]

    print(f"session   {session.session_id}")
    print(f"websocket ws://{host}:{port}")
    print(f"logs      {session.out_dir}")

    url = None
    httpd = None
    if page.exists():
        if args.serve_web:
            try:
                httpd = _serve_web(web_dir, host, args.web_port)
                url = f"http://{host}:{args.web_port}/index.html"
                print(f"client    {url}")
            except OSError as exc:
                print(f"client    could not serve on port {args.web_port} "
                      f"({exc}); falling back to the file path")
        if url is None:
            url = page.as_uri()
            print(f"client    {page}")
        if args.open:
            try:
                webbrowser.open(url)
            except Exception:
                pass
    print("\nCtrl-C to stop.\n")

    try:
        while True:
            time.sleep(args.report_every)
            print("  " + session.metrics.report())
    except KeyboardInterrupt:
        print("\nstopping...")
    finally:
        session.stop()
        if httpd is not None:
            httpd.shutdown()
        print(json.dumps(session.report(), indent=2))
    return 0


def _check(args: argparse.Namespace) -> int:
    from .config import Config, ConfigError

    try:
        cfg = Config.from_file(args.config)
    except ConfigError as exc:
        print(f"config error: {exc}", file=sys.stderr)
        return 1

    source = cfg.build_source()
    try:
        source.start()
        device = source.device
        print(f"device    {device.name} @ {device.sfreq} Hz, "
              f"{device.n_channels} channels")
        print(f"channels  {', '.join(device.ch_names)}")

        report = cfg.validate_against_device(device)
        if report:
            print("\nrole resolution:")
            for role, info in report.items():
                mark = "exact" if info["exact"] else f"substituted ({info['fidelity']})"
                print(f"  {role:<18} {', '.join(info['channels']):<28} {mark}")
                if info["note"]:
                    print(f"  {'':<18} {info['note']}")

        pipeline = cfg.build_pipeline(device)
        print(f"\npipeline  {json.dumps(pipeline.describe(), indent=2)}")

        from .process.filters import StreamFilter
        from .transport.metrics import LatencyBudget

        pre, ep = cfg["preprocess"], cfg["epoching"]
        sf = StreamFilter(device.sfreq, device.n_channels,
                          pre.get("l_freq"), pre.get("h_freq"), pre.get("notch"))
        budget = LatencyBudget(window=ep["window"], step=ep["step"],
                               filter_group_delay=sf.group_delay_s)
        print(f"\nlatency budget: {json.dumps(budget.to_dict(), indent=2)}")
        print("\nconfig is valid for this device.")
    except (ConfigError, KeyError, ValueError) as exc:
        print(f"\nnot valid for this device: {exc}", file=sys.stderr)
        return 1
    finally:
        try:
            source.stop()
        except Exception:
            pass
    return 0


def _devices(args: argparse.Namespace) -> int:
    from .registry import available

    print("sources registered in this install:")
    for name in available("source"):
        print(f"  {name}")

    try:
        from brainflow.board_shim import BoardIds
    except ImportError:
        print("\nbrainflow is not installed, so no hardware boards are listed.")
        print("  pip install neurobridge[brainflow]")
        return 0

    print("\nbrainflow boards available on this machine:")
    for board in BoardIds:
        print(f"  {board.name:<32} id={board.value}")
    return 0


def _diff(args: argparse.Namespace) -> int:
    from .reproducibility import diff_manifests

    a = json.loads(Path(args.a).read_text())
    b = json.loads(Path(args.b).read_text())
    lines = diff_manifests(a, b)
    if not lines:
        print("manifests are equivalent (ignoring session id, participant, "
              "timestamp and commit).")
        return 0
    print(f"{len(lines)} difference(s):")
    for line in lines:
        print(f"  {line}")
    return 1


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="neurobridge",
        description="Real-time EEG and BCI sessions for the classroom.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_run = sub.add_parser("run", help="start a session and serve the browser client")
    p_run.add_argument("config", type=Path)
    p_run.add_argument("--no-open", dest="open", action="store_false",
                       help="do not open the browser automatically")
    p_run.add_argument("--report-every", type=float, default=10.0,
                       metavar="SECONDS")
    p_run.add_argument("--serve-web", action="store_true",
                       help="serve the client over HTTP instead of opening it "
                            "from disk; avoids file:// origin restrictions")
    p_run.add_argument("--web-port", type=int, default=8080, metavar="PORT")
    p_run.set_defaults(func=_run)

    p_check = sub.add_parser("check", help="validate a config against the device")
    p_check.add_argument("config", type=Path)
    p_check.set_defaults(func=_check)

    p_dev = sub.add_parser("devices", help="list available sources and boards")
    p_dev.set_defaults(func=_devices)

    p_diff = sub.add_parser("diff", help="compare two session manifests")
    p_diff.add_argument("a", type=Path)
    p_diff.add_argument("b", type=Path)
    p_diff.set_defaults(func=_diff)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
