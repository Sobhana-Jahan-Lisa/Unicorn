"""Live display in the layout of Unicorn Recorder, with a channel-quality check.

One axis per channel at a fixed ±scale (50 µV by default, as in Recorder),
every received sample drawn -- no decimation, and no clipping: a value beyond
the view simply leaves the axis -- with the two numbers that say how much of a
trace you are not seeing printed beside it: the share of samples outside the
view and the peak-to-peak amplitude. That layout and readout come from the
standalone Unicorn Live Viewer (``unicorn_live.py``). The Good/Bad badge on
each channel is added here, from
:class:`~neurobridge.process.quality.QualityMonitor`.

Good/Bad is neurobridge's physiological check on the last few seconds -- is
this electrode delivering EEG-like signal -- not Unicorn Suite's contact
measurement, and "Good" is not a promise that the window is free of
artifacts. Read it together with the peak-to-peak beside it.

:class:`LiveMonitor` bundles the per-chunk processing (run on the acquisition
thread) with the drawing (run on the GUI timer), so the live viewer and the
four-class recorder show exactly the same thing.
"""

from __future__ import annotations

import time
from typing import Any, Sequence

import numpy as np

from .core.buffer import RingBuffer
from .core.types import Chunk, DeviceInfo
from .process.dropouts import DropoutRepair
from .process.filters import StreamFilter
from .process.quality import QualityMonitor

GOOD = "#2e9e44"
BAD = "#d6412b"
WAITING = "#9e9e9e"


def badge_for(q) -> tuple[str, str]:
    """Short Good/Bad text and colour for one ChannelQuality."""
    if q.usable:
        return "Good", GOOD
    if q.flat:
        reason = "no signal"
    elif q.saturated:
        # Over 500 uV in more than 1% of the filtered window: usually movement
        # or a loose electrode, only sometimes the amplifier's rail.
        reason = "large swings"
    elif "line_noise" in q.flags:
        reason = "mains hum"
    elif "amplitude_out_of_range" in q.flags:
        reason = "too large" if q.rms_uv > 45 else "too small"
    elif "non_physiological_spectrum" in q.flags:
        reason = "noise, not EEG"
    else:
        reason = "poor signal"
    return f"Bad: {reason}", BAD


class ChannelStackView:
    """One axis per channel at a fixed scale, with a badge and readout on each.

    Args:
        ch_names: channel labels, top to bottom.
        sfreq: sampling rate, for the time axis.
        seconds: width of the window on screen.
        scale: fixed half-range in µV; never auto-scaled.
        window_title: title of the plot window.
        top: fraction of the figure height the axes may use; the rest holds
            the status text above them.
    """

    def __init__(self, ch_names: Sequence[str], sfreq: float, seconds: float = 8.0,
                 scale: float = 50.0, window_title: str = "neurobridge",
                 top: float = 0.93) -> None:
        import matplotlib.pyplot as plt

        plt.rcParams["path.simplify"] = False          # draw every sample
        self.names = list(ch_names)
        self.scale = float(scale)
        self.n_show = max(1, int(round(seconds * sfreq)))
        t = (np.arange(self.n_show) - self.n_show + 1) / sfreq
        n = len(self.names)
        self.fig, axes = plt.subplots(n, 1, sharex=True, squeeze=False,
                                      figsize=(13, 9.0 if n <= 8 else 0.9 * n + 1.8))
        self.fig.canvas.manager.set_window_title(window_title)
        self.axes = list(axes[:, 0])
        self.lines, self.badges, self.readouts = [], [], []
        for i, (ax, name) in enumerate(zip(self.axes, self.names)):
            (line,) = ax.plot(t, np.full(self.n_show, np.nan), lw=0.65, color="#007fa3")
            ax.set_xlim(t[0], 0)
            ax.set_ylim(-self.scale, self.scale)
            ax.set_ylabel(f"Ch{i + 1}\n{name}", fontsize=8, rotation=0, ha="right",
                          va="center")
            ax.tick_params(labelsize=7)
            ax.grid(alpha=0.3)
            self.lines.append(line)
            self.badges.append(ax.text(
                0.004, 0.94, "...", transform=ax.transAxes, va="top", fontsize=8,
                fontweight="bold", color="white",
                bbox=dict(boxstyle="round,pad=0.25", fc=WAITING, ec="none")))
            self.readouts.append(ax.text(
                0.996, 0.94, "", transform=ax.transAxes, ha="right", va="top", fontsize=8,
                bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="none", alpha=0.75)))
        self.axes[-1].set_xlabel("seconds relative to the latest received sample")
        self.title = self.fig.suptitle("connecting...", fontsize=10)
        self.fig.tight_layout(rect=(0, 0, 1, top))

    def show_traces(self, window: np.ndarray, centre: bool = False) -> None:
        """Draw the newest samples; ``window`` is (n_channels, k), k <= n_show."""
        k = min(window.shape[1], self.n_show)
        for i, line in enumerate(self.lines):
            x = np.asarray(window[i, window.shape[1] - k:], dtype=np.float64)
            if centre and k:
                x = x - np.median(x)                    # display only
            y = np.full(self.n_show, np.nan)
            y[self.n_show - k:] = x
            line.set_ydata(y)
            if k:
                outside = 100.0 * np.mean(np.abs(x) > self.scale)
                self.readouts[i].set_text(
                    f"outside ±{self.scale:g} µV: {outside:.1f}%  |  p-p {np.ptp(x):.1f} µV")

    def show_quality(self, qualities) -> None:
        for badge, q in zip(self.badges, qualities):
            text, colour = badge_for(q)
            badge.set_text(text)
            badge.get_bbox_patch().set_facecolor(colour)

    def set_status(self, text: str, colour: str = "black") -> None:
        self.title.set_text(text)
        self.title.set_color(colour)


class LiveMonitor:
    """Per-chunk processing plus drawing, shared by the live viewer and recorder.

    Pass the instance to :class:`~neurobridge.io.acquisition.AcquisitionThread`
    as a consumer, so every chunk is processed on the acquisition thread, and
    call :meth:`draw` from the GUI timer. Three copies of the stream are kept:
    as delivered (the ``raw`` display), Bluetooth-dropout-repaired and
    display-filtered, and dropout-repaired at 1-45 Hz for the quality check,
    which runs once a second on the last ``quality_window_s`` seconds -- the
    same data and window 06_live_scope.py scores. The display filter is never
    used for quality: the metrics are defined on 1-45 Hz data.

    Args:
        device: the started source's DeviceInfo.
        low, high, notch: display band-pass edges and notch (0 or None: none).
        mains: 50 or 60, for the quality check and the dropout repair.
        seconds, scale: window on screen and fixed half-range in µV.
        raw: show samples as delivered, median-centred for display only.
        top: fraction of the figure height left to the axes.
    """

    def __init__(self, device: DeviceInfo, *, low: float = 0.1, high: float = 30.0,
                 notch: float | None = 60.0, mains: float = 60.0, seconds: float = 8.0,
                 scale: float = 50.0, raw: bool = False, quality_window_s: float = 5.0,
                 window_title: str = "neurobridge", top: float = 0.93) -> None:
        sf, n = float(device.sfreq), device.n_channels
        self.sf, self.names, self.raw_mode = sf, list(device.ch_names), bool(raw)
        self.repair = DropoutRepair(n, sf, mains)
        self.display_filter = StreamFilter(sf, n, l_freq=low, h_freq=high,
                                           notch=notch or None)
        self.quality_filter = StreamFilter(sf, n, l_freq=1.0, h_freq=min(45.0, sf / 2 - 5),
                                           notch=mains)
        self.quality = QualityMonitor(mains=mains)
        self.view = ChannelStackView(self.names, sf, seconds, scale, window_title, top)
        self.raw = RingBuffer(n, self.view.n_show)
        self.shown = RingBuffer(n, self.view.n_show)
        self.for_quality = RingBuffer(n, int(round(quality_window_s * sf)))
        # How long the display filter's start-up transient may still be
        # visible: the same conservative rule of thumb unicorn_live.py uses,
        # not a proof that it has gone.
        self.settle_s = 0.0 if raw else max(8.0, 5.0 / low)
        self.summary: dict[str, Any] | None = None
        self._last_quality = 0.0
        mode = ("unfiltered, median-centred for display" if raw else
                f"{low:g}-{high:g} Hz" + (f", {notch:g} Hz notch" if notch else ", no notch"))
        self.headline = (f"{device.name}  |  {sf:g} Hz  |  {mode}  |  ±{scale:g} µV  |  "
                         f"no OSCAR  |  Good/Bad: 1-45 Hz, last {quality_window_s:g} s")

    def __call__(self, chunk: Chunk) -> None:
        """Acquisition thread: bring the three copies of the stream up to date."""
        self.raw.push(chunk.data)
        x = self.repair(chunk.data)
        self.shown.push(self.display_filter(x))
        self.for_quality.push(self.quality_filter(x))

    def draw(self, acq, source=None, extra_parts: Sequence[str] = (),
             extra_lines: Sequence[str] = ()) -> None:
        """GUI thread: redraw the traces, the badges (once a second) and the status."""
        buf = self.raw if self.raw_mode else self.shown
        have = min(buf.total_written, self.view.n_show)
        if have == 0:
            self.view.set_status(acq.error or "waiting for EEG samples...",
                                 BAD if acq.error else "black")
            return
        self.view.show_traces(buf.latest(have), centre=self.raw_mode)
        now = time.monotonic()
        nq = min(self.for_quality.total_written, self.for_quality.capacity)
        if now - self._last_quality >= 1.0 and nq >= int(2 * self.sf):
            self._last_quality = now
            qs = self.quality(self.for_quality.latest(nq), self.sf, self.names)
            self.view.show_quality(qs)
            self.summary = self.quality.summary(qs)
        stale = acq.seconds_since_data() > 2.0
        parts = [acq.error or ("NO RECENT DATA" if stale else "receiving")]
        received = acq.total / self.sf
        if received < self.settle_s:
            parts.append(f"filter settling {received:.0f}/{self.settle_s:.0f} s")
        if self.summary is not None:
            parts.append(f"{self.summary['n_usable']}/{self.summary['n_channels']} "
                         f"channels Good")
        held = getattr(source, "held_fraction", None)
        if held is not None:
            parts.append(f"Bluetooth held {100 * held:.1f}% (10 s)")
        gaps = getattr(source, "counter_missing_total", None)
        if gaps is not None:
            parts.append(f"counter gaps {gaps}")
        parts.extend(extra_parts)
        text = "\n".join([self.headline, "  |  ".join(parts), *extra_lines])
        self.view.set_status(text, BAD if (acq.error or stale) else "black")
