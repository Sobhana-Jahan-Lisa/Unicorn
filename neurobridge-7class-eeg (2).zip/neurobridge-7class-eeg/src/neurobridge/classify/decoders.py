"""Decoders: features -> Prediction.

Three concerns are separated here that are usually tangled together:

1. **Mapping** a feature to a control value.
2. **Stabilising** that value in time, so the game does not flicker.
3. **Abstaining** when the evidence is weak, so the game does nothing rather
   than doing something wrong.

Point 3 is the one most BCI game implementations skip, and it is why they feel
erratic. A decoder that can say "I don't know" turns an unreliable classifier
into a usable interface, at the cost of a slower selection rate -- a trade that
should be measured (see ``information_transfer_rate``) rather than assumed.
"""

from __future__ import annotations

import math
from collections import deque
from typing import Any

import numpy as np

from ..core.pipeline import BaseStage
from ..core.types import Prediction
from ..registry import register
from ..core.clock import now


@register("decoder", "threshold")
class ThresholdDecoder(BaseStage):
    """Binary decision on one feature, with hysteresis.

    A single threshold makes the output chatter whenever the feature sits near
    it. Two thresholds (Schmitt trigger) fix this: the state flips to ON only
    above ``high`` and back to OFF only below ``low``. The gap is the price of
    stability, expressed in the same units as the feature so it can be reasoned
    about instead of tuned blindly.

    Args:
        feature: key of the feature to threshold.
        low, high: hysteresis bounds, ``low < high``.
        min_dwell: seconds a state must persist before it is emitted, which
            suppresses single-window flukes from a blink.
    """

    def __init__(self, feature: str, low: float, high: float,
                 min_dwell: float = 0.0) -> None:
        if low >= high:
            raise ValueError(f"low ({low}) must be below high ({high})")
        self.feature, self.low, self.high = feature, low, high
        self.min_dwell = min_dwell
        self._state = 0
        self._pending: tuple[int, float] | None = None
        self._record(feature=feature, low=low, high=high, min_dwell=min_dwell)

    def __call__(self, features: dict[str, float]) -> Prediction:
        if self.feature not in features:
            raise KeyError(
                f"decoder needs feature {self.feature!r}; extractor produced "
                f"{sorted(features)}"
            )
        x = features[self.feature]
        target = self._state
        if x >= self.high:
            target = 1
        elif x <= self.low:
            target = 0

        if self.min_dwell > 0 and target != self._state:
            import time
            t = now()
            if self._pending is None or self._pending[0] != target:
                self._pending = (target, t)
            elif t - self._pending[1] >= self.min_dwell:
                self._state, self._pending = target, None
        else:
            self._state = target

        # Confidence: distance past the active threshold, normalised by the
        # hysteresis gap and saturated at 1.
        span = self.high - self.low
        conf = abs(x - (self.high if self._state else self.low)) / max(span, 1e-9)
        return Prediction(value=self._state, confidence=float(min(1.0, conf)))


@register("decoder", "proportional")
class ProportionalDecoder(BaseStage):
    """Maps a feature to a continuous [0, 1] control value.

    Uses a calibrated linear map with saturation::

        u = clip( (x - x_lo) / (x_hi - x_lo), 0, 1 )

    where ``x_lo``/``x_hi`` come from the student's own calibration percentiles,
    not from population norms. Per-subject scaling is essential: absolute alpha
    power varies by an order of magnitude between people for reasons that have
    nothing to do with attention (skull thickness, hair, electrode contact).

    An optional first-order low-pass smooths the output. Its time constant is
    stated in seconds and converted using the actual update rate, so changing
    the window step does not silently change the feel of the control.
    """

    def __init__(self, feature: str, x_lo: float, x_hi: float,
                 tau: float = 0.5, update_rate: float = 4.0,
                 invert: bool = False) -> None:
        if math.isclose(x_lo, x_hi):
            raise ValueError("x_lo and x_hi must differ")
        self.feature, self.x_lo, self.x_hi = feature, x_lo, x_hi
        self.tau, self.update_rate, self.invert = tau, update_rate, invert
        # alpha = dt / (tau + dt) for a first-order IIR low-pass.
        dt = 1.0 / max(update_rate, 1e-6)
        self._a = dt / (tau + dt) if tau > 0 else 1.0
        self._y: float | None = None
        self._record(feature=feature, x_lo=x_lo, x_hi=x_hi, tau=tau,
                     update_rate=update_rate, invert=invert)

    def __call__(self, features: dict[str, float]) -> Prediction:
        x = features[self.feature]
        u = (x - self.x_lo) / (self.x_hi - self.x_lo)
        u = float(np.clip(u, 0.0, 1.0))
        if self.invert:
            u = 1.0 - u
        self._y = u if self._y is None else self._a * u + (1 - self._a) * self._y
        # Confidence falls off when the raw value is saturated at either rail,
        # because saturation means the calibration no longer resolves the state.
        conf = 1.0 - abs(2 * u - 1.0) ** 4
        return Prediction(value=float(self._y), confidence=float(conf))


@register("decoder", "argmax")
class ArgmaxDecoder(BaseStage):
    """Selects the largest of several scores, abstaining when evidence is weak.

    Designed for SSVEP: pass the ``rho_*`` dictionary from ``FilterBankCCA``.

    Two guards before a selection is emitted:

    * the winning score must exceed ``min_score``;
    * the margin between the top two scores, normalised as
      ``(s1 - s2) / s1``, must exceed ``min_margin``.

    The margin test is what prevents a near-tie between two flicker frequencies
    from producing a coin-flip selection. When either test fails the decoder
    emits ``None`` with the confidence it did have, and the game should show
    "keep looking" rather than moving.
    """

    def __init__(self, prefix: str = "rho_", min_score: float = 0.05,
                 min_margin: float = 0.15, n_confirm: int = 2) -> None:
        self.prefix = prefix
        self.min_score, self.min_margin = min_score, min_margin
        self.n_confirm = max(1, n_confirm)
        self._recent: deque = deque(maxlen=self.n_confirm)
        self._record(prefix=prefix, min_score=min_score,
                     min_margin=min_margin, n_confirm=n_confirm)

    def __call__(self, features: dict[str, float]) -> Prediction:
        items = [(k[len(self.prefix):], v) for k, v in features.items()
                 if k.startswith(self.prefix)]
        if not items:
            raise KeyError(f"no features starting with {self.prefix!r}")
        items.sort(key=lambda kv: kv[1], reverse=True)
        (best, s1) = items[0]
        s2 = items[1][1] if len(items) > 1 else 0.0
        margin = (s1 - s2) / max(s1, 1e-12)

        ok = s1 >= self.min_score and margin >= self.min_margin
        self._recent.append(best if ok else None)
        # Require the same answer n_confirm windows in a row.
        confirmed = (
            len(self._recent) == self._recent.maxlen
            and len(set(self._recent)) == 1
            and self._recent[0] is not None
        )
        return Prediction(
            value=self._recent[0] if confirmed else "none",
            confidence=float(np.clip(margin, 0.0, 1.0)),
            features={"top_score": float(s1), "margin": float(margin)},
        )


@register("decoder", "sklearn")
class SklearnDecoder(BaseStage):
    """Wraps any fitted scikit-learn estimator.

    Features are ordered by ``feature_names`` -- captured at fit time -- rather
    than by dictionary order, because a silently reordered feature vector is the
    single most common way a working offline model becomes a broken online one.
    """

    def __init__(self, model: Any, feature_names: list[str],
                 min_confidence: float = 0.0) -> None:
        self.model = model
        self.feature_names = list(feature_names)
        self.min_confidence = min_confidence
        self._record(model=type(model).__name__,
                     feature_names=self.feature_names,
                     min_confidence=min_confidence)

    def __call__(self, features: dict[str, float]) -> Prediction:
        missing = [f for f in self.feature_names if f not in features]
        if missing:
            raise KeyError(f"model expects features {missing} which are absent")
        x = np.array([[features[f] for f in self.feature_names]])
        label = self.model.predict(x)[0]
        conf = 1.0
        if hasattr(self.model, "predict_proba"):
            conf = float(np.max(self.model.predict_proba(x)))
        if conf < self.min_confidence:
            return Prediction(value="none", confidence=conf)
        value = label.item() if hasattr(label, "item") else label
        return Prediction(value=value, confidence=conf)


def information_transfer_rate(accuracy: float, n_classes: int,
                              seconds_per_selection: float) -> dict[str, float]:
    """Wolpaw information transfer rate.

        B = log2(N) + P*log2(P) + (1 - P)*log2((1 - P) / (N - 1))   bits/selection
        ITR = B * 60 / T                                            bits/minute

    Defined for ``P >= 1/N``; at chance the expression is zero, and below chance
    it is not meaningful, so this returns 0 rather than a negative number that
    would look like a result.

    Reporting ITR alongside accuracy is what makes an abstaining decoder
    comparable to a greedy one: abstention raises P but lowers the selection
    rate, and only ITR prices both.
    """
    N, P = int(n_classes), float(accuracy)
    if N < 2:
        raise ValueError("n_classes must be at least 2")
    if seconds_per_selection <= 0:
        raise ValueError("seconds_per_selection must be positive")
    if P <= 1.0 / N:
        bits = 0.0
    elif P >= 1.0:
        bits = math.log2(N)
    else:
        bits = (math.log2(N) + P * math.log2(P)
                + (1 - P) * math.log2((1 - P) / (N - 1)))
    return {
        "bits_per_selection": round(bits, 4),
        "bits_per_minute": round(bits * 60.0 / seconds_per_selection, 3),
        "selections_per_minute": round(60.0 / seconds_per_selection, 2),
    }
