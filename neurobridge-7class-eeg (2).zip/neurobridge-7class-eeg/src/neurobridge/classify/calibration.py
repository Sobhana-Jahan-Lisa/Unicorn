"""Calibration and BCI-literacy screening.

The problem this solves
-----------------------
A substantial minority of people cannot produce a usable control signal with a
given paradigm on a given day -- commonly called BCI illiteracy or, more
accurately, BCI inefficiency. In a research lab this is a footnote. In a
classroom study it is a validity threat: if a child's game does not respond,
their post-test score measures frustration, not the effectiveness of the
teaching approach, and the treatment effect you report is contaminated by a
hardware failure you never recorded.

So screening is built in and produces a *reported outcome*, not a hidden
precondition. Every session gets a separability estimate with a confidence
interval and a permutation p-value, and a documented decision rule for what
happens when a student falls below threshold. Students who cannot drive the
paradigm are moved to a documented fallback rather than dropped, which keeps
the intention-to-treat analysis intact.

Statistics
----------
* Cross-validated accuracy via stratified k-fold, with a Wilson score interval
  rather than the normal approximation, which is badly wrong at the small
  trial counts a classroom session allows (20-60 trials).
* A label-permutation test for above-chance performance, with the
  ``(1 + count) / (1 + n_perm)`` estimator, which is the unbiased form -- the
  naive ``count / n_perm`` can report p = 0, which is never true.
* Cohen's d on the single most discriminative feature, so a teacher gets an
  effect size and not only a p-value.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Callable

import numpy as np
from sklearn.base import clone
from sklearn.model_selection import StratifiedKFold, cross_val_score

from ..core.types import Epoch


@dataclass
class CalibrationBlock:
    """One instructed segment of the calibration recording."""

    label: str
    instruction: str
    duration: float            # seconds
    cue: str = ""              # optional visual/audio cue id for the front end


#: Ready-made protocols. Durations are chosen for a school lesson: the whole
#: calibration must fit inside a few minutes with a child in the chair.
PROTOCOLS: dict[str, list[CalibrationBlock]] = {
    "alpha": [
        CalibrationBlock("rest_open", "Look at the cross and keep your eyes open.", 30),
        CalibrationBlock("rest_closed", "Close your eyes and relax.", 30),
        CalibrationBlock("rest_open", "Open your eyes again.", 30),
        CalibrationBlock("rest_closed", "Close your eyes one more time.", 30),
    ],
    "motor_imagery": [
        CalibrationBlock("left", "Imagine squeezing your LEFT hand.", 4, cue="arrow_left"),
        CalibrationBlock("right", "Imagine squeezing your RIGHT hand.", 4, cue="arrow_right"),
    ] * 20,
    "ssvep": [
        CalibrationBlock("f1", "Look at the box that flickers slowly.", 5, cue="target_1"),
        CalibrationBlock("f2", "Look at the next box.", 5, cue="target_2"),
        CalibrationBlock("f3", "Look at the third box.", 5, cue="target_3"),
        CalibrationBlock("f4", "Look at the last box.", 5, cue="target_4"),
    ] * 5,
}


def wilson_interval(k: int, n: int, z: float = 1.96) -> tuple[float, float]:
    """Wilson score confidence interval for a binomial proportion.

        centre = (p_hat + z^2/2n) / (1 + z^2/n)
        half   = z/(1 + z^2/n) * sqrt( p_hat(1-p_hat)/n + z^2/4n^2 )

    Correct near 0 and 1 and at small n, where the Wald interval can extend
    outside [0, 1] and badly under-cover.
    """
    if n == 0:
        return (0.0, 1.0)
    p = k / n
    denom = 1 + z**2 / n
    centre = (p + z**2 / (2 * n)) / denom
    half = z / denom * math.sqrt(p * (1 - p) / n + z**2 / (4 * n**2))
    return (max(0.0, centre - half), min(1.0, centre + half))


def cohens_d(a: np.ndarray, b: np.ndarray) -> float:
    """Standardised mean difference with the pooled standard deviation."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    na, nb = len(a), len(b)
    if na < 2 or nb < 2:
        return float("nan")
    sp2 = ((na - 1) * a.var(ddof=1) + (nb - 1) * b.var(ddof=1)) / (na + nb - 2)
    if sp2 <= 0:
        return float("nan")
    return float((a.mean() - b.mean()) / math.sqrt(sp2))


def permutation_test(
    model: Any, X: np.ndarray, y: np.ndarray, n_perm: int = 500,
    cv: int = 5, seed: int = 0,
) -> tuple[float, float, np.ndarray]:
    """Return (observed accuracy, p-value, null distribution).

    The label permutation is done *outside* the cross-validation loop so the
    null preserves the class balance and the CV structure; permuting inside a
    fold would leak the true labels through the fold assignment.
    """
    rng = np.random.default_rng(seed)
    n_splits = min(cv, int(np.min(np.bincount(_encode(y)))))
    if n_splits < 2:
        raise ValueError("each class needs at least 2 trials for cross-validation")
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    obs = float(np.mean(cross_val_score(clone(model), X, y, cv=skf)))

    null = np.empty(n_perm)
    for i in range(n_perm):
        yp = rng.permutation(y)
        null[i] = np.mean(cross_val_score(clone(model), X, yp, cv=skf))
    p = (1.0 + np.sum(null >= obs)) / (1.0 + n_perm)
    return obs, float(p), null


def _encode(y: np.ndarray) -> np.ndarray:
    _, inv = np.unique(y, return_inverse=True)
    return inv


@dataclass
class CalibrationResult:
    """Everything the study needs to record about one student's calibration."""

    paradigm: str
    n_trials: int
    n_classes: int
    accuracy: float
    accuracy_ci: tuple[float, float]
    chance: float
    p_value: float
    effect_size: float
    status: str                      # 'good' | 'marginal' | 'fallback'
    features: list[str] = field(default_factory=list)
    control_range: dict[str, float] = field(default_factory=dict)
    quality: dict[str, Any] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        d = self.__dict__.copy()
        d["accuracy_ci"] = list(self.accuracy_ci)
        return d

    def message(self) -> str:
        """What the front end shows the student -- never the word 'illiterate'."""
        if self.status == "good":
            return "Your brain signals are coming through clearly. Ready to play!"
        if self.status == "marginal":
            return ("We can read your signals, but they are a little quiet. "
                    "The game will give you extra help.")
        return ("Your signals are hard to read today. We will switch to the "
                "practice mode so you can still do the whole lesson.")


class Calibrator:
    """Runs a calibration protocol and decides how the session should proceed.

    Args:
        paradigm: key into ``PROTOCOLS``.
        featurizer: callable Epoch -> dict[str, float]; usually the same
            extractor the live pipeline will use, so calibration and online
            operation cannot drift apart.
        model: scikit-learn estimator used to estimate separability.
        good/marginal: accuracy thresholds above chance for each status band.
    """

    def __init__(
        self,
        paradigm: str,
        featurizer: Callable[[Epoch], dict[str, float]],
        model: Any | None = None,
        good: float = 0.75,
        marginal: float = 0.60,
        alpha: float = 0.05,
    ) -> None:
        if paradigm not in PROTOCOLS:
            raise KeyError(f"unknown paradigm {paradigm!r}; known: {sorted(PROTOCOLS)}")
        self.paradigm = paradigm
        self.featurizer = featurizer
        self.alpha = alpha
        self.good, self.marginal = good, marginal
        if model is None:
            from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
            from sklearn.pipeline import make_pipeline
            from sklearn.preprocessing import StandardScaler
            # Shrinkage LDA: the right default when trials are few relative to
            # features, which is always true for a 3-minute calibration.
            model = make_pipeline(
                StandardScaler(),
                LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto"),
            )
        self.model = model
        self._X: list[list[float]] = []
        self._y: list[str] = []
        self._names: list[str] | None = None
        self._dropped_features: list[str] = []
        self._dropped_epochs = 0

    @property
    def blocks(self) -> list[CalibrationBlock]:
        return PROTOCOLS[self.paradigm]

    @property
    def duration(self) -> float:
        return sum(b.duration for b in self.blocks)

    def add(self, epoch: Epoch, label: str) -> None:
        """Add one labelled calibration epoch.

        Some features are legitimately undefined before calibration has run --
        ``alpha_suppression`` needs the resting baseline this very procedure
        establishes, and reports NaN until it exists. Those columns are dropped
        once, on the first epoch, and recorded in the result. Dropping the whole
        *epoch* instead (the obvious implementation) discards every trial and
        leaves you with an empty calibration and no explanation.
        """
        feats = self.featurizer(epoch)
        if self._names is None:
            self._names = sorted(k for k, v in feats.items()
                                 if np.isfinite(v))
            self._dropped_features = sorted(set(feats) - set(self._names))
            if not self._names:
                raise RuntimeError(
                    f"every feature from {type(self.featurizer).__name__} was "
                    f"non-finite on the first epoch: {sorted(feats)}. "
                    f"Calibration cannot proceed."
                )
        vec = [feats.get(n, float("nan")) for n in self._names]
        if not all(np.isfinite(vec)):
            self._dropped_epochs += 1        # a genuinely bad window
            return
        self._X.append(vec)
        self._y.append(label)

    def fit(self, n_perm: int = 200, quality: dict | None = None) -> CalibrationResult:
        X = np.asarray(self._X, dtype=float)
        y = np.asarray(self._y)
        notes: list[str] = []

        if len(X) == 0:
            raise RuntimeError(
                f"no calibration epochs were collected "
                f"({self._dropped_epochs} were dropped as non-finite). Check "
                f"that set_calibration_label() was called during each block "
                f"and that the headset was streaming."
            )
        if self._dropped_features:
            notes.append(
                f"features not usable during calibration and excluded: "
                f"{self._dropped_features}"
            )
        if self._dropped_epochs:
            notes.append(f"{self._dropped_epochs} epochs dropped as non-finite")
        classes = np.unique(y)
        n_classes = len(classes)
        chance = 1.0 / n_classes

        counts = np.bincount(_encode(y))
        if counts.min() < 5:
            notes.append(
                f"only {counts.min()} trials in the smallest class; the accuracy "
                f"estimate is very uncertain"
            )

        acc, p, _ = permutation_test(self.model, X, y, n_perm=n_perm)
        n_correct = int(round(acc * len(y)))
        ci = wilson_interval(n_correct, len(y))

        # Effect size on the single most discriminative feature (two-class only).
        d = float("nan")
        if n_classes == 2:
            ds = [abs(cohens_d(X[y == classes[0], j], X[y == classes[1], j]))
                  for j in range(X.shape[1])]
            d = float(np.nanmax(ds)) if len(ds) else float("nan")

        # Status: require both a point estimate above threshold and evidence
        # that it is above chance. Either alone is not enough -- a high accuracy
        # on 12 trials is not evidence, and a significant p-value at 55% is not
        # a usable interface.
        if acc >= self.good and p < self.alpha:
            status = "good"
        elif acc >= self.marginal and p < self.alpha:
            status = "marginal"
            notes.append("adaptive assistance enabled")
        else:
            status = "fallback"
            notes.append(
                "signal not separable above chance today; switch to the "
                "replay/practice mode and record this as a protocol deviation"
            )

        # Control range for continuous decoders: robust percentiles rather than
        # min/max, which a single artefact would blow out.
        control: dict[str, float] = {}
        if self._names and X.size:
            for j, name in enumerate(self._names):
                lo, hi = np.percentile(X[:, j], [10, 90])
                control[f"{name}_p10"] = float(lo)
                control[f"{name}_p90"] = float(hi)

        return CalibrationResult(
            paradigm=self.paradigm, n_trials=len(y), n_classes=n_classes,
            accuracy=round(acc, 4), accuracy_ci=(round(ci[0], 4), round(ci[1], 4)),
            chance=chance, p_value=round(p, 4),
            effect_size=round(d, 3) if np.isfinite(d) else float("nan"),
            status=status, features=list(self._names or []),
            control_range=control, quality=quality or {},
            notes=notes,
        )
