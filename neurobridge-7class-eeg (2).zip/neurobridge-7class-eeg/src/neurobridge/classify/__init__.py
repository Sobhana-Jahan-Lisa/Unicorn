"""Spatial filters, decoders and calibration."""
