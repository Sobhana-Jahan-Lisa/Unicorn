"""Spatial filtering and manifold features, as scikit-learn transformers.

Both classes implement ``fit``/``transform`` with ``BaseEstimator`` and
``TransformerMixin``, so they drop into ``sklearn.pipeline.Pipeline`` and work
with ``cross_val_score``, ``GridSearchCV`` and everything else in that
ecosystem. That is the cheapest possible route to "people can plug in their own
model": there is nothing to learn beyond scikit-learn.

Input convention throughout: ``X`` has shape ``(n_epochs, n_channels,
n_samples)``, matching MNE and pyriemann, so recorded data moves between this
package and the wider ecosystem without transposition bugs.
"""

from __future__ import annotations

import numpy as np
from scipy import linalg
from sklearn.base import BaseEstimator, ClassifierMixin, TransformerMixin

from ..process.features import _make_spd, covariance


def _covariances(X: np.ndarray, method: str = "ledoit_wolf") -> np.ndarray:
    return np.stack([covariance(x, method) for x in X])


class CSP(BaseEstimator, TransformerMixin):
    """Common Spatial Patterns for two-class discrimination.

    Solves the generalised eigenvalue problem

        C_1 w = lambda (C_1 + C_2) w

    whose eigenvectors maximise the variance ratio between classes. The
    eigenvalues lie in [0, 1]; components at the extremes are the most
    discriminative, so ``n_components`` filters are taken alternately from each
    end of the spectrum.

    Features are log-variances of the projected signals, normalised by the
    total projected variance::

        f_j = log( var(w_j^T X) / sum_k var(w_k^T X) )

    The log is not cosmetic: variances are approximately chi-square
    distributed, and the log transform makes them close enough to Gaussian for
    LDA -- the pairing that CSP+LDA has relied on since the original
    sensorimotor-rhythm work.

    Args:
        n_components: number of spatial filters retained (even numbers work
            best, taken symmetrically from both ends).
        cov_method: covariance estimator. Shrinkage is on by default because an
            8-channel headset with a 1-2 s window does not give enough samples
            for a well-conditioned sample covariance.
        log: return log-variance features (True) or raw normalised variance.
    """

    def __init__(self, n_components: int = 4, cov_method: str = "ledoit_wolf",
                 log: bool = True) -> None:
        self.n_components = n_components
        self.cov_method = cov_method
        self.log = log

    def fit(self, X: np.ndarray, y: np.ndarray) -> "CSP":
        X = np.asarray(X, dtype=np.float64)
        y = np.asarray(y)
        classes = np.unique(y)
        if len(classes) != 2:
            raise ValueError(
                f"CSP is a two-class method; got {len(classes)} classes "
                f"{list(classes)}. Use one-vs-rest for more."
            )
        if X.ndim != 3:
            raise ValueError(f"expected (n_epochs, n_channels, n_samples), got {X.shape}")
        n_ch = X.shape[1]
        if self.n_components > n_ch:
            raise ValueError(
                f"n_components={self.n_components} exceeds the {n_ch} channels "
                f"available on this device"
            )

        covs = _covariances(X, self.cov_method)
        # Trace-normalise so epochs with large overall amplitude do not dominate.
        covs = covs / np.trace(covs, axis1=1, axis2=2)[:, None, None]

        C1 = _make_spd(covs[y == classes[0]].mean(axis=0))
        C2 = _make_spd(covs[y == classes[1]].mean(axis=0))

        w, V = linalg.eigh(C1, C1 + C2)
        order = np.argsort(w)
        # Interleave from both extremes: most class-1, most class-2, ...
        picks: list[int] = []
        lo, hi = 0, len(order) - 1
        while len(picks) < self.n_components:
            picks.append(order[hi]); hi -= 1
            if len(picks) < self.n_components:
                picks.append(order[lo]); lo += 1

        self.filters_ = V[:, picks].T                     # (n_components, n_ch)
        self.eigenvalues_ = w[picks]
        # Patterns (columns of the inverse) are what you plot on a scalp map;
        # filters are for projection, patterns are for interpretation.
        self.patterns_ = linalg.pinv(V).T[:, picks].T
        self.classes_ = classes
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=np.float64)
        Z = np.einsum("cd,edn->ecn", self.filters_, X)     # project each epoch
        var = Z.var(axis=-1)
        var = var / np.maximum(var.sum(axis=1, keepdims=True), 1e-15)
        return np.log(np.maximum(var, 1e-15)) if self.log else var


def riemannian_mean(covs: np.ndarray, tol: float = 1e-8,
                    max_iter: int = 50) -> np.ndarray:
    """Karcher (Frechet) mean of SPD matrices under the affine-invariant metric.

    Iterates the fixed-point update

        T   = (1/K) sum_i  log_M(C_i)
        M   <- exp_M(T)

    where ``log_M(C) = M^{1/2} logm(M^{-1/2} C M^{-1/2}) M^{1/2}``. This is the
    correct notion of "average covariance" on the SPD manifold; the arithmetic
    mean is not, because it ignores the manifold's curvature and inflates
    determinants (the swelling effect).
    """
    covs = np.asarray(covs, dtype=np.float64)
    M = covs.mean(axis=0)
    M = _make_spd(M)
    for _ in range(max_iter):
        M_isqrt = _sqrtm_inv(M)
        M_sqrt = _sqrtm(M)
        T = np.zeros_like(M)
        for C in covs:
            T += _logm(M_isqrt @ C @ M_isqrt)
        T /= len(covs)
        norm = float(np.linalg.norm(T, "fro"))
        M = _make_spd(M_sqrt @ _expm(T) @ M_sqrt)
        if norm < tol:
            break
    return M


def _eig_fun(C: np.ndarray, fn) -> np.ndarray:
    w, V = linalg.eigh(0.5 * (C + C.T))
    w = np.maximum(w, 1e-12)
    return V @ np.diag(fn(w)) @ V.T


def _sqrtm(C): return _eig_fun(C, np.sqrt)
def _sqrtm_inv(C): return _eig_fun(C, lambda w: 1.0 / np.sqrt(w))
def _logm(C): return _eig_fun(C, np.log)
def _expm(C):
    w, V = linalg.eigh(0.5 * (C + C.T))
    return V @ np.diag(np.exp(w)) @ V.T


class TangentSpace(BaseEstimator, TransformerMixin):
    """Projects covariance matrices onto the tangent space at their Karcher mean.

    Covariance matrices live on a curved manifold, so Euclidean classifiers
    applied to their raw entries are working in the wrong geometry. Mapping to
    the tangent space at the group mean gives a Euclidean vector space in which
    ordinary logistic regression or LDA is well-posed -- the approach that made
    Riemannian methods the strongest general-purpose EEG decoders in open
    competition.

    The vectorisation keeps the upper triangle with off-diagonal entries scaled
    by ``sqrt(2)`` so the Euclidean norm of the vector equals the Frobenius norm
    of the matrix; without that factor, distances in feature space no longer
    correspond to distances on the manifold.
    """

    def __init__(self, cov_method: str = "ledoit_wolf") -> None:
        self.cov_method = cov_method

    def fit(self, X: np.ndarray, y: np.ndarray | None = None) -> "TangentSpace":
        covs = _covariances(np.asarray(X, dtype=np.float64), self.cov_method)
        self.mean_ = riemannian_mean(covs)
        self.mean_isqrt_ = _sqrtm_inv(self.mean_)
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        covs = _covariances(np.asarray(X, dtype=np.float64), self.cov_method)
        n = covs.shape[1]
        iu = np.triu_indices(n)
        scale = np.where(iu[0] == iu[1], 1.0, np.sqrt(2.0))
        out = np.empty((len(covs), len(iu[0])))
        for i, C in enumerate(covs):
            S = _logm(self.mean_isqrt_ @ C @ self.mean_isqrt_)
            out[i] = S[iu] * scale
        return out


def distance_riemann(A: np.ndarray, B: np.ndarray) -> float:
    """Affine-invariant geodesic distance: ``sqrt(sum(log(eig(A^-1 B))^2))``."""
    w = linalg.eigvalsh(A, B)
    w = np.maximum(w, 1e-12)
    return float(np.sqrt(np.sum(np.log(w) ** 2)))


class MDM(ClassifierMixin, BaseEstimator):
    """Minimum Distance to Mean classifier on the SPD manifold.

    Trains in closed form (one Karcher mean per class) and has no
    hyperparameters, which makes it the right first classifier for a classroom:
    it cannot overfit a 40-trial calibration the way a tuned SVM will, and its
    decision rule -- "whichever class your brain state is closest to" -- can be
    explained to a twelve-year-old in one sentence.
    """

    def __init__(self, cov_method: str = "ledoit_wolf") -> None:
        self.cov_method = cov_method

    def fit(self, X: np.ndarray, y: np.ndarray) -> "MDM":
        covs = _covariances(np.asarray(X, dtype=np.float64), self.cov_method)
        self.classes_ = np.unique(y)
        self.means_ = [riemannian_mean(covs[y == c]) for c in self.classes_]
        return self

    def _distances(self, X: np.ndarray) -> np.ndarray:
        covs = _covariances(np.asarray(X, dtype=np.float64), self.cov_method)
        return np.array([[distance_riemann(m, C) for m in self.means_] for C in covs])

    def predict(self, X: np.ndarray) -> np.ndarray:
        return self.classes_[np.argmin(self._distances(X), axis=1)]

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """Softmax over negative distances -- a usable confidence, not a posterior.

        Labelled honestly because calling an unnormalised distance a probability
        is how confidence displays end up lying to students.
        """
        d = self._distances(X)
        z = np.exp(-(d - d.min(axis=1, keepdims=True)))
        return z / z.sum(axis=1, keepdims=True)
