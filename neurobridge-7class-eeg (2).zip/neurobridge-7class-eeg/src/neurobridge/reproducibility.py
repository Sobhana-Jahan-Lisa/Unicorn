"""Reproducibility manifest.

Every session writes one ``manifest.json`` recording exactly what ran: the
resolved configuration, the pipeline with all stage parameters, the device and
how its montage was mapped to the requested roles, library versions, random
seeds, and a content hash of the config.

The hash is the useful part. Six months later, when a reviewer asks whether the
control group used the same preprocessing, you compare two hex strings instead
of two memories. The manifest is also what makes a multi-site replication
possible: another group can diff their manifest against yours and see precisely
where the setups differ.

Nothing here contains identifying information. The participant field is the
pseudonymous code and nothing else.
"""

from __future__ import annotations

import hashlib
import json
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def config_hash(config: dict) -> str:
    """Stable SHA-256 of a configuration.

    Keys are sorted and separators fixed so that two logically identical
    configs written in different key order produce the same hash.
    """
    payload = json.dumps(config, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _git_commit() -> str | None:
    try:
        out = subprocess.run(
            ["git", "rev-parse", "HEAD"], capture_output=True, text=True,
            timeout=2, check=False,
        )
        return out.stdout.strip() or None
    except (OSError, subprocess.SubprocessError):
        return None


def _clock() -> dict[str, float | str]:
    """Describe the session timebase, so reported timings can be trusted."""
    from .core.clock import resolution

    return {
        "source": "time.perf_counter",
        "resolution_us": round(resolution() * 1e6, 3),
    }


def _versions() -> dict[str, str]:
    mods = ["numpy", "scipy", "sklearn", "mne", "brainflow", "yaml", "pandas"]
    out = {"python": sys.version.split()[0], "platform": platform.platform()}
    for name in mods:
        try:
            mod = __import__(name)
            out[name] = getattr(mod, "__version__", "unknown")
        except ImportError:
            continue
    try:
        from . import __version__
        out["neurobridge"] = __version__
    except ImportError:
        pass
    return out


def build_manifest(
    session_id: str,
    participant: str,
    config: dict,
    device: dict,
    pipeline: dict,
    montage: dict | None = None,
    seeds: dict | None = None,
    extra: dict | None = None,
) -> dict[str, Any]:
    return {
        "manifest_version": "1.0",
        "session_id": session_id,
        "participant": participant,
        "created_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "config": config,
        "config_sha256": config_hash(config),
        "device": device,
        "montage_resolution": montage or {},
        "pipeline": pipeline,
        "seeds": seeds or {},
        "environment": _versions(),
        "clock": _clock(),
        "git_commit": _git_commit(),
        **(extra or {}),
    }


def write_manifest(path: str | Path, manifest: dict) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(manifest, indent=2, default=str), encoding="utf-8")
    return p


def diff_manifests(a: dict, b: dict, prefix: str = "") -> list[str]:
    """Human-readable differences between two manifests.

    Used to answer "why did site B get different results" without reading two
    JSON files side by side.
    """
    skip = {"created_utc", "session_id", "participant", "git_commit"}
    out: list[str] = []
    keys = sorted(set(a) | set(b))
    for k in keys:
        if k in skip:
            continue
        av, bv = a.get(k, "<missing>"), b.get(k, "<missing>")
        path = f"{prefix}{k}"
        if isinstance(av, dict) and isinstance(bv, dict):
            out += diff_manifests(av, bv, prefix=f"{path}.")
        elif av != bv:
            out.append(f"{path}: {av!r} != {bv!r}")
    return out
