"""Session: the object that runs everything.

Threading model
---------------
Three threads, chosen so that no slow consumer can delay acquisition:

* **Acquisition** polls the device, applies the stateful causal filter, pushes
  into the ring buffer, and yields completed windows. This thread does the
  least work possible.
* **Processing** takes windows, runs the pipeline, computes quality, and hands
  results to the transport. If it falls behind, the ring buffer absorbs it and
  the sliding window skips ahead rather than emitting stale epochs.
* **Transport** (inside ``WebSocketServer``) owns one writer thread per client,
  each with a bounded queue, so a stalled browser tab cannot block processing.

Acquisition and processing are separated by a queue with a *small* bound. A
large buffer here would hide overload instead of reporting it, and the whole
point of this system is that overload is measured.

Everything the session does is recorded: every window's latency, every dropped
message, every quality warning, every learning event, on one clock.
"""

from __future__ import annotations

import logging
import queue
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Callable

import numpy as np

from .config import Config
from .core.buffer import SlidingWindow
from .core.montage import Montage
from .core.types import Epoch, Prediction
from .education.adaptive import DifficultyController, EngagementModulator, KnowledgeTracer
from .education.events import EventLog
from .education.lessons import Curriculum
from .process.filters import StreamFilter
from .process.quality import QualityMonitor
from .reproducibility import build_manifest, write_manifest
from .transport.metrics import Metrics
from .transport.protocol import Calibration, Hello, Lesson, Metrics as MetricsMsg
from .transport.protocol import Neuro, Quality as QualityMsg
from .transport.websocket import WebSocketServer
from .core.clock import now

log = logging.getLogger("neurobridge.session")


class Session:
    """One recording + teaching session.

    Args:
        config: a :class:`Config`, a dict, or a path to YAML/JSON.
        source: an already-constructed :class:`Source`; if omitted it is built
            from the config.
        on_prediction: optional callback for every decoded window, called on
            the processing thread.
    """

    def __init__(
        self,
        config: Config | dict | str | Path,
        source: Any | None = None,
        on_prediction: Callable[[Prediction, Epoch], None] | None = None,
        session_id: str | None = None,
    ) -> None:
        if isinstance(config, (str, Path)):
            config = Config.from_file(config)
        elif isinstance(config, dict):
            config = Config.from_dict(config)
        self.config: Config = config

        self.session_id = session_id or uuid.uuid4().hex[:12]
        self.participant = self.config.get("session.participant", "SCH-0000")
        self.on_prediction = on_prediction

        self.source = source or self.config.build_source()
        self.metrics = Metrics()
        self.quality_monitor = QualityMonitor(
            mains=float(self.config.get("session.mains", 60.0))
        )

        self.server: WebSocketServer | None = None
        self.events: EventLog | None = None
        self.pipeline = None
        self.window: SlidingWindow | None = None
        self.filter: StreamFilter | None = None

        # Education state
        self.curriculum = Curriculum(
            grade_band=self.config.get("education.grade_band", "9-12")
        )
        self.tracer = KnowledgeTracer()
        self.difficulty = DifficultyController(
            target=float(self.config.get("education.target_success", 0.75))
        )
        self.modulator = EngagementModulator()

        self._epochs: queue.Queue = queue.Queue(maxsize=8)
        self._running = False
        self._threads: list[threading.Thread] = []
        self._latest: Prediction | None = None
        self._latest_quality: dict = {}
        self._calibrator = None
        self._calib_label: str | None = None
        self.out_dir = Path(self.config.get("logging.dir", "sessions")) / self.session_id

    # -- lifecycle ---------------------------------------------------------

    def start(self, serve: bool = True) -> "Session":
        self.source.start()
        device = self.source.device

        montage_report = self.config.validate_against_device(device)
        self.pipeline = self.config.build_pipeline(device)

        pre = self.config["preprocess"]
        self.filter = StreamFilter(
            sfreq=device.sfreq, n_channels=device.n_channels,
            l_freq=pre.get("l_freq"), h_freq=pre.get("h_freq"),
            notch=pre.get("notch"), order=pre.get("order", 4),
        )

        ep = self.config["epoching"]
        self.window = SlidingWindow(device, window=ep["window"], step=ep["step"],
                                    history=ep.get("history"))

        self.metrics.budget.window = ep["window"]
        self.metrics.budget.step = ep["step"]
        self.metrics.budget.filter_group_delay = self.filter.group_delay_s

        self.out_dir.mkdir(parents=True, exist_ok=True)
        self.events = EventLog(self.out_dir / "events.jsonl", self.participant)

        manifest = build_manifest(
            session_id=self.session_id,
            participant=self.participant,
            config=self.config.to_dict(),
            device={"name": device.name, "sfreq": device.sfreq,
                    "channels": list(device.ch_names)},
            pipeline=self.pipeline.describe(),
            montage=montage_report,
            extra={"latency_budget": self.metrics.budget.to_dict(),
                   "curriculum": self.curriculum.to_dict()},
        )
        write_manifest(self.out_dir / "manifest.json", manifest)
        self.events.log("session_start", {
            "session_id": self.session_id,
            "device": device.name,
            "paradigm": self.config.get("session.paradigm"),
            "config_sha256": manifest["config_sha256"],
        })

        if serve:
            t = self.config["transport"]
            self.server = WebSocketServer(
                host=t["host"], port=t["port"], queue_size=t.get("queue_size", 64),
                on_message=self._on_message, on_connect=self._on_connect,
            )
            self.server.start()

        self._running = True
        for target, name in ((self._acquire_loop, "acquire"),
                             (self._process_loop, "process")):
            th = threading.Thread(target=target, daemon=True, name=name)
            th.start()
            self._threads.append(th)
        return self

    def stop(self) -> None:
        self._running = False
        for th in self._threads:
            th.join(timeout=2.0)
        self._threads.clear()
        try:
            self.source.stop()
        except Exception:
            log.exception("error stopping source")
        if self.events:
            self.events.log("session_end", {
                "metrics": self.metrics.snapshot(),
                "knowledge": self.tracer.to_dict(),
                "difficulty": self.difficulty.to_dict(),
            })
            self.events.close()
        if self.server:
            self.server.stop()
        log.info("session %s finished: %s", self.session_id, self.metrics.report())

    def __enter__(self) -> "Session":
        return self.start()

    def __exit__(self, *exc: Any) -> None:
        self.stop()

    # -- threads -----------------------------------------------------------

    def _acquire_loop(self) -> None:
        while self._running:
            try:
                chunk = self.source.read()
            except Exception:
                log.exception("acquisition failed")
                break
            if chunk is None:
                time.sleep(0.005)
                continue
            chunk.data = self.filter(chunk.data)
            for epoch in self.window.push(chunk):
                try:
                    self._epochs.put_nowait(epoch)
                except queue.Full:
                    # Processing is behind. Drop the OLDEST epoch: a stale
                    # window is worthless as a control signal, and counting the
                    # drop is more honest than growing an unbounded backlog.
                    try:
                        self._epochs.get_nowait()
                        self.metrics.dropped_by_backpressure += 1
                        self._epochs.put_nowait(epoch)
                    except (queue.Empty, queue.Full):
                        self.metrics.dropped_by_backpressure += 1

    def _process_loop(self) -> None:
        n = 0
        while self._running:
            try:
                epoch = self._epochs.get(timeout=0.2)
            except queue.Empty:
                continue
            t0 = now()
            try:
                pred = self.pipeline(epoch)
            except Exception:
                log.exception("pipeline failed on one window; continuing")
                continue

            n += 1
            self.metrics.record_epoch(epoch.t_start, pred.t_emit, t0)

            # Quality is computed on a slower schedule; it is far more
            # expensive than the pipeline and does not need to run every window.
            if n % max(1, int(1.0 / self.config["epoching"]["step"])) == 0:
                qs = self.quality_monitor(epoch.data, epoch.sfreq, epoch.ch_names)
                self._latest_quality = self.quality_monitor.summary(qs)
                if self.server:
                    self.server.broadcast(QualityMsg(
                        mean_score=self._latest_quality["mean_score"],
                        per_channel=self._latest_quality["per_channel"],
                        advice=self._latest_quality["advice"],
                    ))
                if self._latest_quality["mean_score"] < 0.5 and self.events:
                    self.events.log("quality_warning", self._latest_quality)

            pred.quality = self._latest_quality.get("per_channel", {})
            self._latest = pred

            if self._calibrator is not None and self._calib_label:
                self._calibrator.add(epoch, self._calib_label)

            mean_q = self._latest_quality.get("mean_score", 1.0)
            eng = pred.features.get("engagement")
            if eng is not None:
                state = self.modulator.update(eng, mean_q)
                if state["action"] != "none" and self.events:
                    self.events.log("engagement_state", state)

            if self.server:
                tier = self.config.get("session.privacy_tier", "derived")
                feats = pred.features if tier in ("features", "raw") else {}
                self.server.broadcast(Neuro(
                    value=pred.value, confidence=round(pred.confidence, 4),
                    features={k: round(float(v), 5) for k, v in feats.items()},
                    quality=mean_q, reject=bool(epoch.meta.get("reject", False)),
                    t_epoch=round(epoch.t_start, 6),
                    latency_ms=round(pred.latency * 1000.0, 2),
                ))
                self.metrics.dropped_by_backpressure = (
                    self.metrics.dropped_by_backpressure + 0
                )

            if self.on_prediction:
                try:
                    self.on_prediction(pred, epoch)
                except Exception:
                    log.exception("on_prediction callback raised")

            if n % 40 == 0 and self.server:
                snap = self.metrics.snapshot()
                self.server.broadcast(MetricsMsg(
                    latency_ms_p50=snap["latency_ms_p50"],
                    latency_ms_p95=snap["latency_ms_p95"],
                    jitter_ms=snap["jitter_ms"], loss_rate=snap["loss_rate"],
                    dropped_messages=self.server.dropped,
                ))

    # -- transport handlers ------------------------------------------------

    def _on_connect(self, client) -> None:
        device = self.source.device
        client.send(Hello(
            device=device.name, sfreq=device.sfreq,
            channels=list(device.ch_names),
            montage=Montage(device.ch_names).report(),
            paradigm=self.config.get("session.paradigm", ""),
            privacy_tier=self.config.get("session.privacy_tier", "derived"),
            window=self.config["epoching"]["window"],
            step=self.config["epoching"]["step"],
            session_id=self.session_id,
        ).to_json(), "hello")

    def _on_message(self, client, msg: dict) -> None:
        kind = msg["type"]
        if kind == "echo":
            self.metrics.record_rtt(now() - float(msg["t_client"]))
            return
        if kind == "learning":
            self._handle_learning(msg["event"])
            return
        if kind == "game" and self.events:
            self.events.log("level_complete" if msg["state"].get("complete")
                            else "game_start", msg["state"])
            self.metrics.record_frame()
            return
        if kind == "ready":
            self._push_lesson()
            return
        if kind == "control":
            self._handle_control(client, msg)

    def _handle_learning(self, ev: dict) -> None:
        kind = ev.get("kind")
        neuro = {}
        if self._latest:
            neuro = {k: round(float(v), 5)
                     for k, v in self._latest.features.items()}
            neuro["confidence"] = round(self._latest.confidence, 4)
            neuro["quality"] = self._latest_quality.get("mean_score", float("nan"))

        if kind == "response" and self.events:
            concept = ev.get("concept_id", "unknown")
            # Grade here, not in the browser. A client-reported 'correct' flag
            # is a self-assessment, and any student who opens the console can
            # set it. The item is looked up in the curriculum the server owns.
            item = self._find_item(concept, ev.get("question_id", ""))
            if item is not None:
                correct = item.check(ev.get("answer", -1))
                item_b = item.difficulty
                verdict = {"question_id": item.item_id, "correct": correct,
                           "correct_option": item.answer,
                           "explanation": item.explanation}
            else:
                correct = bool(ev.get("correct"))
                item_b = float(ev.get("item_difficulty", 0.0))
                verdict = {"question_id": ev.get("question_id", ""),
                           "correct": correct, "explanation": ""}
            self.tracer.update(concept, correct, item_b)
            d = self.difficulty.update(correct)
            self.events.response(
                concept_id=concept, question_id=ev.get("question_id", ""),
                correct=correct, rt_ms=float(ev.get("rt_ms", 0.0)),
                answer=ev.get("answer"), difficulty=d, neuro=neuro,
            )
            self._push_lesson(feedback=verdict)
        elif self.events:
            self.events.log(
                kind if kind in {"concept_shown", "question_shown", "hint_used"}
                else "note", ev, neuro=neuro,
            )

    def _find_item(self, concept_id: str, item_id: str):
        """Look up a curriculum item by id, tolerating an unknown concept."""
        concept = self.curriculum.concepts.get(concept_id)
        pools = [concept] if concept else list(self.curriculum.concepts.values())
        for c in pools:
            for it in c.items:
                if it.item_id == item_id:
                    return it
        return None

    def _handle_control(self, client, msg: dict) -> None:
        action = msg["action"]
        if action == "calibrate":
            self.start_calibration(msg.get("paradigm"))
        elif action == "set_privacy":
            tier = msg.get("tier", "derived")
            if tier in ("derived", "features"):
                self.config.data["session"]["privacy_tier"] = tier
                if self.events:
                    self.events.log("note", {"privacy_tier": tier})
            # 'raw' is deliberately not settable from the browser.
        elif action == "calibration_block":
            self.set_calibration_label(msg.get("label"))
        elif action == "calibration_finish":
            try:
                self.finish_calibration()
            except RuntimeError as exc:
                log.warning("calibration_finish ignored: %s", exc)
        elif action == "stop":
            self._running = False

    # -- calibration -------------------------------------------------------

    def start_calibration(self, paradigm: str | None = None) -> None:
        from .classify.calibration import Calibrator

        paradigm = paradigm or self.config.get("session.paradigm", "alpha")
        extractor = self.pipeline.extractor
        if extractor is None:
            raise RuntimeError("calibration needs an extractor in the pipeline")
        self._calibrator = Calibrator(paradigm, extractor)
        if self.events:
            self.events.log("calibration_start", {"paradigm": paradigm})
        if self.server:
            self.server.broadcast(Calibration(
                phase="running", progress=0.0,
                instruction="Get comfortable and look at the screen.",
                blocks=[{"label": b.label, "instruction": b.instruction,
                         "duration": b.duration, "cue": b.cue}
                        for b in self._calibrator.blocks],
            ))

    def set_calibration_label(self, label: str | None) -> None:
        """Called by the front end as each instructed block begins."""
        self._calib_label = label
        if self.events and label:
            self.events.log("calibration_block", {"label": label})

    def finish_calibration(self) -> dict:
        if self._calibrator is None:
            raise RuntimeError("no calibration in progress")
        result = self._calibrator.fit(quality=self._latest_quality)
        self._calibrator, self._calib_label = None, None
        if self.events:
            self.events.log("calibration_result", result.to_dict())
            if result.status == "fallback":
                self.events.deviation("calibration below chance",
                                      {"accuracy": result.accuracy})
        if self.server:
            self.server.broadcast(Calibration(
                phase="done", progress=1.0, result=result.to_dict(),
                message=result.message(),
            ))
        return result.to_dict()

    def _push_lesson(self, feedback: dict | None = None) -> None:
        """Send the current concept and one item sized to the student's ability."""
        if not self.server:
            return
        cid = self.curriculum.next_concept(self.tracer)
        if cid is None:
            return
        c = self.curriculum.concepts[cid]
        item = self.curriculum.next_item(cid, self.tracer, self.difficulty.d)
        self.server.broadcast(Lesson(
            concept_id=cid, title=c.title, body=c.summary,
            difficulty=round(self.difficulty.d, 3),
            prompt={"item_id": item.item_id, "prompt": item.prompt,
                    "options": item.options,
                    "item_difficulty": item.difficulty,
                    "activity": c.activity},
            feedback=feedback,
            mastery={k: round(v.mastery, 3)
                     for k, v in self.tracer.states.items()},
        ))

    # -- introspection -----------------------------------------------------

    @property
    def latest(self) -> Prediction | None:
        return self._latest

    def report(self) -> dict:
        return {
            "session_id": self.session_id,
            "metrics": self.metrics.snapshot(),
            "quality": self._latest_quality,
            "knowledge": self.tracer.to_dict(),
            "difficulty": self.difficulty.to_dict(),
            "clients": self.server.n_clients if self.server else 0,
            "dropped_epochs": self.metrics.dropped_by_backpressure,
            "dropped_chunks": self.window.dropped_chunks if self.window else 0,
        }
