"""Adaptive difficulty and knowledge tracing.

Two estimators, both stated explicitly rather than hand-tuned, because "the
game got harder when the student did well" is not a method section.

1. **Difficulty control** is a stochastic root-finding problem: find the
   difficulty ``d`` at which the student's success probability equals a target
   ``p*``. Robbins-Monro solves exactly this from binary outcomes::

       d_{n+1} = clip( d_n + a_n * (y_n - p*) ,  0, 1 )
       a_n     = c / (n_0 + n)^gamma

   With ``gamma`` in (0.5, 1] the step sizes satisfy ``sum a_n = inf`` and
   ``sum a_n^2 < inf``, the classical conditions under which the iterate
   converges to the root. A floor is placed under ``a_n`` because the target is
   *non-stationary* -- the student is learning, which moves the root -- and a
   step size decaying to zero would freeze the difficulty at whatever the
   student's ability was ten minutes ago.

   ``p*`` defaults to 0.75: high enough to stay motivating, low enough to keep
   the task inside the zone of proximal development rather than at ceiling.

2. **Knowledge tracing** uses the one-parameter logistic (Rasch) model::

       P(correct | theta, b) = sigmoid(theta - b)

   updated online by gradient ascent on the log-likelihood::

       theta <- theta + eta * (y - P)

   which is the same update rule as the Elo rating system, arrived at from the
   likelihood rather than by analogy. ``theta`` is the student's ability on a
   concept in logits and ``b`` is item difficulty; both are on an interpretable
   scale where a one-logit gap means roughly 73% success odds.

An important separation: EEG-derived engagement modulates *presentation*
(pacing, prompts, encouragement) and difficulty modulates *task demand* from
behavioural correctness. Letting a noisy neural index directly set task
difficulty would make the difficulty trace a function of electrode contact,
which is neither defensible nor reproducible.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field


def sigmoid(x: float) -> float:
    # Numerically stable for large |x|.
    if x >= 0:
        z = math.exp(-x)
        return 1.0 / (1.0 + z)
    z = math.exp(x)
    return z / (1.0 + z)


class DifficultyController:
    """Robbins-Monro controller targeting a fixed success probability.

    Args:
        target: desired success probability ``p*`` in (0, 1).
        d0: initial difficulty in [0, 1].
        c: step-size scale. Larger adapts faster and oscillates more.
        gamma: step-size decay exponent; must lie in (0.5, 1].
        n0: offset that softens the first few, very large, steps.
        min_step: floor on ``a_n`` so the controller keeps tracking a moving
            root instead of converging and freezing.
        bounds: hard limits on difficulty.
    """

    def __init__(
        self,
        target: float = 0.75,
        d0: float = 0.4,
        c: float = 0.6,
        gamma: float = 0.7,
        n0: int = 4,
        min_step: float = 0.02,
        bounds: tuple[float, float] = (0.0, 1.0),
    ) -> None:
        if not 0.0 < target < 1.0:
            raise ValueError("target success probability must be in (0, 1)")
        if not 0.5 < gamma <= 1.0:
            raise ValueError(
                "gamma must be in (0.5, 1] for the Robbins-Monro conditions "
                "sum(a_n)=inf and sum(a_n^2)<inf to hold"
            )
        self.target, self.c, self.gamma, self.n0 = target, c, gamma, n0
        self.min_step, self.bounds = min_step, bounds
        self.d = float(min(max(d0, bounds[0]), bounds[1]))
        self.n = 0
        self.history: list[tuple[int, float, int]] = []

    def step_size(self) -> float:
        return max(self.min_step, self.c / (self.n0 + self.n) ** self.gamma)

    def update(self, success: bool) -> float:
        """Feed one trial outcome; returns the new difficulty."""
        y = 1.0 if success else 0.0
        a = self.step_size()
        self.d = float(min(max(self.d + a * (y - self.target),
                               self.bounds[0]), self.bounds[1]))
        self.n += 1
        self.history.append((self.n, round(self.d, 4), int(y)))
        return self.d

    @property
    def observed_rate(self) -> float:
        if not self.history:
            return float("nan")
        return sum(h[2] for h in self.history) / len(self.history)

    def to_dict(self) -> dict:
        return {
            "difficulty": round(self.d, 4),
            "target": self.target,
            "n_trials": self.n,
            "observed_success_rate": round(self.observed_rate, 4)
            if self.history else None,
            "step_size": round(self.step_size(), 4),
        }


@dataclass
class ConceptState:
    """Rasch ability estimate for one concept."""

    concept_id: str
    theta: float = 0.0             # ability in logits
    n_attempts: int = 0
    n_correct: int = 0
    history: list[float] = field(default_factory=list)

    @property
    def mastery(self) -> float:
        """Probability of answering an average-difficulty item correctly."""
        return sigmoid(self.theta)

    @property
    def raw_accuracy(self) -> float:
        return self.n_correct / self.n_attempts if self.n_attempts else float("nan")


class KnowledgeTracer:
    """Online Rasch estimation of per-concept ability.

    Args:
        eta: learning rate for the gradient step. 0.4 gives a responsive
            estimate over the 10-20 items a single lesson affords; smaller
            values are appropriate for longer sequences.
        prior_theta: starting ability, in logits. Zero means "expected to get a
            median-difficulty item right half the time".
    """

    def __init__(self, eta: float = 0.4, prior_theta: float = 0.0) -> None:
        self.eta, self.prior_theta = eta, prior_theta
        self.states: dict[str, ConceptState] = {}

    def state(self, concept_id: str) -> ConceptState:
        if concept_id not in self.states:
            self.states[concept_id] = ConceptState(concept_id, self.prior_theta)
        return self.states[concept_id]

    def update(self, concept_id: str, correct: bool,
               item_difficulty: float = 0.0) -> ConceptState:
        """One graded response. ``item_difficulty`` is ``b``, in logits."""
        s = self.state(concept_id)
        p = sigmoid(s.theta - item_difficulty)
        y = 1.0 if correct else 0.0
        s.theta += self.eta * (y - p)
        s.n_attempts += 1
        s.n_correct += int(correct)
        s.history.append(round(s.theta, 4))
        return s

    def expected_correct(self, concept_id: str, item_difficulty: float = 0.0) -> float:
        return sigmoid(self.state(concept_id).theta - item_difficulty)

    def mastered(self, concept_id: str, threshold: float = 0.8,
                 min_attempts: int = 3) -> bool:
        """Mastery requires both a high estimate and enough evidence for it.

        The attempt floor matters: after one lucky answer the Rasch estimate can
        cross any threshold, and a curriculum that advances on that will march
        a student past material they have not learned.

        Read-only: querying an unseen concept does not create a state for it,
        so the exported knowledge map contains only concepts actually attempted
        rather than every concept the sequencer happened to look at.
        """
        s = self.states.get(concept_id)
        if s is None:
            return False
        return s.n_attempts >= min_attempts and s.mastery >= threshold

    def to_dict(self) -> dict:
        return {
            cid: {
                "theta": round(s.theta, 4),
                "mastery": round(s.mastery, 4),
                "attempts": s.n_attempts,
                "correct": s.n_correct,
            }
            for cid, s in self.states.items()
        }


class EngagementModulator:
    """Turns a neural engagement index into *presentation* choices.

    Deliberately limited: it can prompt, encourage, offer a break, or slow the
    pace. It cannot change task difficulty or scoring, so no reported learning
    outcome depends on signal quality.

    The decision uses a within-session z-score against the student's own
    running mean and variance (Welford's online algorithm), because absolute
    engagement values are not comparable between people or between headsets.
    """

    def __init__(self, low_z: float = -1.0, high_z: float = 1.0,
                 min_samples: int = 20, dwell: int = 8) -> None:
        self.low_z, self.high_z = low_z, high_z
        self.min_samples, self.dwell = min_samples, dwell
        self._n = 0
        self._mean = 0.0
        self._m2 = 0.0
        self._streak = 0
        self._last_state = "neutral"

    def _welford(self, x: float) -> None:
        self._n += 1
        delta = x - self._mean
        self._mean += delta / self._n
        self._m2 += delta * (x - self._mean)

    @property
    def sd(self) -> float:
        return math.sqrt(self._m2 / (self._n - 1)) if self._n > 1 else 0.0

    def update(self, engagement: float, quality: float = 1.0) -> dict:
        """Returns a presentation recommendation and the z-score behind it."""
        if not math.isfinite(engagement) or quality < 0.5:
            # Low-quality signal produces no recommendation at all, rather than
            # a recommendation derived from noise.
            return {"state": "unknown", "z": float("nan"), "action": "none",
                    "reason": "signal quality too low to interpret"}

        self._welford(engagement)
        if self._n < self.min_samples or self.sd == 0:
            return {"state": "calibrating", "z": float("nan"), "action": "none",
                    "reason": f"building baseline ({self._n}/{self.min_samples})"}

        z = (engagement - self._mean) / self.sd
        state = "low" if z <= self.low_z else "high" if z >= self.high_z else "neutral"
        self._streak = self._streak + 1 if state == self._last_state else 1
        self._last_state = state

        action = "none"
        if self._streak >= self.dwell:
            if state == "low":
                action = "prompt_break"
            elif state == "high":
                action = "extend_challenge"

        return {"state": state, "z": round(z, 3), "action": action,
                "streak": self._streak, "baseline_mean": round(self._mean, 4),
                "baseline_sd": round(self.sd, 4)}
