"""Learning event log.

This is the module that connects the three literatures your review says never
meet. The EEG stack produces a neural time series; the game produces a
behavioural time series; the curriculum produces a pedagogical time series. If
they are recorded separately with separate clocks, the education analysis can
only correlate summary statistics -- which is why existing school studies report
pre/post gains and little else.

Here all three are written to one append-only JSONL file with one monotonic
clock, so an analysis can ask questions that current work cannot: what were the
band powers in the eight seconds before a wrong answer; does engagement drop
before the behavioural signs of disengagement appear; does adaptive difficulty
change the neural response to error.

Format
------
One JSON object per line, written and flushed immediately. JSONL is used
deliberately over a database or a pickle: a truncated file from a crashed
session is still fully readable up to the last complete line, and a teacher can
open it in a text editor. Every record carries ``t`` (monotonic seconds since
session start) and ``wall`` (UTC ISO-8601) so records can be aligned within a
session and ordered across sessions.

Privacy
-------
No name, no date of birth, no free-text that could identify a child. The only
identifier is a pseudonymous participant code supplied by the study, and the
mapping from code to child stays outside this system entirely -- on paper, in a
locked drawer, which is the only place it belongs.
"""

from __future__ import annotations

import json
import re
import threading
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator
from ..core.clock import now

#: Event kinds the analysis code knows how to interpret.
KINDS = {
    "session_start", "session_end",
    "calibration_start", "calibration_block", "calibration_result",
    "concept_shown", "question_shown", "response", "hint_used",
    "difficulty_change", "engagement_state",
    "game_start", "game_end", "level_complete",
    "quality_warning", "protocol_deviation", "note",
}

_PSEUDONYM_RE = re.compile(r"^[A-Z]{2,4}-\d{3,5}$")

#: Keys that must never appear in an event payload.
_FORBIDDEN_KEYS = {
    "name", "first_name", "last_name", "surname", "email", "dob",
    "date_of_birth", "address", "phone", "student_name", "photo", "ip",
}


class PrivacyViolation(ValueError):
    """Raised when an event would write identifying information."""


@dataclass
class LearningEvent:
    kind: str
    t: float
    wall: str
    participant: str
    payload: dict[str, Any] = field(default_factory=dict)
    neuro: dict[str, float] = field(default_factory=dict)

    def to_json(self) -> str:
        return json.dumps(asdict(self), separators=(",", ":"), default=str)


class EventLog:
    """Append-only, thread-safe, privacy-checked session log.

    Args:
        path: destination ``.jsonl`` file.
        participant: pseudonymous code, e.g. ``"SCH-0142"``. Validated against a
            strict pattern so a real name cannot be passed in by accident --
            the mistake is easy to make and impossible to undo once the file
            is written.
        t0: monotonic origin shared with the transport layer.
    """

    def __init__(self, path: str | Path, participant: str,
                 t0: float | None = None, strict: bool = True) -> None:
        if strict and not _PSEUDONYM_RE.match(participant):
            raise PrivacyViolation(
                f"participant code {participant!r} does not look like a "
                f"pseudonymous ID (expected e.g. 'SCH-0142'). Never use names."
            )
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.participant = participant
        self.t0 = t0 if t0 is not None else now()
        self._lock = threading.Lock()
        self._fh = self.path.open("a", encoding="utf-8")
        self.n_events = 0

    # -- writing -----------------------------------------------------------

    def log(self, kind: str, payload: dict[str, Any] | None = None,
            neuro: dict[str, float] | None = None,
            t: float | None = None) -> LearningEvent:
        if kind not in KINDS:
            raise ValueError(f"unknown event kind {kind!r}; known: {sorted(KINDS)}")
        payload = dict(payload or {})
        self._check_privacy(payload)

        ev = LearningEvent(
            kind=kind,
            t=round((t if t is not None else now()) - self.t0, 6),
            wall=datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
            participant=self.participant,
            payload=payload,
            neuro=dict(neuro or {}),
        )
        with self._lock:
            self._fh.write(ev.to_json() + "\n")
            self._fh.flush()          # crash-safe: never lose the last minutes
            self.n_events += 1
        return ev

    @staticmethod
    def _check_privacy(payload: dict[str, Any]) -> None:
        def walk(d: Any, path: str = "") -> None:
            if isinstance(d, dict):
                for k, v in d.items():
                    if str(k).lower() in _FORBIDDEN_KEYS:
                        raise PrivacyViolation(
                            f"event payload contains identifying key "
                            f"{path}{k!r}. Log a pseudonymous code instead."
                        )
                    walk(v, f"{path}{k}.")
            elif isinstance(d, (list, tuple)):
                for item in d:
                    walk(item, path)

        walk(payload)

    # -- convenience wrappers ---------------------------------------------

    def response(self, concept_id: str, question_id: str, correct: bool,
                 rt_ms: float, answer: Any = None, difficulty: float | None = None,
                 neuro: dict[str, float] | None = None) -> LearningEvent:
        """Log a graded answer with the neural snapshot that preceded it."""
        return self.log("response", {
            "concept_id": concept_id, "question_id": question_id,
            "correct": bool(correct), "rt_ms": round(float(rt_ms), 1),
            "answer": answer, "difficulty": difficulty,
        }, neuro=neuro)

    def deviation(self, reason: str, detail: dict | None = None) -> LearningEvent:
        """Record a protocol deviation. Every study has them; few record them."""
        return self.log("protocol_deviation",
                        {"reason": reason, **(detail or {})})

    def close(self) -> None:
        with self._lock:
            if not self._fh.closed:
                self._fh.close()

    def __enter__(self) -> "EventLog":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    # -- reading -----------------------------------------------------------

    @staticmethod
    def read(path: str | Path) -> Iterator[LearningEvent]:
        """Stream events back, skipping a truncated final line if present."""
        with Path(path).open(encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    d = json.loads(line)
                except json.JSONDecodeError:
                    continue                 # truncated tail from a crash
                yield LearningEvent(**d)

    @staticmethod
    def to_table(path: str | Path):
        """Load into a pandas DataFrame with payload keys flattened to columns."""
        import pandas as pd

        rows = []
        for ev in EventLog.read(path):
            row = {"kind": ev.kind, "t": ev.t, "wall": ev.wall,
                   "participant": ev.participant}
            row.update({f"p_{k}": v for k, v in ev.payload.items()})
            row.update({f"n_{k}": v for k, v in ev.neuro.items()})
            rows.append(row)
        return pd.DataFrame(rows)


def align_neuro_window(events: list[LearningEvent], t_event: float,
                       lookback: float = 8.0) -> list[LearningEvent]:
    """Return the neural events in the ``lookback`` seconds before ``t_event``.

    The primitive the education analysis is built on: give it the timestamp of
    a wrong answer and it hands back the neural state leading up to it.
    """
    return [e for e in events
            if e.neuro and t_event - lookback <= e.t <= t_event]
