"""Curriculum, knowledge tracing and event logging."""
