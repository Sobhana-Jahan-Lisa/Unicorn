"""Curriculum: a prerequisite graph of BCI concepts, with assessment items.

Why the curriculum lives in the package
---------------------------------------
If the lesson content sits in the game's JavaScript, then every replication has
to rebuild it, and no two studies teach the same thing. Putting the concept
graph, the items, and their difficulties in the Python package makes the
*intervention itself* installable and versionable: another group can
``pip install`` it, run the identical curriculum on different hardware, and
compare results. That is the reproducibility gap in education technology, not
just the analysis gap.

Item difficulties ``b`` are on the Rasch logit scale used by
``education.adaptive.KnowledgeTracer``. The values shipped here are *prior*
estimates from a pilot; the whole point of logging responses is that they can
be re-estimated from data, and ``calibrate_difficulties`` does exactly that.
Treat the shipped numbers as a starting point to be replaced, and say so in the
paper.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any


@dataclass
class Item:
    """One assessment item."""

    item_id: str
    concept_id: str
    prompt: str
    options: list[str]
    answer: int                       # index into options
    difficulty: float = 0.0           # Rasch b, in logits
    explanation: str = ""

    def check(self, choice: int) -> bool:
        return int(choice) == self.answer


@dataclass
class Concept:
    """One node in the curriculum graph."""

    concept_id: str
    title: str
    grade_band: str                   # 'K-2', '3-5', '6-8', '9-12'
    summary: str
    prerequisites: tuple[str, ...] = ()
    activity: str = ""                # what the student does in the game
    items: list[Item] = field(default_factory=list)


def _c(cid, title, band, summary, prereqs, activity, items) -> Concept:
    return Concept(cid, title, band, summary, tuple(prereqs), activity,
                   [Item(f"{cid}-{i}", cid, *it) for i, it in enumerate(items, 1)])


#: The default curriculum. Twelve concepts spanning the arc of a BCI course:
#: signal origin -> acquisition -> processing -> decoding -> feedback -> ethics.
CURRICULUM: dict[str, Concept] = {c.concept_id: c for c in [
    _c("neurons", "Your Brain Makes Electricity", "3-5",
       "Brain cells send tiny electrical signals to each other. When many cells "
       "fire together, the signal is big enough to measure from outside the head.",
       [], "Watch the raw trace move while you clench your jaw and then relax.",
       [("What are we measuring with an EEG headset?",
         ["Electricity made by brain cells", "The temperature of the brain",
          "Blood moving in the brain", "Sounds inside the head"], 0, -1.2,
         "EEG measures tiny voltages produced when groups of neurons fire together."),
        ("Why do many brain cells need to fire together to be measured?",
         ["One cell's signal is far too small to detect at the scalp",
          "Brain cells only work in groups",
          "The skull blocks single signals but not groups",
          "Machines cannot measure fast signals"], 0, 0.4,
         "A single neuron's field is far too small at the scalp; summed activity is not.")]),

    _c("electrodes", "Electrodes and Contact", "3-5",
       "Electrodes sit on the scalp and pick up voltage. If one is not touching "
       "properly, it records noise instead of brain activity.",
       ["neurons"], "Use the signal-quality display to find and fix a bad electrode.",
       [("An electrode's quality bar turns red. What is the most likely reason?",
         ["It is not making good contact with the scalp",
          "The brain has stopped working", "The computer is too slow",
          "The room is too bright"], 0, -0.8,
         "Red almost always means contact, not cortex."),
        ("Why is the reference electrode important?",
         ["Voltage is always measured as a difference between two points",
          "It powers the headset", "It stores the data",
          "It blocks radio signals"], 0, 0.8,
         "There is no such thing as an absolute voltage; every EEG channel is a difference.")]),

    _c("sampling", "Taking Snapshots of a Signal", "6-8",
       "A computer cannot record a smooth wave. It takes rapid snapshots. The "
       "number of snapshots per second is the sampling rate.",
       ["electrodes"], "Slow the sampling rate down and watch a wave fall apart.",
       [("Our headset samples at 250 Hz. What does that mean?",
         ["It takes 250 measurements every second",
          "It records for 250 seconds", "It uses 250 electrodes",
          "It measures 250 microvolts"], 0, -0.6,
         "Hertz means times per second."),
        ("To see a 40 Hz wave clearly, the sampling rate must be at least...",
         ["80 Hz", "40 Hz", "20 Hz", "400 Hz"], 0, 1.2,
         "Nyquist: you need more than two samples per cycle, so above 80 Hz.")]),

    _c("noise", "Signal and Noise", "6-8",
       "Blinks, jaw clenches, movement and electrical wiring all add unwanted "
       "signal. Telling brain activity from artefact is most of the work.",
       ["electrodes"], "Blink deliberately and watch the artefact detector catch it.",
       [("You blink hard and the trace jumps. Is that brain activity?",
         ["No, it is an artefact from the eye muscles",
          "Yes, blinking is a brain wave", "It is the reference electrode",
          "It is the sampling rate changing"], 0, -0.5,
         "Eye movement produces voltages far larger than cortical rhythms."),
        ("Why do we filter out 50 or 60 Hz?",
         ["That is the frequency of building electrical wiring",
          "The brain never makes those frequencies",
          "It makes the file smaller", "It speeds up the computer"], 0, 0.6,
         "Mains hum couples into every recording; the frequency depends on the country.")]),

    _c("rhythms", "Brain Rhythms", "6-8",
       "Brain activity contains repeating waves at different speeds. They are "
       "grouped into bands: delta, theta, alpha, beta, gamma.",
       ["sampling", "noise"], "Match the live spectrum to the named bands.",
       [("Which band is around 8 to 13 waves per second?",
         ["Alpha", "Delta", "Beta", "Gamma"], 0, -0.3, "Alpha spans 8-13 Hz."),
        ("Alpha waves usually get STRONGER when you...",
         ["Close your eyes and relax", "Solve a hard maths problem",
          "Run on the spot", "Watch a fast video"], 0, 0.0,
         "Posterior alpha increases with eye closure and relaxed wakefulness."),
        ("What happens to alpha when you open your eyes?",
         ["It gets smaller, which is called desynchronisation",
          "It gets bigger", "It changes into delta", "Nothing changes"], 0, 1.0,
         "Eye opening desynchronises the posterior alpha rhythm.")]),

    _c("frequency", "From Waves to Numbers", "9-12",
       "A spectrum shows how much power a signal has at each frequency. Band "
       "power is the area under that curve inside a band.",
       ["rhythms"], "Drag the band edges and watch the computed power change.",
       [("What does the height of the spectrum at 10 Hz tell you?",
         ["How much 10 Hz activity is in the signal",
          "How loud the room is", "How many electrodes are connected",
          "The sampling rate"], 0, 0.2, "Spectral power at that frequency."),
        ("Why do we often use RELATIVE band power instead of absolute?",
         ["It cancels out differences in electrode contact between people",
          "It is easier to compute", "It removes the need for filtering",
          "Absolute power is always wrong"], 0, 1.4,
         "Relative power divides out the unknown per-person gain.")]),

    _c("filtering", "Filters", "9-12",
       "A filter keeps some frequencies and removes others. Real-time filters "
       "can only use the past, so they add a small delay.",
       ["frequency"], "Toggle the band-pass on and off and compare traces.",
       [("A band-pass filter from 1 to 45 Hz will remove...",
         ["Slow drift below 1 Hz and fast noise above 45 Hz",
          "Only blinks", "All brain activity", "Nothing at all"], 0, 0.3,
         "It passes the band and attenuates outside it."),
        ("Why does a real-time filter add delay?",
         ["It can only use samples that have already arrived",
          "The computer is slow", "It has to save the file first",
          "Delay comes from the electrodes"], 0, 1.5,
         "Causality forces a group delay; offline zero-phase filtering does not have this constraint.")]),

    _c("features", "Features", "9-12",
       "A feature is a number that summarises something useful about a window "
       "of signal, like alpha power or the ratio between two bands.",
       ["frequency"], "Build your own feature by choosing channels and a band.",
       [("Why turn a whole second of EEG into a few numbers?",
         ["The numbers capture what matters and are easier to compare",
          "To make the file bigger", "Because computers cannot store waves",
          "To remove the need for electrodes"], 0, 0.1,
         "Feature extraction reduces dimensionality while keeping the discriminative part.")]),

    _c("classification", "Teaching a Computer to Guess", "9-12",
       "A classifier learns from labelled examples. You show it examples of two "
       "brain states, and it learns a rule to tell new ones apart.",
       ["features"], "Record eyes-open and eyes-closed examples, then train live.",
       [("Why do we record examples before the game starts?",
         ["The computer needs labelled examples to learn your pattern",
          "To warm up the headset", "To check the internet",
          "To make the game harder"], 0, -0.2, "That is what calibration is."),
        ("Your classifier is 95% accurate on the examples it trained on but 55% "
         "on new data. What happened?",
         ["It memorised the training examples instead of learning the pattern",
          "The headset broke", "The sampling rate was too high",
          "It needs fewer electrodes"], 0, 1.8,
         "Overfitting; this is why accuracy must be cross-validated.")]),

    _c("feedback", "The Loop", "6-8",
       "In a BCI, your brain changes the game and the game changes your brain. "
       "That two-way loop is what makes it a brain-computer INTERFACE.",
       ["rhythms"], "Play the closed-loop game and watch your own control.",
       [("What makes a system a brain-COMPUTER INTERFACE rather than just a recorder?",
         ["The computer responds to your brain in real time",
          "It uses more than one electrode", "It saves the data to a file",
          "It has a screen"], 0, 0.0, "The defining feature is the closed loop."),
        ("Why does delay matter in a BCI?",
         ["If feedback comes too late you cannot learn to control it",
          "Delay uses more battery", "Delay changes the sampling rate",
          "It does not matter"], 0, 0.9,
         "Learning a control signal depends on tight temporal contingency.")]),

    _c("limits", "What BCIs Cannot Do", "6-8",
       "A BCI does not read thoughts. It recognises a few practised brain "
       "states, and it gets them wrong some of the time.",
       ["feedback"], "Try to make the game do the wrong thing on purpose.",
       [("Can this headset read what you are thinking about?",
         ["No, it can only recognise a few practised patterns",
          "Yes, it reads any thought", "Only if you concentrate hard",
          "Only with more electrodes"], 0, -0.7,
         "Consumer EEG decodes a small number of trained states, not semantic content."),
        ("Your classifier is right 70% of the time. What does that mean?",
         ["It will be wrong about 3 times in every 10",
          "It is broken", "It is perfect", "It will improve on its own"], 0, 0.2,
         "Accuracy is a rate, and the error rate is what the user actually feels.")]),

    _c("ethics", "Whose Brain Data Is It?", "6-8",
       "Brain data is personal. Who can see it, how long it is kept, and what "
       "it could be used for are questions to answer before recording, not after.",
       ["limits"], "Choose the privacy settings for your own session.",
       [("Who should decide what happens to your brain data?",
         ["You, and your parent or guardian", "The company that made the headset",
          "Anyone who asks", "The school computer"], 0, -0.9,
         "Consent and control belong to the person the data came from."),
        ("Our system only sends band powers over the network, not raw EEG. Why?",
         ["It limits what could be learned if the data were intercepted",
          "Raw EEG is too boring", "It makes the game faster",
          "Band powers are more accurate"], 0, 1.1,
         "Data minimisation: send the least that does the job.")]),
]}


class Curriculum:
    """Sequences concepts by prerequisite structure and measured mastery."""

    def __init__(self, concepts: dict[str, Concept] | None = None,
                 grade_band: str | None = None) -> None:
        self.concepts = dict(concepts or CURRICULUM)
        if grade_band:
            keep = self._bands_up_to(grade_band)
            selected = {k for k, v in self.concepts.items() if v.grade_band in keep}
            # Close over prerequisites. A concept in band B whose prerequisite
            # sits in a higher band is a curriculum-design error (caught by
            # _validate below), but closing the set here means a custom
            # curriculum can never be filtered into a broken graph.
            changed = True
            while changed:
                changed = False
                for k in list(selected):
                    for p in self.concepts[k].prerequisites:
                        if p in self.concepts and p not in selected:
                            selected.add(p)
                            changed = True
            self.concepts = {k: v for k, v in self.concepts.items()
                             if k in selected}
        self._validate()

    _BAND_ORDER = ["K-2", "3-5", "6-8", "9-12"]

    def _bands_up_to(self, band: str) -> set[str]:
        if band not in self._BAND_ORDER:
            raise ValueError(f"unknown grade band {band!r}")
        return set(self._BAND_ORDER[: self._BAND_ORDER.index(band) + 1])

    def _validate(self) -> None:
        """Reject a graph with dangling or cyclic prerequisites at construction."""
        for c in self.concepts.values():
            for p in c.prerequisites:
                if p not in self.concepts:
                    raise ValueError(
                        f"concept {c.concept_id!r} requires {p!r}, which is not "
                        f"in this curriculum (grade-band filtering may have "
                        f"removed it)"
                    )
        # A prerequisite must never sit in a higher grade band than the
        # concept that depends on it -- otherwise teaching the lower band in
        # isolation is impossible.
        for c in self.concepts.values():
            ci = self._BAND_ORDER.index(c.grade_band)
            for p in c.prerequisites:
                pi = self._BAND_ORDER.index(self.concepts[p].grade_band)
                if pi > ci:
                    raise ValueError(
                        f"concept {c.concept_id!r} ({c.grade_band}) requires "
                        f"{p!r} from the higher band "
                        f"{self.concepts[p].grade_band}"
                    )

        # Kahn's algorithm; a non-empty remainder means a cycle.
        indeg = {k: len(c.prerequisites) for k, c in self.concepts.items()}
        ready = [k for k, d in indeg.items() if d == 0]
        seen = 0
        while ready:
            k = ready.pop()
            seen += 1
            for other in self.concepts.values():
                if k in other.prerequisites:
                    indeg[other.concept_id] -= 1
                    if indeg[other.concept_id] == 0:
                        ready.append(other.concept_id)
        if seen != len(self.concepts):
            raise ValueError("curriculum prerequisite graph contains a cycle")

    def order(self) -> list[str]:
        """A stable topological order -- the default lesson sequence."""
        indeg = {k: len(c.prerequisites) for k, c in self.concepts.items()}
        out: list[str] = []
        while len(out) < len(self.concepts):
            ready = sorted(k for k, d in indeg.items() if d == 0 and k not in out)
            if not ready:
                break
            k = ready[0]
            out.append(k)
            indeg[k] = -1
            for other in self.concepts.values():
                if k in other.prerequisites and indeg[other.concept_id] > 0:
                    indeg[other.concept_id] -= 1
        return out

    def unlocked(self, tracer, threshold: float = 0.8) -> list[str]:
        """Concepts whose prerequisites are all mastered."""
        return [
            k for k, c in self.concepts.items()
            if all(tracer.mastered(p, threshold) for p in c.prerequisites)
            and not tracer.mastered(k, threshold)
        ]

    def next_concept(self, tracer, threshold: float = 0.8) -> str | None:
        """Pick the next concept: earliest unlocked one in topological order."""
        avail = set(self.unlocked(tracer, threshold))
        for k in self.order():
            if k in avail:
                return k
        return None

    def next_item(self, concept_id: str, tracer, difficulty: float = 0.5) -> Item:
        """Choose the item whose success probability is closest to the target.

        Maximum-information selection under the Rasch model would pick
        ``b = theta`` (p = 0.5). Targeting a higher success probability instead
        trades a little measurement precision for the motivation of a child who
        is not in a psychometrics lab -- a deliberate, stated trade-off.
        """
        c = self.concepts[concept_id]
        if not c.items:
            raise ValueError(f"concept {concept_id!r} has no items")
        theta = tracer.state(concept_id).theta
        target_b = theta - math.log(difficulty / (1 - difficulty)) if 0 < difficulty < 1 else theta
        return min(c.items, key=lambda it: abs(it.difficulty - target_b))

    def to_dict(self) -> dict[str, Any]:
        return {
            k: {"title": c.title, "grade_band": c.grade_band,
                "summary": c.summary, "prerequisites": list(c.prerequisites),
                "activity": c.activity, "n_items": len(c.items)}
            for k, c in self.concepts.items()
        }


def calibrate_difficulties(responses: list[tuple[str, bool]],
                           prior: dict[str, float] | None = None,
                           eta: float = 0.1, epochs: int = 20) -> dict[str, float]:
    """Re-estimate item difficulties ``b`` from pooled pilot responses.

    Joint maximum-likelihood on the Rasch model, alternating between person
    ability and item difficulty. Anchored by fixing the mean difficulty at zero,
    because the Rasch model is only identified up to a shift -- without the
    anchor the estimates drift and are not comparable between runs.

    Args:
        responses: ``(item_id, correct)`` pairs, pooled across students.
        prior: starting difficulties.
    Returns:
        Updated ``item_id -> b``.
    """
    from .adaptive import sigmoid

    b = dict(prior or {})
    for item_id, _ in responses:
        b.setdefault(item_id, 0.0)
    theta = 0.0
    for _ in range(epochs):
        for item_id, correct in responses:
            p = sigmoid(theta - b[item_id])
            err = (1.0 if correct else 0.0) - p
            theta += eta * err
            b[item_id] -= eta * err
        mean_b = sum(b.values()) / len(b)
        b = {k: v - mean_b for k, v in b.items()}          # identifiability anchor
    return {k: round(v, 3) for k, v in b.items()}
