"""Data sources.

``Source`` is the seam that makes the package headset-agnostic. It is a very
small interface on purpose -- open, read whatever is available, close, and
describe yourself -- because every extra required method is another barrier to
someone adding a device.

``SyntheticSource`` matters more than it looks: it is what lets the test suite,
the tutorials, and continuous integration run with no hardware in the room.
A teacher can rehearse an entire lesson on a laptop before the headsets arrive.
"""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from collections.abc import Iterator
from typing import Any

import numpy as np

from ..core.types import Chunk, DeviceInfo
from ..registry import register
from ..core.clock import now


class Source(ABC):
    """Abstract acquisition device."""

    @property
    @abstractmethod
    def device(self) -> DeviceInfo: ...

    @abstractmethod
    def start(self) -> None: ...

    @abstractmethod
    def read(self) -> Chunk | None:
        """Return whatever samples have accumulated, or None if none yet."""

    @abstractmethod
    def stop(self) -> None: ...

    def stream(self, poll: float = 0.02) -> Iterator[Chunk]:
        """Convenience generator over ``read()``."""
        while True:
            chunk = self.read()
            if chunk is None:
                time.sleep(poll)
                continue
            yield chunk

    def __enter__(self) -> "Source":
        self.start()
        return self

    def __exit__(self, *exc: Any) -> None:
        self.stop()


@register("source", "synthetic")
class SyntheticSource(Source):
    """Generates physiologically plausible EEG in real time.

    This class is load-bearing: it is what lets the test suite, the tutorials,
    continuous integration, and a teacher rehearsing a lesson all run with no
    hardware in the room. So the signal has to survive the package's own signal
    quality checks -- white noise with a sine on top does not, and a demo built
    on it will be flagged as a broken electrode by ``QualityMonitor``.

    Three components, each generated with persistent state so the stream is
    continuous across chunk boundaries:

    **1/f background.** Built as a sum of first-order low-pass filtered white
    noise sources with octave-spaced corner frequencies. Each contributes a
    Lorentzian to the spectrum, and octave-spaced Lorentzians with equal
    amplitude sum to an approximate ``1/f`` power law over the range they span
    -- the standard construction, and the reason the result has a realistic
    aperiodic slope instead of a flat one.

    **Alpha rhythm.** A narrowband process, not a pure sine: white noise driven
    through a resonator at ``alpha_freq``. Real alpha waxes and wanes, and a
    fixed-amplitude sinusoid makes every downstream demo look implausibly
    stable and every band-power feature saturate at 1.0.

    **Blinks.** Stereotyped frontal deflections at a configurable rate, so the
    artifact rejection and quality advice have something real to catch.

    Args:
        sfreq: sampling rate in Hz.
        ch_names: channel labels; defaults to the Unicorn Hybrid Black montage.
        alpha_amp: microvolts RMS of alpha added to posterior channels. Change
            it at runtime (``src.alpha_amp = 2``) to fake eyes-open/eyes-closed
            and drive a whole game loop deterministically.
        noise_amp: microvolts RMS of the 1/f background.
        blink_rate: blinks per minute; 0 disables them.
        blink_amp: peak microvolts of a blink at the frontal pole. Attenuated
            posteriorly, so a headset with no frontopolar electrode sees
            blinks as a smaller deflection -- which is what really happens.
        realtime: if True, emit only as many samples as wall-clock time allows.
            Set False in tests to run as fast as the CPU permits.
        seed: fixes the noise so tests are reproducible.
    """

    UNICORN_8 = ("Fz", "C3", "Cz", "C4", "Pz", "PO7", "Oz", "PO8")

    def __init__(
        self,
        sfreq: float = 250.0,
        ch_names: tuple[str, ...] | list[str] = UNICORN_8,
        alpha_amp: float = 12.0,
        alpha_freq: float = 10.0,
        noise_amp: float = 10.0,
        blink_rate: float = 12.0,
        blink_amp: float = 150.0,
        seed: int | None = 0,
        realtime: bool = True,
    ) -> None:
        self._device = DeviceInfo(
            name="synthetic",
            sfreq=float(sfreq),
            ch_names=tuple(ch_names),
            ch_types=tuple("eeg" for _ in ch_names),
        )
        self.alpha_amp = alpha_amp
        self.alpha_freq = alpha_freq
        self.noise_amp = noise_amp
        self.blink_rate = blink_rate
        self.blink_amp = blink_amp
        self.realtime = realtime
        self._rng = np.random.default_rng(seed)
        self._t_last = 0.0
        self._t0 = 0.0
        self._seq = 0
        self._running = False
        self._blink_phase = -1

        nch = self._device.n_channels
        sf = self._device.sfreq

        # 1/f background: octave-spaced first-order poles from 0.5 Hz upward.
        n_poles = 7
        corners = 0.5 * 2.0 ** np.arange(n_poles)
        corners = corners[corners < sf / 2.5]
        self._pink_a = np.exp(-2 * np.pi * corners / sf)          # (n_poles,)
        self._pink_state = np.zeros((len(self._pink_a), nch))
        # Each pole is weighted by 1/sqrt(f_c) so equal-octave bands carry
        # equal power, which is what makes the sum a 1/f law rather than 1/f^2.
        self._pink_w = (1.0 / np.sqrt(corners))[:, None]

        # Alpha resonator: a two-pole band-pass driven by white noise.
        r = 0.985                                   # pole radius -> bandwidth
        theta = 2 * np.pi * alpha_freq / sf
        self._alpha_a1 = 2 * r * np.cos(theta)
        self._alpha_a2 = -(r ** 2)
        self._alpha_z1 = np.zeros(nch)
        self._alpha_z2 = np.zeros(nch)

        # Posterior weighting: alpha is a posterior rhythm on a real head.
        self._alpha_gain = np.array(
            [_posterior_weight(ch) for ch in self._device.ch_names]
        )[:, None]
        self._blink_gain = np.array(
            [_frontal_weight(ch) for ch in self._device.ch_names]
        )[:, None]

        self._warm_up()

    def _warm_up(self) -> None:
        """Run the filters for a few seconds so the first chunk is not a ramp.

        Also measures the realised RMS of each component, so ``noise_amp`` and
        ``alpha_amp`` mean microvolts rather than arbitrary filter units.
        """
        n = int(5 * self._device.sfreq)
        pink = self._pink(n)
        alpha = self._alpha(n)
        self._pink_scale = 1.0 / max(float(pink.std()), 1e-9)
        self._alpha_scale = 1.0 / max(float(alpha.std()), 1e-9)

    def _pink(self, n: int) -> np.ndarray:
        """Advance the 1/f cascade by ``n`` samples. Shape (n_channels, n)."""
        nch = self._device.n_channels
        w = self._rng.normal(0.0, 1.0, (len(self._pink_a), nch, n))
        out = np.empty((nch, n))
        a = self._pink_a[:, None]
        state = self._pink_state
        for i in range(n):
            state = a * state + (1.0 - a) * w[:, :, i]
            out[:, i] = (self._pink_w * state).sum(axis=0)
        self._pink_state = state
        return out

    def _alpha(self, n: int) -> np.ndarray:
        """Advance the alpha resonator by ``n`` samples."""
        nch = self._device.n_channels
        drive = self._rng.normal(0.0, 1.0, (nch, n))
        out = np.empty((nch, n))
        z1, z2 = self._alpha_z1, self._alpha_z2
        for i in range(n):
            y = drive[:, i] + self._alpha_a1 * z1 + self._alpha_a2 * z2
            out[:, i] = y
            z2, z1 = z1, y
        self._alpha_z1, self._alpha_z2 = z1, z2
        return out

    def _blinks(self, n: int) -> np.ndarray:
        """Occasional stereotyped frontal deflections, ~200 ms wide."""
        out = np.zeros((self._device.n_channels, n))
        if self.blink_rate <= 0:
            return out
        sf = self._device.sfreq
        p = self.blink_rate / 60.0 / sf                  # per-sample probability
        width = int(0.2 * sf)
        for i in range(n):
            if self._blink_phase < 0 and self._rng.random() < p:
                self._blink_phase = 0
            if self._blink_phase >= 0:
                # Half-sine bump ~200 ms wide: the classic blink shape.
                frac = self._blink_phase / width
                out[:, i] = (self.blink_amp * np.sin(np.pi * frac)
                             * self._blink_gain[:, 0])
                self._blink_phase += 1
                if self._blink_phase >= width:
                    self._blink_phase = -1
        return out

    @property
    def device(self) -> DeviceInfo:
        return self._device

    def start(self) -> None:
        self._t0 = self._t_last = now()
        self._running = True

    def stop(self) -> None:
        self._running = False

    def read(self) -> Chunk | None:
        if not self._running:
            raise RuntimeError("call start() before read()")
        t = now()
        if self.realtime:
            n = int((t - self._t_last) * self._device.sfreq)
            if n <= 0:
                return None
        else:
            n = int(0.1 * self._device.sfreq)       # fixed 100 ms, no waiting

        t_start = self._t_last
        self._t_last += n / self._device.sfreq

        data = self.noise_amp * self._pink_scale * self._pink(n)
        data += (self.alpha_amp * self._alpha_scale
                 * self._alpha_gain * self._alpha(n))
        data += self._blinks(n)

        self._seq += 1
        return Chunk(data=data, t_start=t_start, seq=self._seq)


def _posterior_weight(ch: str) -> float:
    """Alpha amplitude by scalp position, from the 10-20 label."""
    from ..core.montage import parse_label

    p = parse_label(ch)
    if p is None:
        return 0.5
    y = p[2]                                        # +1 anterior, -1 posterior
    return float(np.clip(0.15 + 0.85 * (0.5 - y / 2.0), 0.1, 1.0))


def _frontal_weight(ch: str) -> float:
    """Blink amplitude by scalp position: largest at the frontal pole."""
    from ..core.montage import parse_label

    p = parse_label(ch)
    if p is None:
        return 0.2
    y = p[2]                                        # +1.0 at the frontal pole
    return float(np.clip((y + 0.45) / 1.45, 0.0, 1.0) ** 1.5)


def packet_counter_gaps(counter: np.ndarray, previous: float | None = None) -> tuple[int, int]:
    """Missing and repeated values in a device's per-sample packet counter.

    Returns ``(missing, repeated)``: how many counter values were skipped, and
    how many samples repeated the value before them. ``previous`` is the last
    value of the preceding chunk, so a chunk boundary is checked like any
    other step. A counter that wraps (BrainFlow's synthetic board counts
    0-255) is unwrapped at the next power of two above the value it wrapped
    from, so a wrap is not mistaken for a gap.
    """
    c = np.asarray(counter, dtype=np.float64)
    if previous is not None:
        c = np.concatenate([[float(previous)], c])
    if c.size < 2:
        return 0, 0
    d = np.diff(c)
    wrap = d < 0
    if wrap.any():
        d = d.copy()
        d[wrap] += 2.0 ** np.ceil(np.log2(np.maximum(c[:-1][wrap], 1.0) + 1.0))
    return int(np.sum(np.maximum(d - 1.0, 0.0))), int(np.sum(d == 0))


@register("source", "brainflow")
class BrainFlowSource(Source):
    """Any BrainFlow-supported headset, including the Unicorn Hybrid Black.

    BrainFlow already normalises the wire protocol across vendors; this wrapper
    adds what it does not give you -- a DeviceInfo with real channel names, unit
    conversion, and monotonic timestamps aligned to the local clock.

    Each chunk also carries the board's side rows in ``Chunk.aux``, where the
    board has them: BrainFlow's per-sample ``timestamp``, the device's
    ``package_num`` counter, the ``marker`` row that :meth:`insert_marker`
    writes into, and ``battery``. Skipped counter values are totalled in
    ``counter_missing_total`` next to the held-sample count, because which of
    the two a Unicorn Bluetooth dropout shows up in has not yet been checked
    on hardware.

    Args:
        board: BrainFlow board name or numeric id, e.g. ``"UNICORN_BOARD"``.
        serial_port / mac_address / other params passed to BrainFlowInputParams.
    """

    def __init__(self, board: str | int = "SYNTHETIC_BOARD", *, mains: float = 60.0,
                 repair_dropouts: bool = True, **params: Any) -> None:
        self._board_arg = board
        self._params = params
        # Bluetooth dropouts arrive as held samples that freeze the mains hum
        # mid-cycle; repaired on arrival (see neurobridge.process.dropouts),
        # which is also what load_recording() does to saved files.
        self._mains = float(mains)
        self._repair_dropouts = bool(repair_dropouts)
        self._repair = None
        self._board = None
        self._streaming = False
        self._eeg_idx: list[int] = []
        self._aux_idx: dict[str, int] = {}
        self._device_info: DeviceInfo | None = None
        self._seq = 0
        self._t0 = 0.0
        self._last_col: np.ndarray | None = None
        self._last_counter: float | None = None
        self._loss_window: list[tuple[int, int]] = []
        #: Running totals of delivered and held (lost) samples this session.
        self.samples_total = 0
        self.held_total = 0
        #: Running totals from the device's packet counter, where it has one:
        #: counter values skipped, and samples that repeated the value before.
        self.counter_missing_total = 0
        self.counter_repeat_total = 0

    def _import(self):
        try:
            from brainflow.board_shim import BoardIds, BoardShim, BrainFlowInputParams
        except ImportError as exc:  # pragma: no cover - depends on optional extra
            raise ImportError(
                "BrainFlowSource requires the 'brainflow' extra: "
                "pip install neurobridge[brainflow]"
            ) from exc
        return BoardIds, BoardShim, BrainFlowInputParams

    @property
    def device(self) -> DeviceInfo:
        if self._device_info is None:
            raise RuntimeError("call start() before accessing device info")
        return self._device_info

    def start(self) -> None:  # pragma: no cover - requires hardware or brainflow
        BoardIds, BoardShim, BrainFlowInputParams = self._import()
        board_id = (
            int(self._board_arg)
            if isinstance(self._board_arg, int)
            else int(getattr(BoardIds, self._board_arg).value)
        )
        bf_params = BrainFlowInputParams()
        for key, value in self._params.items():
            setattr(bf_params, key, value)

        self._board = BoardShim(board_id, bf_params)
        self._board.prepare_session()
        self._board.start_stream()
        self._streaming = True
        self._t0 = now()

        self._eeg_idx = BoardShim.get_eeg_channels(board_id)
        # Side rows kept next to the EEG instead of discarded. Not every board
        # has every row, and BrainFlow raises for the ones it lacks.
        self._aux_idx = {}
        for name, getter in (("timestamp", BoardShim.get_timestamp_channel),
                             ("package_num", BoardShim.get_package_num_channel),
                             ("marker", BoardShim.get_marker_channel),
                             ("battery", BoardShim.get_battery_channel)):
            try:
                self._aux_idx[name] = int(getter(board_id))
            except Exception:
                pass
        names = BoardShim.get_eeg_names(board_id)
        self._device_info = DeviceInfo(
            name=BoardShim.get_device_name(board_id),
            sfreq=float(BoardShim.get_sampling_rate(board_id)),
            ch_names=tuple(names),
            ch_types=tuple("eeg" for _ in names),
            extra={"board_id": board_id},
        )
        if self._repair_dropouts:
            from ..process.dropouts import DropoutRepair

            self._repair = DropoutRepair(len(self._eeg_idx),
                                         self._device_info.sfreq, self._mains)

    def read(self) -> Chunk | None:  # pragma: no cover - requires brainflow
        if self._board is None:
            raise RuntimeError("call start() before read()")
        n = self._board.get_board_data_count()
        if n == 0:
            return None
        raw = self._board.get_board_data(n)
        self._seq += 1
        sfreq = self.device.sfreq
        t_start = now() - n / sfreq
        data = raw[self._eeg_idx, :]
        aux = {name: raw[i].copy() for name, i in self._aux_idx.items()}
        self._track_held(data, sfreq)
        if "package_num" in aux:
            missing, repeated = packet_counter_gaps(aux["package_num"], self._last_counter)
            self.counter_missing_total += missing
            self.counter_repeat_total += repeated
            self._last_counter = float(aux["package_num"][-1])
        if self._repair is not None:
            data = self._repair(data)
        return Chunk(data=data, t_start=t_start, seq=self._seq, aux=aux or None)

    def _track_held(self, data: np.ndarray, sfreq: float) -> None:
        """Count samples that repeat the previous one exactly on every channel.

        Over Bluetooth, lost Unicorn packets show up in the BrainFlow stream as
        the last sample held for the length of the gap -- runs of rows
        identical on all eight channels, with the sample count (and so the
        timing) preserved. Real 24-bit EEG never repeats exactly on every
        channel at once, so an exact repeat is a lost sample. On this
        project's recordings it has run from 0.02% to 11% of a session, and
        because each gap freezes the mains hum mid-cycle it inflates RMS and
        peak-to-peak far more than its share of samples suggests. The gaps
        are repaired on arrival, but the EEG inside them is still lost, so
        above a few percent move the Bluetooth dongle closer to the headset
        before recording.
        """
        prev = self._last_col
        full = data if prev is None else np.concatenate([prev[:, None], data], axis=1)
        held = (int(np.all(full[:, 1:] == full[:, :-1], axis=0).sum())
                if full.shape[1] > 1 else 0)
        self._last_col = data[:, -1].copy()
        n = data.shape[1]
        self.samples_total += n
        self.held_total += held
        self._loss_window.append((n, held))
        span = int(10 * sfreq)
        while (len(self._loss_window) > 1
               and sum(k for k, _ in self._loss_window[1:]) >= span):
            self._loss_window.pop(0)

    @property
    def held_fraction(self) -> float:
        """Fraction of roughly the last 10 s that arrived as held (lost) samples."""
        n = sum(k for k, _ in self._loss_window)
        return sum(h for _, h in self._loss_window) / n if n else 0.0

    def insert_marker(self, value: float) -> None:  # pragma: no cover - requires brainflow
        """Write ``value`` into the board's marker row at the next sample it delivers.

        A label placed this way sits on the sample it belongs to, instead of
        being reconstructed afterwards from a wall-clock time whose offset from
        the first recorded sample is unknown. BrainFlow reserves 0 for "no
        marker", so ``value`` must be non-zero.
        """
        if self._board is None:
            raise RuntimeError("call start() before insert_marker()")
        if value == 0:
            raise ValueError("0 means 'no marker' in BrainFlow; use a non-zero code")
        self._board.insert_marker(float(value))

    def stop_stream(self) -> None:  # pragma: no cover - requires brainflow
        """Stop acquiring but keep the session open.

        Samples the board has already delivered can still be drained with
        read(); stop() then releases the device. stop() on its own still does
        both.
        """
        if self._board is not None and self._streaming:
            self._board.stop_stream()
            self._streaming = False

    def stop(self) -> None:  # pragma: no cover - requires brainflow
        if self._board is not None:
            self.stop_stream()
            self._board.release_session()
            self._board = None


@register("source", "lsl")
class LSLSource(Source):
    """Any device streaming EEG over Lab Streaming Layer.

    BrainFlow covers a fixed list of vendor SDKs; LSL is the other common path
    onto the network -- most EEG software (BrainVision Recorder, OpenViBE,
    muse-lsl, many manufacturers' own drivers) can publish an LSL outlet, so a
    headset with no BrainFlow board id can usually still reach this package by
    running whatever LSL app the vendor ships and pointing this class at it.
    Channel count, names, and sampling rate all come from the outlet's own
    advertised stream info, the same "trust the SDK, do not hardcode it"
    convention ``BrainFlowSource`` uses.

    Args:
        stream_name: match a specific outlet by its LSL ``name`` (e.g. the
            name muse-lsl or the vendor's own app assigns). Takes priority
            over ``stream_type`` when given, for when more than one EEG
            outlet is on the network.
        stream_type: match by LSL ``type`` when no name is given; ``"EEG"``
            is the convention essentially every EEG outlet advertises.
        timeout: seconds to wait for a matching outlet before giving up.
        max_buflen: seconds of data LSL buffers internally if ``read()`` is
            not called often enough to keep up.
        ch_names: force the channel labels instead of trusting the outlet's
            own XML description. Needed for bridges that publish generic or
            missing labels -- some third-party LSL bridges (a common way to
            get an Emotiv headset onto LSL, since Emotiv's own SDK is not a
            BrainFlow board) do not populate ``<channels><channel><label>``
            at all, and every channel-role lookup in this package (montage
            roles like ``alpha_posterior``, ``theta_frontal``) depends on
            real 10-20 labels to work. Must match the outlet's channel count
            and order exactly.
    """

    def __init__(
        self,
        stream_name: str | None = None,
        stream_type: str = "EEG",
        timeout: float = 5.0,
        max_buflen: int = 360,
        ch_names: tuple[str, ...] | list[str] | None = None,
    ) -> None:
        self._stream_name = stream_name
        self._stream_type = stream_type
        self._timeout = timeout
        self._max_buflen = max_buflen
        self._ch_names_override = tuple(ch_names) if ch_names else None
        self._inlet = None
        self._device_info: DeviceInfo | None = None
        self._seq = 0

    def _import(self):
        try:
            import pylsl
        except ImportError as exc:  # pragma: no cover - depends on optional extra
            raise ImportError(
                "LSLSource requires the 'pylsl' package: pip install pylsl"
            ) from exc
        return pylsl

    @property
    def device(self) -> DeviceInfo:
        if self._device_info is None:
            raise RuntimeError("call start() before accessing device info")
        return self._device_info

    def start(self) -> None:  # pragma: no cover - requires an LSL outlet
        pylsl = self._import()
        prop, value = (("name", self._stream_name) if self._stream_name
                       else ("type", self._stream_type))
        streams = pylsl.resolve_byprop(prop, value, timeout=self._timeout)
        if not streams:
            raise RuntimeError(
                f"no LSL stream found with {prop}={value!r} after "
                f"{self._timeout}s -- is the outlet running and on the same network?"
            )
        self._inlet = pylsl.StreamInlet(streams[0], max_buflen=self._max_buflen)
        info = self._inlet.info()
        n_ch = info.channel_count()
        if self._ch_names_override is not None:
            if len(self._ch_names_override) != n_ch:
                raise ValueError(
                    f"ch_names has {len(self._ch_names_override)} entries but "
                    f"the outlet reports {n_ch} channels"
                )
            names = list(self._ch_names_override)
        else:
            names = _lsl_channel_labels(info, n_ch)
        self._device_info = DeviceInfo(
            name=info.name(),
            sfreq=float(info.nominal_srate()),
            ch_names=tuple(names),
            ch_types=tuple("eeg" for _ in names),
            extra={"source_id": info.source_id(), "stream_type": info.type()},
        )

    def read(self) -> Chunk | None:  # pragma: no cover - requires an LSL outlet
        if self._inlet is None:
            raise RuntimeError("call start() before read()")
        samples, _ = self._inlet.pull_chunk(timeout=0.0, max_samples=4096)
        if not samples:
            return None
        data = np.asarray(samples, dtype=np.float64).T  # (n_channels, n_samples)
        n = data.shape[1]
        sfreq = self.device.sfreq
        self._seq += 1
        # Timestamped against the package's own perf_counter clock, not LSL's
        # local_clock() -- every other Source (including BrainFlowSource) does
        # the same, and mixing clock domains within one session is exactly
        # what core.clock.now()'s docstring warns against.
        t_start = now() - n / sfreq
        return Chunk(data=data, t_start=t_start, seq=self._seq)

    def stop(self) -> None:  # pragma: no cover - requires an LSL outlet
        if self._inlet is not None:
            self._inlet.close_stream()
            self._inlet = None


def _lsl_channel_labels(info: Any, n_ch: int) -> list[str]:
    """Read per-channel labels from the outlet's XML description.

    This is the layout essentially every LSL EEG app writes (BrainVision
    Recorder, OpenViBE, muse-lsl, vendor apps): a ``<channels>`` element with
    one ``<channel>`` child per channel, each holding a ``<label>``. Falls
    back to generic names if the outlet did not populate one -- some minimal
    outlets skip it, and a missing label should not be a hard failure.
    """
    labels: list[str] = []
    ch = info.desc().child("channels").child("channel")
    while (not ch.empty()) and len(labels) < n_ch:
        label = ch.child_value("label") or ch.child_value("name")
        labels.append(label if label else f"Ch{len(labels) + 1}")
        ch = ch.next_sibling()
    if len(labels) != n_ch:
        labels = [f"Ch{i + 1}" for i in range(n_ch)]
    return labels


@register("source", "replay")
class ReplaySource(Source):
    """Replays a recorded array at real-time speed.

    Recording one good session and replaying it turns a flaky classroom demo
    into a deterministic one, and gives the education study a way to show every
    student the identical stimulus when that is what the design requires.
    """

    def __init__(
        self,
        data: np.ndarray,
        device: DeviceInfo,
        loop: bool = True,
        chunk_ms: float = 40.0,
    ) -> None:
        self._data = np.asarray(data, dtype=np.float64)
        self._device = device
        self.loop = loop
        self._n_chunk = max(1, int(chunk_ms / 1000.0 * device.sfreq))
        self._pos = 0
        self._seq = 0
        self._t_last = 0.0
        self._running = False

    @property
    def device(self) -> DeviceInfo:
        return self._device

    def start(self) -> None:
        self._t_last = now()
        self._running = True

    def stop(self) -> None:
        self._running = False

    def read(self) -> Chunk | None:
        if not self._running:
            raise RuntimeError("call start() before read()")
        t = now()
        if t - self._t_last < self._n_chunk / self._device.sfreq:
            return None
        if self._pos >= self._data.shape[1]:
            if not self.loop:
                return None
            self._pos = 0
        end = min(self._pos + self._n_chunk, self._data.shape[1])
        chunk = Chunk(
            data=self._data[:, self._pos:end].copy(),
            t_start=self._t_last,
            seq=self._seq,
        )
        self._t_last += (end - self._pos) / self._device.sfreq
        self._pos = end
        self._seq += 1
        return chunk
