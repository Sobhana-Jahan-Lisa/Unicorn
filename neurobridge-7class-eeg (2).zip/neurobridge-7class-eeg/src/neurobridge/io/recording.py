"""Recording, replay and MNE interoperability.

Real-time and offline analysis are usually two disconnected worlds: you stream
with one tool and analyse with another, and the preprocessing silently differs.
Here a session's raw data is written in a format that reconstructs into the
exact same ``DeviceInfo``, and converts to an ``mne.io.RawArray`` in one call --
so the offline analysis inherits the online montage, sampling rate and channel
types rather than having them re-entered by hand.

Storage format is NPZ: numpy arrays plus a JSON sidecar of metadata. It is
readable by anyone with numpy and needs no database. :class:`Recorder` keeps a
session in memory and writes the NPZ on close; :class:`StreamingRecorder` also
appends every chunk to a CSV the moment it arrives, so an interrupted session
is not lost, and :func:`recover_csv_recording` turns that CSV back into an NPZ.

Raw EEG from minors is written only when ``logging.raw`` is explicitly enabled.
The default session writes derived features and events, not the recording.
"""

from __future__ import annotations

import csv
import json
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np

from ..core.types import Chunk, DeviceInfo


class Recorder:
    """Appends chunks to an in-memory buffer and writes NPZ on close.

    Args:
        device: montage and sampling rate, stored alongside the data.
        path: output ``.npz``.
        max_seconds: hard cap on recording length. A cap is a feature, not a
            limitation: an unbounded recorder in a classroom quietly fills a
            disk and then loses the session it was protecting.
    """

    def __init__(self, device: DeviceInfo, path: str | Path,
                 max_seconds: float = 3600.0) -> None:
        self.device = device
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.max_samples = int(max_seconds * device.sfreq)
        self._blocks: list[np.ndarray] = []
        self._timestamps: list[float] = []
        self._n = 0
        self._lock = threading.Lock()
        self.truncated = False

    def add(self, chunk: Chunk) -> None:
        with self._lock:
            if self._n >= self.max_samples:
                self.truncated = True
                return
            room = self.max_samples - self._n
            data = chunk.data[:, :room]
            self._blocks.append(np.asarray(data, dtype=np.float32))
            self._timestamps.append(chunk.t_start)
            self._n += data.shape[1]

    @property
    def n_samples(self) -> int:
        return self._n

    def close(self, annotations: list[dict] | None = None) -> Path:
        with self._lock:
            data = (np.hstack(self._blocks) if self._blocks
                    else np.zeros((self.device.n_channels, 0), dtype=np.float32))
            meta = {
                "device": self.device.name,
                "sfreq": self.device.sfreq,
                "ch_names": list(self.device.ch_names),
                "ch_types": list(self.device.ch_types),
                "unit": self.device.unit,
                "n_samples": int(data.shape[1]),
                "truncated": self.truncated,
                "annotations": annotations or [],
            }
            np.savez_compressed(
                self.path, data=data,
                chunk_starts=np.asarray(self._timestamps, dtype=np.float64),
                meta=np.array(json.dumps(meta)),
            )
        return self.path


#: A label opened with marker code ``c`` is closed with ``c + END_OFFSET``.
#: Both are positive because BrainFlow reserves 0 for "no marker".
END_OFFSET = 100

_AUX = ("timestamp", "package_num", "marker")


class StreamingRecorder(Recorder):
    """A :class:`Recorder` that also survives a crash.

    Every chunk is appended to a CSV and flushed the moment it arrives --
    unfiltered EEG exactly as the source delivered it, with BrainFlow's
    per-sample timestamp, the device's packet counter and the marker row --
    so if Python or the laptop dies mid-session, everything received so far
    is already on disk; :func:`recover_csv_recording` rebuilds the NPZ from
    it. A JSON sidecar describing the recording is written before the first
    sample and completed on close. :meth:`close` also writes the usual NPZ,
    in the format :func:`load_recording` and the training scripts read, with
    the side rows added as ``timestamps``, ``package_num`` and ``marker``
    arrays. Nothing is ever overwritten. The approach follows the standalone
    Unicorn Live Viewer (``unicorn_live.py``).

    Args:
        device, max_seconds: as :class:`Recorder`.
        path: the ``.npz``; the ``.csv`` and ``.json`` share its name.
        extra_meta: stored in the sidecar and the NPZ metadata -- e.g.
            participant, session, mains, marker codes, display filter.
    """

    def __init__(self, device: DeviceInfo, path: str | Path,
                 max_seconds: float = 3600.0,
                 extra_meta: dict[str, Any] | None = None) -> None:
        path = Path(path)
        csv_path, json_path = path.with_suffix(".csv"), path.with_suffix(".json")
        for p in (path, csv_path, json_path):
            if p.exists():
                raise FileExistsError(f"{p} already exists; a recording is never overwritten")
        super().__init__(device, path, max_seconds)
        self.csv_path, self.json_path = csv_path, json_path
        self.extra_meta = dict(extra_meta or {})
        self._aux: dict[str, list[np.ndarray]] = {name: [] for name in _AUX}
        self._last_col: np.ndarray | None = None
        self._held = 0
        self._closed = False
        self._started = datetime.now(timezone.utc).isoformat()
        self._fh = csv_path.open("x", newline="", encoding="utf-8")
        self._csv = csv.writer(self._fh)
        self._csv.writerow(["sample", "brainflow_timestamp_s", "package_counter", "marker"]
                           + [f"{name}_uV" for name in device.ch_names])
        self._fh.flush()
        self._write_sidecar(status="recording")

    def _meta(self) -> dict[str, Any]:
        return {
            "device": self.device.name,
            "sfreq": self.device.sfreq,
            "ch_names": list(self.device.ch_names),
            "ch_types": list(self.device.ch_types),
            "unit": self.device.unit,
            "recording": ("unfiltered EEG exactly as the source delivered it: "
                          "no dropout repair, no filtering"),
            "csv": self.csv_path.name,
            "started": self._started,
            **self.extra_meta,
        }

    def _write_sidecar(self, **fields: Any) -> None:
        self.json_path.write_text(json.dumps({**self._meta(), **fields}, indent=2),
                                  encoding="utf-8")

    def add(self, chunk: Chunk) -> None:
        with self._lock:
            if self._closed:
                raise RuntimeError("the recording is already closed")
            if self._n >= self.max_samples:
                self.truncated = True
                return
            data = np.asarray(chunk.data[:, :self.max_samples - self._n], dtype=np.float64)
            k = data.shape[1]
            if k == 0:
                return
            if k < chunk.n_samples:
                self.truncated = True
            aux = chunk.aux or {}
            cols = {name: (np.asarray(aux[name], dtype=np.float64)[:k] if name in aux
                           else np.full(k, np.nan)) for name in _AUX}
            # Held samples: exact repeats of the previous sample on every channel.
            full = (data if self._last_col is None
                    else np.concatenate([self._last_col[:, None], data], axis=1))
            self._held += int(np.all(full[:, 1:] == full[:, :-1], axis=0).sum())
            self._last_col = data[:, -1].copy()
            rows = np.column_stack([cols["timestamp"], cols["package_num"],
                                    cols["marker"], data.T]).tolist()
            self._csv.writerows([self._n + j, *row] for j, row in enumerate(rows))
            self._fh.flush()
            self._blocks.append(data.astype(np.float32))
            self._timestamps.append(chunk.t_start)
            for name in _AUX:
                self._aux[name].append(cols[name])
            self._n += k

    @property
    def markers(self) -> np.ndarray:
        """The marker row recorded so far, 0 where there is no marker."""
        with self._lock:
            parts = self._aux["marker"]
            m = np.concatenate(parts) if parts else np.zeros(0)
        return np.nan_to_num(m, nan=0.0)

    def close(self, annotations: list[dict] | None = None,
              extra_meta: dict[str, Any] | None = None) -> Path:
        """Close the CSV, write the NPZ and the completed sidecar. Idempotent."""
        from .sources import packet_counter_gaps

        with self._lock:
            if self._closed:
                return self.path
            self._closed = True
            self._fh.close()
            data = (np.hstack(self._blocks) if self._blocks
                    else np.zeros((self.device.n_channels, 0), dtype=np.float32))
            aux = {name: (np.concatenate(v) if v else np.zeros(0))
                   for name, v in self._aux.items()}
            counter = aux["package_num"][np.isfinite(aux["package_num"])]
            missing, repeated = packet_counter_gaps(counter) if counter.size else (None, None)
            meta = {
                **self._meta(), **(extra_meta or {}),
                "n_samples": int(data.shape[1]),
                "truncated": self.truncated,
                "packet_loss": {"held_samples": self._held, "counter_missing": missing,
                                "counter_repeated": repeated},
                "annotations": annotations or [],
            }
            with self.path.open("xb") as fh:
                np.savez_compressed(
                    fh, data=data,
                    chunk_starts=np.asarray(self._timestamps, dtype=np.float64),
                    timestamps=aux["timestamp"], package_num=aux["package_num"],
                    marker=aux["marker"], meta=np.array(json.dumps(meta)),
                )
            self.json_path.write_text(json.dumps({**meta, "status": "complete"}, indent=2),
                                      encoding="utf-8")
        return self.path


def spans_from_markers(markers: np.ndarray, sfreq: float, labels: dict[int, str],
                       **fields: Any) -> tuple[list[dict], list[str]]:
    """Pair label markers into annotation spans.

    ``labels`` maps a code to its label; a span opens on ``code`` and closes on
    ``code + END_OFFSET``. Times are seconds from the first recorded sample --
    the convention :func:`epochs_from_recording` and the training scripts use
    -- and the exact sample indices are kept alongside. ``fields`` (e.g.
    participant, session) are copied into every span.

    Returns ``(spans, problems)``. A span left open, a close without a matching
    open, or an unknown code is described in ``problems`` and not turned into
    a span, rather than guessed at.
    """
    spans: list[dict] = []
    problems: list[str] = []
    open_code: int | None = None
    open_at = 0
    m = np.nan_to_num(np.asarray(markers, dtype=np.float64), nan=0.0)
    for idx in np.flatnonzero(m):
        code = int(round(m[idx]))
        if code in labels:
            if open_code is not None:
                problems.append(f"'{labels[open_code]}' opened at {open_at / sfreq:.2f} s "
                                f"was never closed")
            open_code, open_at = code, int(idx)
        elif code - END_OFFSET in labels:
            base = code - END_OFFSET
            if open_code != base:
                problems.append(f"'{labels[base]}' closed at {idx / sfreq:.2f} s without "
                                f"being opened")
                continue
            spans.append({"label": labels[base], "t_start": open_at / sfreq,
                          "t_end": int(idx) / sfreq, "start_sample": open_at,
                          "end_sample": int(idx), **fields})
            open_code = None
        else:
            problems.append(f"unknown marker {m[idx]:g} at {idx / sfreq:.2f} s")
    if open_code is not None:
        problems.append(f"'{labels[open_code]}' was still open when the recording ended; "
                        f"discarded")
    return spans, problems


def recover_csv_recording(csv_path: str | Path) -> Path:
    """Rebuild the NPZ of a :class:`StreamingRecorder` session that never closed.

    For a crash, a killed process or a power cut: reads the CSV that was
    flushed chunk by chunk and the JSON sidecar written before the first
    sample, recovers the labelled spans from the marker column when the
    sidecar lists ``marker_codes``, and writes the NPZ next to the CSV.
    Refuses to overwrite an existing NPZ. Returns its path.
    """
    csv_path = Path(csv_path)
    side = json.loads(csv_path.with_suffix(".json").read_text(encoding="utf-8"))
    out = csv_path.with_suffix(".npz")
    if out.exists():
        raise FileExistsError(f"{out} already exists")
    table = np.loadtxt(csv_path, delimiter=",", skiprows=1, ndmin=2)
    if table.size == 0:
        raise ValueError(f"{csv_path} has no samples")
    data = table[:, 4:].T
    timestamps, counter, marker = table[:, 1], table[:, 2], table[:, 3]
    codes = {int(k): v for k, v in (side.get("marker_codes") or {}).items()}
    fields = {k: side[k] for k in ("participant", "session") if k in side}
    spans, problems = (spans_from_markers(marker, float(side["sfreq"]), codes, **fields)
                       if codes else ([], []))
    meta = {k: v for k, v in side.items() if k != "status"}
    meta.update({"n_samples": int(data.shape[1]), "truncated": False, "annotations": spans,
                 "marker_problems": problems, "recovered_from_csv": True})
    with out.open("xb") as fh:
        np.savez_compressed(fh, data=data.astype(np.float32), chunk_starts=np.zeros(0),
                            timestamps=timestamps, package_num=counter, marker=marker,
                            meta=np.array(json.dumps(meta)))
    return out


def load_recording(path: str | Path, repair_dropouts: bool = True,
                   mains: float | None = None) -> tuple[np.ndarray, DeviceInfo, dict]:
    """Load an NPZ recording back into ``(data, device, meta)``.

    Args:
        repair_dropouts: fill Bluetooth dropouts (held samples) exactly as
            the live :class:`~neurobridge.io.sources.BrainFlowSource` does, so
            offline analysis and training see the signal the live system
            sees. A no-op on recordings without dropouts. Pass ``False`` for
            the samples exactly as stored. See
            :mod:`neurobridge.process.dropouts`.
        mains: hum frequency for the repair; ``meta["mains"]`` if the
            recording has it, else 60 Hz.
    """
    z = np.load(Path(path), allow_pickle=False)
    meta = json.loads(str(z["meta"]))
    device = DeviceInfo(
        name=meta["device"], sfreq=meta["sfreq"],
        ch_names=tuple(meta["ch_names"]),
        ch_types=tuple(meta.get("ch_types") or ()),
        unit=meta.get("unit", "uV"),
    )
    data = z["data"].astype(np.float64)
    if repair_dropouts and data.size:
        from ..process.dropouts import DropoutRepair

        repair = DropoutRepair(data.shape[0], float(meta["sfreq"]),
                               float(mains or meta.get("mains", 60.0)))
        data = repair(data)
        meta["dropouts_repaired"] = repair.n_repaired
    return data, device, meta


def to_mne(data: np.ndarray, device: DeviceInfo, montage: str = "standard_1020"):
    """Convert to an ``mne.io.RawArray`` with the standard montage attached.

    MNE expects volts; this package works in microvolts, so the conversion
    factor is applied here and only here. Getting this wrong is the classic
    source of amplitudes that are off by a million and PSDs that look absurd.
    """
    try:
        import mne
    except ImportError as exc:
        raise ImportError(
            "MNE interop needs the 'mne' extra: pip install neurobridge[mne]"
        ) from exc

    info = mne.create_info(
        ch_names=list(device.ch_names),
        sfreq=device.sfreq,
        ch_types=list(device.ch_types) or "eeg",
    )
    raw = mne.io.RawArray(data * 1e-6, info, verbose="ERROR")
    try:
        raw.set_montage(montage, on_missing="warn", verbose="ERROR")
    except Exception:                                   # unusual channel labels
        pass
    return raw


def from_mne(raw) -> tuple[np.ndarray, DeviceInfo]:
    """Convert an MNE Raw back to this package's convention (microvolts)."""
    data = raw.get_data() * 1e6
    device = DeviceInfo(
        name=str(raw.info.get("description") or "mne"),
        sfreq=float(raw.info["sfreq"]),
        ch_names=tuple(raw.ch_names),
        ch_types=tuple(raw.get_channel_types()),
    )
    return data, device


def epochs_from_recording(
    data: np.ndarray, device: DeviceInfo, window: float, step: float,
    labels: list[tuple[float, float, str]] | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """Cut a recording into the same windows the online system would use.

    This is what makes offline model development honest: the training epochs
    have identical length, hop and alignment to the ones the live pipeline will
    see, so an offline accuracy figure transfers to the online setting instead
    of being an optimistic upper bound.

    Args:
        labels: ``(t_start, t_end, label)`` spans in seconds. Windows are
            assigned a label only when they fall *entirely* inside a span;
            partially overlapping windows are discarded rather than given an
            ambiguous label, which would blur the class boundary.
    """
    n_win = int(round(window * device.sfreq))
    n_step = int(round(step * device.sfreq))
    if n_win > data.shape[1]:
        raise ValueError(
            f"window of {window} s needs {n_win} samples but the recording has "
            f"{data.shape[1]}"
        )

    X, y = [], []
    for start in range(0, data.shape[1] - n_win + 1, n_step):
        t0 = start / device.sfreq
        t1 = (start + n_win) / device.sfreq
        label = None
        if labels is not None:
            for a, b, lab in labels:
                if a <= t0 and t1 <= b:
                    label = lab
                    break
            if label is None:
                continue
        X.append(data[:, start:start + n_win])
        y.append(label)
    return np.stack(X) if X else np.empty((0, data.shape[0], n_win)), np.array(y)
