"""Background acquisition: read a source on its own thread.

In 06_live_scope.py and 19_record_focus_states.py the device is read from the
plot's animation timer, so anything that stalls the GUI -- dragging the window,
a slow redraw -- also stalls reading and recording. BrainFlow keeps buffering
in the meantime, so samples are not lost, but nothing reaches the recording
until the GUI gets round to it. Here one thread reads the source every
``poll_s``, hands each chunk to the recorder first and then to whatever
processing the caller registers; the GUI only takes snapshots. The approach
follows the standalone Unicorn Live Viewer (``unicorn_live.py``).

Label markers go through the same thread. A key press only queues a code; the
acquisition thread writes it into the device's own marker row (BrainFlow's
``insert_marker``), so the board is only ever touched from one thread and the
label lands on the sample it belongs to. Sources without a marker row get the
code on the first sample of the next chunk instead.
"""

from __future__ import annotations

import queue
import threading
import time
from typing import Any, Callable, Iterable

import numpy as np

from ..core.types import Chunk
from .sources import Source


class AcquisitionThread:
    """Reads an already-started source on a background thread.

    Args:
        source: a :class:`Source` whose ``start()`` has already been called.
        recorder: optional; every chunk is added to it before any consumer
            sees it, so what is written is exactly what arrived.
        consumers: callables ``f(chunk)`` run on the acquisition thread for
            every chunk, in order -- e.g. filter and push into a ring buffer.
            They must be quick and must not touch the GUI.
        poll_s: wait between reads once the source has nothing new.

    ``error`` holds the reason if acquisition stopped by itself; ``problems``
    lists label markers that could not be placed.
    """

    def __init__(self, source: Source, recorder: Any = None,
                 consumers: Iterable[Callable[[Chunk], None]] = (),
                 poll_s: float = 0.02) -> None:
        self.source = source
        self.recorder = recorder
        self.consumers = list(consumers)
        self.poll_s = float(poll_s)
        self.lock = threading.Lock()
        self.error: str | None = None
        self.problems: list[str] = []
        self.total = 0
        self.last_received: float | None = None
        self._markers: queue.SimpleQueue[float] = queue.SimpleQueue()
        self._soft: list[float] = []
        self._native = callable(getattr(source, "insert_marker", None))
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._closed = False

    def start(self) -> None:
        if self._thread is not None or self._closed:
            raise RuntimeError("acquisition already started")
        self._thread = threading.Thread(target=self._run, name="neurobridge-acquisition",
                                        daemon=True)
        self._thread.start()

    def mark(self, code: float) -> None:
        """Queue a label marker for the next sample. Safe to call from any thread."""
        if code == 0:
            raise ValueError("marker code 0 means 'no marker'")
        self._markers.put(float(code))

    def seconds_since_data(self) -> float:
        """Seconds since the last chunk arrived; infinite before the first."""
        with self.lock:
            last = self.last_received
        return float("inf") if last is None else time.monotonic() - last

    def _step(self) -> bool:
        """Place queued markers, then read once. True if a chunk arrived."""
        while True:
            try:
                code = self._markers.get_nowait()
            except queue.Empty:
                break
            if self._native:
                try:
                    self.source.insert_marker(code)
                except Exception as exc:          # e.g. the stream already stopped
                    self.problems.append(f"marker {code:g} was not placed: {exc}")
            else:
                self._soft.append(code)
        chunk = self.source.read()
        if chunk is None:
            return False
        if not np.isfinite(chunk.data).all():
            raise ValueError("non-finite EEG samples received; acquisition stopped")
        if self._soft:
            aux = dict(chunk.aux or {})
            marker = np.array(aux.get("marker", np.zeros(chunk.n_samples)), dtype=np.float64)
            k = min(len(self._soft), chunk.n_samples)
            marker[:k] = self._soft[:k]
            del self._soft[:k]
            aux["marker"] = marker
            chunk.aux = aux
        if self.recorder is not None:
            self.recorder.add(chunk)
        for fn in self.consumers:
            fn(chunk)
        with self.lock:
            self.total += chunk.n_samples
            self.last_received = time.monotonic()
        return True

    def _run(self) -> None:
        try:
            while not self._stop.is_set():
                while not self._stop.is_set() and self._step():
                    pass
                self._stop.wait(self.poll_s)
        except Exception as exc:                  # surfaced through .error
            self.error = f"{type(exc).__name__}: {exc}"
            self._stop.set()

    def close(self) -> None:
        """Stop reading, drain what the device already delivered, release it.

        Samples the device has already buffered are still read and recorded,
        so closing the window does not cut off the end of a recording. Safe
        to call more than once.
        """
        if self._closed:
            return
        self._closed = True
        self._stop.set()
        if self._thread is not None:
            self._thread.join()
            self._thread = None
        try:
            if callable(getattr(self.source, "stop_stream", None)):
                self.source.stop_stream()
            if self.error is None:
                try:
                    while self._step():
                        pass
                except Exception as exc:
                    self.error = f"{type(exc).__name__}: {exc}"
        finally:
            self.source.stop()
