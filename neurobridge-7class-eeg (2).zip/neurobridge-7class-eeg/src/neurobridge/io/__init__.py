"""Acquisition sources and recording."""
