"""Entry point for ``python -m neurobridge``.

Installing the package creates a ``neurobridge.exe`` launcher on Windows, but
locked-down machines routinely block newly created executables under
Application Control or SmartScreen policies -- exactly the environment this
package targets. ``python -m neurobridge`` runs the same code through the
already-trusted Python interpreter and needs no separate executable, so it is
the form the documentation uses.
"""

import sys

from .cli import main

if __name__ == "__main__":
    sys.exit(main())
