"""neurobridge -- a hardware-agnostic, real-time EEG platform for teaching BCI.

Quick start (no hardware needed)::

    from neurobridge import Session
    with Session("configs/alpha_attention.yaml") as s:
        input("open web/index.html, then press Enter to stop...")
    print(s.report())

The package is organised in layers, each usable on its own:

    core        types, ring buffer, sliding window, pipeline, montage roles
    io          acquisition sources (synthetic, BrainFlow, replay) and recording
    process     causal filters, spectral and CCA features, signal quality
    classify    CSP, Riemannian tangent space, decoders, calibration screening
    transport   dependency-free WebSocket server, wire protocol, timing metrics
    education   curriculum graph, knowledge tracing, adaptive difficulty, logs
"""

from __future__ import annotations

__version__ = "0.1.0"

from .config import Config, ConfigError
from .core.buffer import RingBuffer, SlidingWindow
from .core.montage import Montage, ROLES
from .core.pipeline import Pipeline
from .core.types import Chunk, DeviceInfo, Epoch, Prediction
from .io.sources import BrainFlowSource, LSLSource, ReplaySource, Source, SyntheticSource
from .registry import available, register
from .session import Session

# Importing these registers their stages in the registry.
from .process import filters as _filters      # noqa: F401
from .process import features as _features    # noqa: F401
from .classify import decoders as _decoders   # noqa: F401

__all__ = [
    "__version__", "Session", "Config", "ConfigError",
    "Chunk", "DeviceInfo", "Epoch", "Prediction",
    "RingBuffer", "SlidingWindow", "Pipeline", "Montage", "ROLES",
    "Source", "SyntheticSource", "BrainFlowSource", "LSLSource", "ReplaySource",
    "register", "available",
]
