"""Name -> class registry.

Two jobs:

1. Let a YAML file say ``type: bandpower`` instead of importing a class.
2. Let someone else's package add a headset or a feature without editing this
   one, either by calling ``register()`` or by declaring an entry point in the
   ``neurobridge.plugins`` group.

Keeping registration explicit (rather than scanning modules) means an unknown
``type:`` in a config fails immediately with a list of valid options, which is
the error message a beginner actually needs.
"""

from __future__ import annotations

from typing import Any, Callable, TypeVar

T = TypeVar("T")

_REGISTRY: dict[str, dict[str, type]] = {
    "source": {},
    "transform": {},
    "extractor": {},
    "decoder": {},
    "transport": {},
}


def register(kind: str, name: str) -> Callable[[type[T]], type[T]]:
    """Class decorator: ``@register("extractor", "bandpower")``."""
    if kind not in _REGISTRY:
        raise KeyError(f"unknown kind {kind!r}; expected one of {list(_REGISTRY)}")

    def _wrap(cls: type[T]) -> type[T]:
        _REGISTRY[kind][name] = cls
        return cls

    return _wrap


def get(kind: str, name: str) -> type:
    try:
        return _REGISTRY[kind][name]
    except KeyError:
        available = sorted(_REGISTRY.get(kind, {}))
        raise KeyError(
            f"no {kind} registered as {name!r}. Available: {available}"
        ) from None


def build(kind: str, spec: dict[str, Any]) -> Any:
    """Instantiate from a config dict of the form ``{'type': ..., **kwargs}``."""
    spec = dict(spec)
    name = spec.pop("type", None)
    if name is None:
        raise KeyError(f"{kind} spec is missing a 'type' key: {spec}")
    return get(kind, name)(**spec)


def available(kind: str) -> list[str]:
    return sorted(_REGISTRY[kind])


def load_plugins() -> None:
    """Import third-party packages advertising the ``neurobridge.plugins`` group."""
    from importlib.metadata import entry_points

    for ep in entry_points(group="neurobridge.plugins"):
        ep.load()
