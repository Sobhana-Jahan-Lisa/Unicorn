"""Real-time performance instrumentation.

These numbers are study outcomes, not debug output. A claim that a system is
"real-time" is unfalsifiable without them, and the BCI game literature is
criticised precisely for reporting control accuracy while leaving timing
unmeasured. Everything here is designed to be reported in a paper:

* **End-to-end latency** is measured from the *start of the analysed window*,
  not from the moment the pipeline happened to run. A 1 s window inherently
  carries up to 1 s of evidence age; hiding that by timing only the compute
  step would flatter the system by an order of magnitude. The breakdown is
  reported as ``window + filter group delay + compute + transport``.

* **Jitter** uses the RFC 3550 interarrival estimator::

      D(i-1, i) = (R_i - R_{i-1}) - (S_i - S_{i-1})
      J_i = J_{i-1} + (|D(i-1, i)| - J_{i-1}) / 16

  which is an exponentially weighted mean deviation, robust to the occasional
  outlier in a way that a running standard deviation is not.

* **Loss** is computed from sequence gaps, so a dropped message is counted even
  when the connection stays up -- the failure mode that backpressure creates.

* Percentiles are reported instead of means. A mean latency of 80 ms with a
  p95 of 600 ms is a system that feels broken, and the mean conceals it.
"""

from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass, field

import numpy as np
from ..core.clock import now


@dataclass
class LatencyBudget:
    """Static, additive components of end-to-end delay, in seconds.

    Filled in at session start from the actual configuration so a paper can
    report where the delay comes from rather than only its total.
    """

    window: float = 0.0            # evidence age from the analysis window
    filter_group_delay: float = 0.0
    step: float = 0.0              # quantisation from the update interval

    @property
    def structural_ms(self) -> float:
        """Delay that no amount of optimisation can remove, given this config."""
        return 1000.0 * (self.window / 2.0 + self.filter_group_delay + self.step / 2.0)

    def to_dict(self) -> dict:
        return {
            "window_s": self.window,
            "filter_group_delay_s": round(self.filter_group_delay, 5),
            "step_s": self.step,
            "structural_latency_ms": round(self.structural_ms, 2),
            "note": (
                "structural latency uses the window midpoint as the effective "
                "evidence time; add measured compute and transport latency for "
                "the end-to-end figure"
            ),
        }


class Metrics:
    """Rolling timing statistics for one session."""

    def __init__(self, maxlen: int = 2000) -> None:
        self.latency = deque(maxlen=maxlen)          # seconds, window start -> emit
        self.compute = deque(maxlen=maxlen)          # seconds, pipeline only
        self.rtt = deque(maxlen=200)                 # seconds, echo round trip
        self._jitter = 0.0
        self._last_send: float | None = None
        self._last_recv: float | None = None
        self.expected = 0
        self.received = 0
        self.gaps = 0
        self._last_seq: int | None = None
        self.dropped_by_backpressure = 0
        self.budget = LatencyBudget()
        self.frame_times: deque = deque(maxlen=200)

    # -- recording ---------------------------------------------------------

    def record_epoch(self, t_epoch: float, t_emit: float,
                     t_compute_start: float | None = None) -> None:
        self.latency.append(max(0.0, t_emit - t_epoch))
        if t_compute_start is not None:
            self.compute.append(max(0.0, t_emit - t_compute_start))

    def record_arrival(self, t_sent: float, t_received: float | None = None) -> None:
        """Update the RFC 3550 jitter estimate from one message pair."""
        t_received = t_received if t_received is not None else now()
        if self._last_send is not None and self._last_recv is not None:
            d = (t_received - self._last_recv) - (t_sent - self._last_send)
            self._jitter += (abs(d) - self._jitter) / 16.0
        self._last_send, self._last_recv = t_sent, t_received

    def record_sequence(self, seq: int) -> None:
        self.received += 1
        if self._last_seq is not None and seq > self._last_seq + 1:
            self.gaps += seq - self._last_seq - 1
        if self._last_seq is None or seq > self._last_seq:
            self._last_seq = seq
        self.expected = (self._last_seq or 0) + 1

    def record_rtt(self, seconds: float) -> None:
        self.rtt.append(max(0.0, seconds))

    def record_frame(self) -> None:
        self.frame_times.append(now())

    # -- reporting ---------------------------------------------------------

    @staticmethod
    def _pct(values: deque, q: float) -> float:
        if not values:
            return float("nan")
        return float(np.percentile(np.fromiter(values, float), q) * 1000.0)

    @property
    def jitter_ms(self) -> float:
        return self._jitter * 1000.0

    @property
    def loss_rate(self) -> float:
        return self.gaps / max(self.expected, 1)

    @property
    def fps(self) -> float:
        if len(self.frame_times) < 2:
            return 0.0
        span = self.frame_times[-1] - self.frame_times[0]
        return (len(self.frame_times) - 1) / span if span > 0 else 0.0

    def snapshot(self) -> dict:
        return {
            "latency_ms_p50": round(self._pct(self.latency, 50), 2),
            "latency_ms_p95": round(self._pct(self.latency, 95), 2),
            "latency_ms_max": round(self._pct(self.latency, 100), 2),
            "compute_ms_p50": round(self._pct(self.compute, 50), 2),
            "compute_ms_p95": round(self._pct(self.compute, 95), 2),
            "rtt_ms_p50": round(self._pct(self.rtt, 50), 2),
            "jitter_ms": round(self.jitter_ms, 2),
            "loss_rate": round(self.loss_rate, 5),
            "n_windows": len(self.latency),
            "dropped_by_backpressure": self.dropped_by_backpressure,
            "fps": round(self.fps, 1),
            "budget": self.budget.to_dict(),
        }

    def report(self) -> str:
        """Human-readable summary, suitable for pasting into a lab notebook."""
        s = self.snapshot()
        return (
            f"windows={s['n_windows']}  "
            f"latency p50={s['latency_ms_p50']} ms p95={s['latency_ms_p95']} ms  "
            f"compute p95={s['compute_ms_p95']} ms  "
            f"jitter={s['jitter_ms']} ms  loss={s['loss_rate']:.3%}  "
            f"dropped={s['dropped_by_backpressure']}"
        )
