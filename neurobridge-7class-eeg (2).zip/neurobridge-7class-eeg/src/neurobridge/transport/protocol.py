"""Wire protocol between the Python pipeline and the browser.

Design rules
------------
1. **Versioned.** Every message carries ``v``. A browser that receives a
   version it does not understand says so instead of silently mis-rendering.
2. **Bidirectional and symmetric.** Downstream (Python -> browser) carries
   neural state; upstream (browser -> Python) carries game and learning events.
   Both directions are logged with the same timebase, which is what makes the
   education analysis possible: you can align "the student answered question 7
   incorrectly" with the EEG features from the ten seconds before it.
3. **Privacy-tiered.** ``raw`` messages are opt-in and off by default. In the
   default ``derived`` tier nothing leaves the machine except band powers and
   control values, so no raw neural recording of a minor crosses a network
   boundary at all. The tier is stamped into every message, so a recording can
   be audited after the fact.
4. **Small.** A ``neuro`` message at 4 Hz with 8 channels of band power is a
   few hundred bytes; the schema avoids nesting so a browser can parse it
   without allocation pressure.

All timestamps are float seconds on a single shared monotonic clock,
established at session start and communicated in the ``hello`` handshake.
"""

from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from typing import Any, Literal
from ..core.clock import now

PROTOCOL_VERSION = "1.0"

PrivacyTier = Literal["derived", "features", "raw"]

#: Messages Python sends to the browser.
DOWNSTREAM = {
    "hello",       # handshake: device, montage, protocol version, clock origin
    "neuro",       # per-window control value + features + quality
    "quality",     # periodic signal-quality report
    "calibration", # calibration progress and result
    "lesson",      # lesson/concept state pushed from the curriculum engine
    "metrics",     # transport latency/jitter/loss snapshot
    "error",
}

#: Messages the browser sends to Python.
UPSTREAM = {
    "ready",       # browser is up, reports its own clock and capabilities
    "game",        # game state: score, level, difficulty, target
    "learning",    # learning event: concept, question, response, correctness
    "control",     # request: start/stop/calibrate/set-paradigm
    "echo",        # round-trip latency probe
}


def _now() -> float:
    return now()


@dataclass
class Message:
    """Base envelope. ``t`` is the send time on the shared monotonic clock."""

    type: str
    t: float = field(default_factory=_now)
    v: str = PROTOCOL_VERSION
    seq: int = 0

    def to_json(self) -> str:
        return json.dumps(asdict(self), separators=(",", ":"), default=_default)


def _default(o: Any) -> Any:
    if hasattr(o, "tolist"):
        return o.tolist()
    if hasattr(o, "item"):
        return o.item()
    raise TypeError(f"cannot serialise {type(o).__name__}")


@dataclass
class Hello(Message):
    type: str = "hello"
    device: str = ""
    sfreq: float = 0.0
    channels: list[str] = field(default_factory=list)
    montage: dict[str, Any] = field(default_factory=dict)
    paradigm: str = ""
    privacy_tier: str = "derived"
    window: float = 1.0
    step: float = 0.25
    session_id: str = ""


@dataclass
class Neuro(Message):
    """One decoded window. The message the game loop actually consumes."""

    type: str = "neuro"
    value: Any = 0.0                      # control signal (float, int, or label)
    confidence: float = 1.0
    features: dict[str, float] = field(default_factory=dict)
    quality: float = 1.0                  # mean channel quality, 0-1
    reject: bool = False                  # artefact detected in this window
    t_epoch: float = 0.0                  # start of the analysed window
    latency_ms: float = 0.0               # t_emit - t_epoch, measured


@dataclass
class Quality(Message):
    type: str = "quality"
    mean_score: float = 1.0
    per_channel: dict[str, float] = field(default_factory=dict)
    advice: list[str] = field(default_factory=list)


@dataclass
class Calibration(Message):
    """Calibration state. ``blocks`` is the whole instructed script, sent once
    when calibration starts, so the browser can run the countdown itself and
    only report block boundaries back. Keeping the timing in the browser means
    the instruction a student sees and the label attached to their EEG cannot
    drift apart by a network round trip."""

    type: str = "calibration"
    phase: str = "idle"                   # idle|running|done|failed
    block: str = ""
    instruction: str = ""
    progress: float = 0.0                 # 0-1
    blocks: list[dict[str, Any]] = field(default_factory=list)
    result: dict[str, Any] | None = None
    message: str = ""


@dataclass
class Lesson(Message):
    """Current concept, the next item, and the verdict on the previous answer.

    ``feedback`` is how grading gets back to the browser. The correct-answer
    index is never sent with the question -- only afterwards, with the
    explanation -- so a student reading the console cannot see the answer
    before choosing, and cannot report their own score.
    """

    type: str = "lesson"
    concept_id: str = ""
    title: str = ""
    body: str = ""
    difficulty: float = 0.5
    prompt: dict[str, Any] | None = None
    feedback: dict[str, Any] | None = None
    mastery: dict[str, float] = field(default_factory=dict)


@dataclass
class Metrics(Message):
    type: str = "metrics"
    latency_ms_p50: float = 0.0
    latency_ms_p95: float = 0.0
    jitter_ms: float = 0.0
    loss_rate: float = 0.0
    rtt_ms: float = 0.0
    dropped_messages: int = 0
    fps: float = 0.0


@dataclass
class ErrorMsg(Message):
    type: str = "error"
    code: str = ""
    detail: str = ""


# ---------------------------------------------------------------------------
# Upstream validation
# ---------------------------------------------------------------------------

class ProtocolError(ValueError):
    """Raised on a malformed or unsupported upstream message."""


_REQUIRED: dict[str, tuple[str, ...]] = {
    "ready": (),
    "game": ("state",),
    "learning": ("event",),
    "control": ("action",),
    "echo": ("t_client",),
}

_ALLOWED_ACTIONS = {"start", "stop", "calibrate", "calibration_block",
                    "calibration_finish", "set_paradigm", "set_difficulty",
                    "set_privacy"}


def parse_upstream(payload: str) -> dict[str, Any]:
    """Validate and normalise a message from the browser.

    The browser is untrusted input like any other network peer -- a student can
    open the console. Validation happens here and only here, so no downstream
    module has to defend itself.
    """
    try:
        msg = json.loads(payload)
    except json.JSONDecodeError as exc:
        raise ProtocolError(f"not valid JSON: {exc}") from None
    if not isinstance(msg, dict):
        raise ProtocolError("top-level message must be an object")

    mtype = msg.get("type")
    if mtype not in UPSTREAM:
        raise ProtocolError(f"unknown message type {mtype!r}; expected one of "
                            f"{sorted(UPSTREAM)}")

    version = msg.get("v", PROTOCOL_VERSION)
    if str(version).split(".")[0] != PROTOCOL_VERSION.split(".")[0]:
        raise ProtocolError(
            f"protocol major version mismatch: browser sent {version}, "
            f"server speaks {PROTOCOL_VERSION}"
        )

    for key in _REQUIRED[mtype]:
        if key not in msg:
            raise ProtocolError(f"{mtype!r} message is missing required key {key!r}")

    if mtype == "control" and msg["action"] not in _ALLOWED_ACTIONS:
        raise ProtocolError(f"unknown action {msg['action']!r}; expected one of "
                            f"{sorted(_ALLOWED_ACTIONS)}")

    if mtype == "learning":
        ev = msg["event"]
        if not isinstance(ev, dict) or "kind" not in ev:
            raise ProtocolError("learning.event must be an object with a 'kind'")

    msg.setdefault("t", _now())
    return msg
