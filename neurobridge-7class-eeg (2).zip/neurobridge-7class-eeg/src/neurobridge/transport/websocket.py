"""A WebSocket server built on the standard library only.

Why not use an existing library
-------------------------------
Every dependency is a barrier in a school. A teacher on a locked-down machine
with no admin rights and a firewall that blocks PyPI can still run this: numpy
and scipy come with any scientific Python install, and the transport adds
nothing. The RFC 6455 subset needed for a local, single-origin, text-only
connection is about two hundred lines, and implementing it here also makes the
latency path fully visible -- which matters when latency is a reported outcome
rather than an implementation detail.

Backpressure
------------
The browser is the slow consumer. A tab in the background gets its timers
throttled, and a laptop rendering a game at 30 fps can stall for a hundred
milliseconds at a time. If the server simply queues everything, the game
receives an ever-growing backlog of stale neural state, and the control signal
appears to lag further behind reality the longer the session runs. That failure
is invisible in a short demo and ruinous in a 30-minute lesson.

The policy here is explicit: neural state is **latest-value-wins**. When a
client's queue is full, older ``neuro`` messages are dropped rather than the
newest, because a control signal from 400 ms ago has no value. Messages that
carry state transitions -- ``calibration``, ``lesson``, ``hello`` -- are never
dropped; they are queued without limit and the connection is closed if the
client cannot keep up. Every drop is counted and reported in the ``metrics``
message, so the study can state exactly how much data the transport shed.
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import queue
import socket
import struct
import threading
from collections.abc import Callable
from typing import Any

log = logging.getLogger("neurobridge.transport")

_GUID = "258EAFA5-E914-47DA-95CA-5AB0DC85B11C"

OP_CONT, OP_TEXT, OP_BIN, OP_CLOSE, OP_PING, OP_PONG = 0x0, 0x1, 0x2, 0x8, 0x9, 0xA

#: Message types that may be dropped under backpressure (latest-value-wins).
DROPPABLE = {"neuro", "quality", "metrics"}


class Frame:
    """Minimal RFC 6455 framing."""

    @staticmethod
    def encode(payload: bytes, opcode: int = OP_TEXT) -> bytes:
        """Server-to-client frames are never masked (RFC 6455 section 5.1)."""
        header = bytearray()
        header.append(0x80 | opcode)                    # FIN + opcode
        n = len(payload)
        if n < 126:
            header.append(n)
        elif n < (1 << 16):
            header.append(126)
            header += struct.pack("!H", n)
        else:
            header.append(127)
            header += struct.pack("!Q", n)
        return bytes(header) + payload

    @staticmethod
    def read(sock: socket.socket) -> tuple[int, bytes] | None:
        """Read one complete message, reassembling continuation frames."""
        opcode_first: int | None = None
        chunks: list[bytes] = []

        while True:
            head = _recv_exact(sock, 2)
            if head is None:
                return None
            b0, b1 = head[0], head[1]
            fin = bool(b0 & 0x80)
            opcode = b0 & 0x0F
            masked = bool(b1 & 0x80)
            length = b1 & 0x7F

            if length == 126:
                ext = _recv_exact(sock, 2)
                if ext is None:
                    return None
                length = struct.unpack("!H", ext)[0]
            elif length == 127:
                ext = _recv_exact(sock, 8)
                if ext is None:
                    return None
                length = struct.unpack("!Q", ext)[0]

            if length > 8 * 1024 * 1024:
                raise ValueError(f"frame of {length} bytes exceeds the 8 MiB limit")

            mask = None
            if masked:
                mask = _recv_exact(sock, 4)
                if mask is None:
                    return None

            payload = _recv_exact(sock, length) if length else b""
            if payload is None:
                return None
            if mask:
                payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))

            # Control frames may be interleaved and are never fragmented.
            if opcode in (OP_CLOSE, OP_PING, OP_PONG):
                return opcode, payload

            if opcode_first is None:
                opcode_first = opcode
            chunks.append(payload)
            if fin:
                return opcode_first, b"".join(chunks)


def _recv_exact(sock: socket.socket, n: int) -> bytes | None:
    buf = bytearray()
    while len(buf) < n:
        try:
            part = sock.recv(n - len(buf))
        except (OSError, socket.timeout):
            return None
        if not part:
            return None
        buf += part
    return bytes(buf)


class Client:
    """One connected browser, with its own writer thread and bounded queue."""

    def __init__(self, sock: socket.socket, addr: Any, maxsize: int = 64) -> None:
        self.sock = sock
        self.addr = addr
        self.queue: queue.Queue = queue.Queue(maxsize=maxsize)
        self.alive = True
        self.dropped = 0
        self.sent = 0
        self._lock = threading.Lock()

    def send(self, message: str, mtype: str = "neuro") -> bool:
        """Enqueue a message; drop the oldest droppable one if the queue is full."""
        if not self.alive:
            return False
        try:
            self.queue.put_nowait((mtype, message))
            return True
        except queue.Full:
            if mtype in DROPPABLE:
                # Latest-value-wins: discard the head, then enqueue.
                try:
                    self.queue.get_nowait()
                    self.dropped += 1
                    self.queue.put_nowait((mtype, message))
                    return True
                except (queue.Empty, queue.Full):
                    self.dropped += 1
                    return False

            # A state message must never be dropped, but the backlog blocking it
            # is almost always neuro/quality traffic we already promised to
            # shed. Evict the oldest droppable entry to make room. Closing here
            # instead would disconnect a healthy client for the sole reason that
            # it briefly stopped reading -- which is what a backgrounded tab or
            # a slow socket buffer looks like, and is not a fault.
            if self._evict_droppable():
                try:
                    self.queue.put_nowait((mtype, message))
                    return True
                except queue.Full:
                    pass

            # Nothing droppable to evict: the queue is full of state messages,
            # so the client genuinely cannot keep up and the connection goes.
            log.warning("client %s cannot keep up with %s messages; closing",
                        self.addr, mtype)
            self.close()
            return False

    def _evict_droppable(self) -> bool:
        """Remove the oldest droppable entry, preserving the order of the rest.

        Best-effort: the writer thread may take from the queue concurrently, in
        which case at worst one message is sent slightly out of order. That is
        preferable to holding the writer's lock across a queue rebuild, which
        would stall every client on the slowest one.
        """
        kept: list[tuple[str, str]] = []
        evicted = False
        try:
            while True:
                item = self.queue.get_nowait()
                if not evicted and item[0] in DROPPABLE:
                    evicted = True
                    self.dropped += 1
                    continue
                kept.append(item)
        except queue.Empty:
            pass
        for item in kept:
            try:
                self.queue.put_nowait(item)
            except queue.Full:
                self.dropped += 1
        return evicted

    def writer_loop(self) -> None:
        while self.alive:
            try:
                _, msg = self.queue.get(timeout=0.5)
            except queue.Empty:
                continue
            try:
                with self._lock:
                    self.sock.sendall(Frame.encode(msg.encode("utf-8")))
                self.sent += 1
            except OSError:
                self.close()
                return

    def ping(self) -> None:
        try:
            with self._lock:
                self.sock.sendall(Frame.encode(b"", OP_PING))
        except OSError:
            self.close()

    def close(self) -> None:
        if not self.alive:
            return
        self.alive = False
        try:
            self.sock.sendall(Frame.encode(b"", OP_CLOSE))
        except OSError:
            pass
        try:
            self.sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        self.sock.close()


class WebSocketServer:
    """Threaded WebSocket server bound to localhost by default.

    Args:
        host: bind address. Defaults to ``127.0.0.1`` deliberately -- neural
            data from a minor should not be reachable from the school network
            unless someone makes that choice explicitly.
        port: TCP port.
        on_message: callback ``(client, dict) -> None`` for validated upstream
            messages. Runs on the reader thread, so it must not block.
        queue_size: per-client outbound queue depth. At 4 Hz updates, 64 slots
            is 16 s of backlog -- far more than a healthy client ever uses, so
            hitting the limit is itself diagnostic.
    """

    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 8765,
        on_message: Callable[[Client, dict], None] | None = None,
        on_connect: Callable[[Client], None] | None = None,
        on_disconnect: Callable[[Client], None] | None = None,
        queue_size: int = 64,
        allowed_origins: tuple[str, ...] | None = None,
    ) -> None:
        self.host, self.port = host, port
        self.on_message = on_message
        self.on_connect = on_connect
        self.on_disconnect = on_disconnect
        self.queue_size = queue_size
        self.allowed_origins = allowed_origins
        self.clients: list[Client] = []
        self._server: socket.socket | None = None
        self._running = False
        self._lock = threading.Lock()
        self._seq = 0

    # -- lifecycle ---------------------------------------------------------

    def start(self) -> None:
        self._server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._server.bind((self.host, self.port))
        self._server.listen(8)
        self._server.settimeout(0.5)
        self._running = True
        threading.Thread(target=self._accept_loop, daemon=True,
                         name="ws-accept").start()
        log.info("websocket server listening on ws://%s:%d", self.host, self.port)

    def stop(self) -> None:
        self._running = False
        with self._lock:
            for c in list(self.clients):
                c.close()
            self.clients.clear()
        if self._server:
            try:
                self._server.close()
            except OSError:
                pass
            self._server = None

    def __enter__(self) -> "WebSocketServer":
        self.start()
        return self

    def __exit__(self, *exc: Any) -> None:
        self.stop()

    # -- connection handling ----------------------------------------------

    def _accept_loop(self) -> None:
        while self._running and self._server is not None:
            try:
                sock, addr = self._server.accept()
            except socket.timeout:
                continue
            except OSError:
                return
            threading.Thread(target=self._handle, args=(sock, addr),
                             daemon=True, name=f"ws-{addr[1]}").start()

    def _handshake(self, sock: socket.socket) -> bool:
        sock.settimeout(5.0)
        data = b""
        while b"\r\n\r\n" not in data:
            part = sock.recv(4096)
            if not part:
                return False
            data += part
            if len(data) > 16384:
                return False

        lines = data.decode("latin-1").split("\r\n")
        headers = {}
        for line in lines[1:]:
            if ": " in line:
                k, v = line.split(": ", 1)
                headers[k.lower()] = v

        key = headers.get("sec-websocket-key")
        if not key or headers.get("upgrade", "").lower() != "websocket":
            sock.sendall(b"HTTP/1.1 400 Bad Request\r\n\r\n")
            return False

        if self.allowed_origins is not None:
            origin = headers.get("origin", "")
            if origin not in self.allowed_origins:
                log.warning("rejected websocket from origin %r", origin)
                sock.sendall(b"HTTP/1.1 403 Forbidden\r\n\r\n")
                return False

        accept = base64.b64encode(
            hashlib.sha1((key + _GUID).encode("latin-1")).digest()
        ).decode()
        sock.sendall(
            b"HTTP/1.1 101 Switching Protocols\r\n"
            b"Upgrade: websocket\r\n"
            b"Connection: Upgrade\r\n"
            b"Sec-WebSocket-Accept: " + accept.encode() + b"\r\n\r\n"
        )
        sock.settimeout(None)
        return True

    def _handle(self, sock: socket.socket, addr: Any) -> None:
        # The client is registered BEFORE the handshake completes, so a
        # broadcast issued in the moment between the browser's 101 response and
        # the server finishing setup is queued rather than lost. The writer
        # thread has not started yet, so nothing is written to the socket
        # before the upgrade response -- messages simply wait in the queue.
        client = Client(sock, addr, maxsize=self.queue_size)
        with self._lock:
            self.clients.append(client)

        try:
            ok = self._handshake(sock)
        except OSError:
            ok = False
        if not ok:
            with self._lock:
                if client in self.clients:
                    self.clients.remove(client)
            client.alive = False
            sock.close()
            return

        threading.Thread(target=client.writer_loop, daemon=True,
                         name=f"ws-w-{addr[1]}").start()
        if self.on_connect:
            self.on_connect(client)

        try:
            while client.alive:
                frame = Frame.read(sock)
                if frame is None:
                    break
                opcode, payload = frame
                if opcode == OP_CLOSE:
                    break
                if opcode == OP_PING:
                    with client._lock:
                        sock.sendall(Frame.encode(payload, OP_PONG))
                    continue
                if opcode == OP_PONG:
                    continue
                if opcode != OP_TEXT:
                    continue
                if self.on_message:
                    from .protocol import ProtocolError, parse_upstream
                    try:
                        msg = parse_upstream(payload.decode("utf-8"))
                    except ProtocolError as exc:
                        client.send(
                            json.dumps({"type": "error", "code": "protocol",
                                        "detail": str(exc)}), "error")
                        continue
                    try:
                        self.on_message(client, msg)
                    except Exception:                       # never kill the loop
                        log.exception("on_message handler raised")
        except (OSError, ValueError) as exc:
            log.debug("connection %s ended: %s", addr, exc)
        finally:
            client.close()
            with self._lock:
                if client in self.clients:
                    self.clients.remove(client)
            if self.on_disconnect:
                self.on_disconnect(client)

    # -- sending -----------------------------------------------------------

    def broadcast(self, message: Any, mtype: str | None = None) -> int:
        """Send to every connected client. Returns the number that accepted it."""
        if hasattr(message, "to_json"):
            self._seq += 1
            message.seq = self._seq
            mtype = mtype or message.type
            payload = message.to_json()
        elif isinstance(message, dict):
            mtype = mtype or message.get("type", "neuro")
            payload = json.dumps(message, separators=(",", ":"))
        else:
            payload = str(message)
            mtype = mtype or "neuro"

        with self._lock:
            clients = list(self.clients)
        return sum(c.send(payload, mtype) for c in clients)

    @property
    def n_clients(self) -> int:
        with self._lock:
            return len(self.clients)

    @property
    def dropped(self) -> int:
        with self._lock:
            return sum(c.dropped for c in self.clients)
