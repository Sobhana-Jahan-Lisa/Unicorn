"""Feature extraction.

Every extractor returns ``dict[str, float]`` so features are self-describing all
the way to the browser -- a student can see ``alpha_PO7 = 14.2`` rather than an
anonymous vector position. That costs a little speed and buys a great deal of
teachability.

Mathematical notes
------------------
**Band power.** Computed from Welch's averaged periodogram with a Hann window::

    P_xx(f) = (1/K) * sum_k |FFT(w * x_k)|^2 / (fs * sum(w^2))

with ``scaling='density'``, so ``P_xx`` is in uV^2/Hz. Absolute band power is
the integral of the density over the band, evaluated by the trapezoid rule::

    P_band = integral_{f_lo}^{f_hi} P_xx(f) df

Two constraints are enforced rather than assumed:

* The frequency resolution ``df = fs / nperseg`` must be finer than the band
  being measured, otherwise the "theta power" you report is an artefact of the
  bin grid. A band narrower than ``2*df`` raises.
* Welch trades variance for resolution. With a 1 s window at 250 Hz there is
  room for either one segment (1 Hz resolution, high variance) or several
  shorter ones (coarse resolution, lower variance). The default keeps a single
  Hann-tapered segment and relies on temporal smoothing downstream, which is
  the right trade for a control signal that must respond within a second.

**Relative power.** ``P_band / P_total`` over a stated broadband range. Relative
power is the correct default for cross-subject and cross-headset comparison
because it cancels the unknown scalar gain from electrode impedance and skull
thickness -- exactly the nuisance factor that differs between a lab and a
classroom.

**CCA for SSVEP.** For window ``X`` (channels x samples) and reference set
``Y_f`` built from sines and cosines at ``f`` and its harmonics, the canonical
correlation is::

    rho(f) = max_{a,b}  corr(a^T X, b^T Y_f)

solved numerically through QR decompositions and an SVD rather than by forming
``Sxx^-1`` explicitly, which is ill-conditioned when channels are correlated
(always true for EEG).
"""

from __future__ import annotations

import numpy as np
from scipy import linalg, signal

from ..core.pipeline import BaseStage
from ..core.types import Epoch
from ..registry import register

#: Standard clinical bands (Hz). Deliberately non-overlapping and contiguous.
BANDS: dict[str, tuple[float, float]] = {
    "delta": (1.0, 4.0),
    "theta": (4.0, 8.0),
    "alpha": (8.0, 13.0),
    "beta": (13.0, 30.0),
    "gamma": (30.0, 45.0),
}


def welch_psd(
    data: np.ndarray,
    sfreq: float,
    nperseg: int | None = None,
    noverlap: int | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """Welch power spectral density in uV^2/Hz.

    Returns:
        freqs: shape (n_freqs,)
        psd:   shape (n_channels, n_freqs)
    """
    n = data.shape[-1]
    if nperseg is None:
        nperseg = n                      # one segment: best resolution
    nperseg = min(int(nperseg), n)
    if noverlap is None:
        noverlap = nperseg // 2
    noverlap = min(int(noverlap), nperseg - 1)
    freqs, psd = signal.welch(
        data, fs=sfreq, window="hann", nperseg=nperseg,
        noverlap=noverlap, scaling="density", axis=-1, detrend="constant",
    )
    return freqs, np.atleast_2d(psd)


def integrate_band(
    freqs: np.ndarray, psd: np.ndarray, lo: float, hi: float
) -> np.ndarray:
    """Integrate a PSD over [lo, hi] with the trapezoid rule.

    Raises if the band is narrower than two frequency bins, because the result
    would be dominated by grid placement rather than by the signal.
    """
    df = float(freqs[1] - freqs[0])
    if (hi - lo) < 2 * df:
        raise ValueError(
            f"band [{lo}, {hi}] Hz is {hi - lo:.2f} Hz wide but the frequency "
            f"resolution is {df:.2f} Hz. Lengthen the analysis window to at "
            f"least {2 / (hi - lo):.2f} s, or widen the band."
        )
    mask = (freqs >= lo) & (freqs <= hi)
    if mask.sum() < 2:
        raise ValueError(f"fewer than 2 frequency bins inside [{lo}, {hi}] Hz")
    return np.trapezoid(psd[:, mask], freqs[mask], axis=-1)


@register("extractor", "bandpower")
class BandPower(BaseStage):
    """Absolute and/or relative power in named bands, per channel or averaged.

    Args:
        bands: mapping name -> (lo, hi). Defaults to the standard five.
        channels: channel names to use; None uses all EEG channels.
        relative: if True, divide each band by total power in ``total_band``.
        total_band: denominator range for relative power.
        aggregate: 'mean' averages over channels into one value per band;
            'none' emits one value per band per channel (``alpha_PO7``).
        log: return ``10*log10(P)``. Power is log-normally distributed across
            time and subjects, so logging is what makes downstream linear
            models and thresholds behave. Ignored when ``relative=True``.
    """

    def __init__(
        self,
        bands: dict[str, tuple[float, float]] | None = None,
        channels: list[str] | None = None,
        relative: bool = True,
        total_band: tuple[float, float] = (1.0, 45.0),
        aggregate: str = "mean",
        log: bool = False,
        nperseg: int | None = None,
    ) -> None:
        self.bands = dict(bands or BANDS)
        self.channels = channels
        self.relative = relative
        self.total_band = tuple(total_band)
        self.aggregate = aggregate
        self.log = log
        self.nperseg = nperseg
        self._record(bands=self.bands, channels=channels, relative=relative,
                     total_band=list(total_band), aggregate=aggregate, log=log,
                     nperseg=nperseg)

    def __call__(self, epoch: Epoch) -> dict[str, float]:
        if self.channels:
            idx = [epoch.ch_names.index(c) for c in self.channels]
            data, names = epoch.data[idx], [epoch.ch_names[i] for i in idx]
        else:
            data, names = epoch.data, list(epoch.ch_names)

        freqs, psd = welch_psd(data, epoch.sfreq, nperseg=self.nperseg)
        total = integrate_band(freqs, psd, *self.total_band) if self.relative else None

        out: dict[str, float] = {}
        for band, (lo, hi) in self.bands.items():
            p = integrate_band(freqs, psd, lo, hi)
            if self.relative:
                p = p / np.maximum(total, 1e-12)
            elif self.log:
                p = 10.0 * np.log10(np.maximum(p, 1e-12))
            if self.aggregate == "mean":
                out[band] = float(np.mean(p))
            else:
                for name, v in zip(names, p):
                    out[f"{band}_{name}"] = float(v)
        return out


@register("extractor", "attention")
class AttentionIndex(BaseStage):
    """Composite engagement/attention indices from band ratios.

    Emits three quantities with different literatures behind them:

    * ``engagement`` = beta / (alpha + theta)  -- the Pope-style engagement
      index used in adaptive automation and neurofeedback.
    * ``theta_beta`` = theta / beta  -- the ratio most often reported in
      attention research; higher values are associated with inattention.
    * ``alpha_suppression`` = 1 - alpha_rel / alpha_baseline -- eyes-open
      desynchronisation relative to a calibrated resting level.

    ``alpha_baseline`` must be set by the calibration routine before
    ``alpha_suppression`` is meaningful; until then it is reported as NaN
    rather than as a fabricated zero.
    """

    def __init__(
        self,
        channels: list[str] | None = None,
        alpha_baseline: float | None = None,
        smooth: float = 0.3,
    ) -> None:
        self.channels = channels
        self.alpha_baseline = alpha_baseline
        self.smooth = float(smooth)
        self._ema: dict[str, float] = {}
        self._bp = BandPower(channels=channels, relative=True, aggregate="mean")
        self._record(channels=channels, alpha_baseline=alpha_baseline,
                     smooth=smooth)

    def _ema_update(self, key: str, value: float) -> float:
        """Exponentially weighted mean: s_t = a*x_t + (1-a)*s_{t-1}."""
        prev = self._ema.get(key)
        s = value if prev is None else self.smooth * value + (1 - self.smooth) * prev
        self._ema[key] = s
        return s

    def __call__(self, epoch: Epoch) -> dict[str, float]:
        b = self._bp(epoch)
        alpha, theta, beta = b["alpha"], b["theta"], b["beta"]
        eng = beta / max(alpha + theta, 1e-12)
        tb = theta / max(beta, 1e-12)
        out = {
            "alpha": alpha, "theta": theta, "beta": beta,
            "engagement": self._ema_update("engagement", float(eng)),
            "theta_beta": self._ema_update("theta_beta", float(tb)),
        }
        if self.alpha_baseline:
            out["alpha_suppression"] = float(
                self._ema_update(
                    "supp", 1.0 - alpha / max(self.alpha_baseline, 1e-12)
                )
            )
        else:
            out["alpha_suppression"] = float("nan")
        return out


@register("extractor", "asymmetry")
class FrontalAsymmetry(BaseStage):
    """Frontal alpha asymmetry: ln(alpha_right) - ln(alpha_left).

    The log difference is the standard form because alpha power is
    log-normal and the difference of logs is a scale-free ratio, which cancels
    the per-subject gain that plain subtraction would leave in.

    Since alpha is inversely related to cortical activity, a *positive* value
    indicates relatively greater left-frontal activity. Report the sign
    convention alongside the number; the literature is littered with papers
    that did not.
    """

    def __init__(self, left: list[str], right: list[str],
                 band: tuple[float, float] = (8.0, 13.0)) -> None:
        self.left, self.right, self.band = left, right, tuple(band)
        self._record(left=left, right=right, band=list(band))

    def __call__(self, epoch: Epoch) -> dict[str, float]:
        li = [epoch.ch_names.index(c) for c in self.left]
        ri = [epoch.ch_names.index(c) for c in self.right]
        freqs, psd = welch_psd(epoch.data, epoch.sfreq)
        p = integrate_band(freqs, psd, *self.band)
        pl, pr = float(np.mean(p[li])), float(np.mean(p[ri]))
        return {
            "alpha_left": pl,
            "alpha_right": pr,
            "asymmetry": float(np.log(max(pr, 1e-12)) - np.log(max(pl, 1e-12))),
        }


# --------------------------------------------------------------------------
# SSVEP
# --------------------------------------------------------------------------

def reference_signals(
    freq: float, n_samples: int, sfreq: float, n_harmonics: int = 3
) -> np.ndarray:
    """Sine/cosine reference bank for one stimulation frequency.

    Returns shape (2 * n_harmonics, n_samples). Harmonics above Nyquist are
    dropped rather than aliased back into the band, which would otherwise
    inflate the correlation with an unrelated frequency.
    """
    t = np.arange(n_samples) / sfreq
    rows = []
    for h in range(1, n_harmonics + 1):
        f = freq * h
        if f >= sfreq / 2:
            break
        rows.append(np.sin(2 * np.pi * f * t))
        rows.append(np.cos(2 * np.pi * f * t))
    if not rows:
        raise ValueError(f"no harmonic of {freq} Hz falls below Nyquist")
    return np.vstack(rows)


def cca_correlation(X: np.ndarray, Y: np.ndarray) -> float:
    """Largest canonical correlation between X and Y.

    Args:
        X: (n_features_x, n_samples)
        Y: (n_features_y, n_samples)

    Computed via QR + SVD::

        Xc = X - mean,  Yc = Y - mean
        Qx, _ = qr(Xc^T),  Qy, _ = qr(Yc^T)
        rho = max singular value of  Qx^T Qy

    This is algebraically identical to solving the generalised eigenvalue
    problem ``Sxy Syy^-1 Syx a = rho^2 Sxx a`` but avoids inverting the
    near-singular channel covariance of an EEG montage.
    """
    Xc = X - X.mean(axis=1, keepdims=True)
    Yc = Y - Y.mean(axis=1, keepdims=True)

    # Guard against all-zero (flat) channels, which make QR rank-deficient.
    if not np.any(np.abs(Xc) > 1e-12) or not np.any(np.abs(Yc) > 1e-12):
        return 0.0

    Qx, rx = linalg.qr(Xc.T, mode="economic")
    Qy, ry = linalg.qr(Yc.T, mode="economic")

    # Drop numerically null directions.
    tol_x = np.finfo(float).eps * max(rx.shape) * np.abs(np.diag(rx)).max()
    tol_y = np.finfo(float).eps * max(ry.shape) * np.abs(np.diag(ry)).max()
    kx = int((np.abs(np.diag(rx)) > tol_x).sum())
    ky = int((np.abs(np.diag(ry)) > tol_y).sum())
    if kx == 0 or ky == 0:
        return 0.0
    Qx, Qy = Qx[:, :kx], Qy[:, :ky]

    s = linalg.svdvals(Qx.T @ Qy)
    return float(np.clip(s[0], 0.0, 1.0)) if s.size else 0.0


@register("extractor", "fbcca")
class FilterBankCCA(BaseStage):
    """Filter-bank CCA for SSVEP -- the standard high-accuracy detector.

    Plain CCA ignores the fact that SSVEP harmonics carry independent
    information with decreasing SNR. FBCCA decomposes the signal into sub-bands,
    runs CCA in each, and combines::

        rho_tilde(f) = sum_n  w(n) * rho_n(f)^2 ,   w(n) = n^-a + b

    with ``a = 1.25`` and ``b = 0.25``. Squaring keeps every term positive; the
    decaying weights encode that higher sub-bands are noisier.

    Args:
        freqs: stimulation frequencies presented in the game, in Hz.
        n_harmonics: harmonics included in each reference bank.
        n_bands: number of filter-bank sub-bands.
        band_start: lower edge of sub-band n is ``n * band_start``.
        band_stop: shared upper edge.
        channels: which electrodes to use; resolve these from the
            ``ssvep`` montage role rather than hard-coding them.
    """

    def __init__(
        self,
        freqs: list[float],
        n_harmonics: int = 4,
        n_bands: int = 5,
        band_start: float = 8.0,
        band_stop: float = 88.0,
        a: float = 1.25,
        b: float = 0.25,
        channels: list[str] | None = None,
    ) -> None:
        if not freqs:
            raise ValueError("at least one stimulation frequency is required")
        self.freqs = [float(f) for f in freqs]
        self.n_harmonics = n_harmonics
        self.n_bands = n_bands
        self.band_start, self.band_stop = band_start, band_stop
        self.a, self.b = a, b
        self.channels = channels
        self._sos_cache: dict[tuple, list] = {}
        self._ref_cache: dict[tuple, np.ndarray] = {}
        self._record(freqs=self.freqs, n_harmonics=n_harmonics, n_bands=n_bands,
                     band_start=band_start, band_stop=band_stop, a=a, b=b,
                     channels=channels)

    def _weights(self) -> np.ndarray:
        n = np.arange(1, self.n_bands + 1, dtype=float)
        return n ** (-self.a) + self.b

    def _filters(self, sfreq: float) -> list:
        key = (sfreq, self.n_bands, self.band_start, self.band_stop)
        if key in self._sos_cache:
            return self._sos_cache[key]
        nyq = sfreq / 2.0
        stop = min(self.band_stop, nyq * 0.95)
        sos = []
        for n in range(1, self.n_bands + 1):
            lo = n * self.band_start
            if lo >= stop:
                break
            sos.append(
                signal.butter(4, [lo / nyq, stop / nyq], btype="bandpass",
                              output="sos")
            )
        if not sos:
            raise ValueError(
                f"no filter-bank sub-band fits below Nyquist ({nyq} Hz) with "
                f"band_start={self.band_start}"
            )
        self._sos_cache[key] = sos
        return sos

    def _refs(self, freq: float, n: int, sfreq: float) -> np.ndarray:
        key = (freq, n, sfreq, self.n_harmonics)
        if key not in self._ref_cache:
            self._ref_cache[key] = reference_signals(
                freq, n, sfreq, self.n_harmonics
            )
        return self._ref_cache[key]

    def __call__(self, epoch: Epoch) -> dict[str, float]:
        data = epoch.data
        if self.channels:
            idx = [epoch.ch_names.index(c) for c in self.channels]
            data = data[idx]

        n = data.shape[-1]
        min_cycles = 2.0
        if n / epoch.sfreq < min_cycles / min(self.freqs):
            raise ValueError(
                f"window of {n / epoch.sfreq:.2f} s holds fewer than "
                f"{min_cycles} cycles of {min(self.freqs)} Hz; SSVEP detection "
                f"needs at least {min_cycles / min(self.freqs):.2f} s"
            )

        sos_bank = self._filters(epoch.sfreq)
        w = self._weights()[: len(sos_bank)]

        out: dict[str, float] = {}
        for f in self.freqs:
            Y = self._refs(f, n, epoch.sfreq)
            rho2 = 0.0
            for wn, sos in zip(w, sos_bank):
                Xb = signal.sosfiltfilt(sos, data, axis=-1)
                rho2 += wn * cca_correlation(Xb, Y) ** 2
            out[f"rho_{f:g}"] = float(rho2)
        return out


@register("extractor", "covariance")
class CovarianceFeature(BaseStage):
    """Regularised spatial covariance, flattened to the upper triangle.

    Uses Ledoit-Wolf shrinkage::

        Sigma_hat = (1 - g) * S + g * (trace(S)/p) * I

    with ``g`` chosen analytically to minimise expected squared error. Plain
    sample covariance is rank-deficient whenever ``n_samples`` is not
    comfortably larger than ``n_channels^2``, which is routinely violated by an
    8-channel headset with a 1 s window -- and a singular covariance makes CSP
    and any Riemannian method fail outright.
    """

    def __init__(self, channels: list[str] | None = None, shrinkage: str = "ledoit_wolf"):
        self.channels, self.shrinkage = channels, shrinkage
        self._record(channels=channels, shrinkage=shrinkage)

    def matrix(self, epoch: Epoch) -> np.ndarray:
        data = epoch.data
        if self.channels:
            idx = [epoch.ch_names.index(c) for c in self.channels]
            data = data[idx]
        return covariance(data, self.shrinkage)

    def __call__(self, epoch: Epoch) -> dict[str, float]:
        C = self.matrix(epoch)
        iu = np.triu_indices(C.shape[0])
        return {f"cov_{i}_{j}": float(C[i, j]) for i, j in zip(*iu)}


def covariance(data: np.ndarray, method: str = "ledoit_wolf") -> np.ndarray:
    """Symmetric positive-definite covariance estimate of (n_channels, n_samples)."""
    X = data - data.mean(axis=1, keepdims=True)
    p, n = X.shape
    if method == "empirical":
        C = (X @ X.T) / max(n - 1, 1)
    elif method in ("ledoit_wolf", "oas"):
        from sklearn.covariance import ledoit_wolf, oas

        fn = ledoit_wolf if method == "ledoit_wolf" else oas
        C, _ = fn(X.T, assume_centered=True)
    else:
        raise ValueError(f"unknown covariance method {method!r}")
    # Guarantee strict positive-definiteness for downstream matrix logarithms.
    return _make_spd(C)


def _make_spd(C: np.ndarray, eps: float = 1e-10) -> np.ndarray:
    C = 0.5 * (C + C.T)
    w, V = linalg.eigh(C)
    floor = max(eps, float(w.max()) * 1e-12) if w.size and w.max() > 0 else eps
    w = np.maximum(w, floor)
    return V @ np.diag(w) @ V.T
