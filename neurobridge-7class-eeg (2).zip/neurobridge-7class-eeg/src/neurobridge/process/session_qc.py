"""Per-recording quality reports and whole-dataset sweeps.

Why this exists separately from ``quality.py``
----------------------------------------------
``QualityMonitor`` scores an *epoch* that has already been preprocessed. Point
it at a raw Unicorn recording and every channel scores zero, because the
Unicorn streams DC-coupled: each electrode's half-cell offset puts the trace at
120,000-712,000 uV, far past any sane saturation threshold, with the EEG riding
on top as a few tens of uV. The offset is not signal and not a fault -- it just
has to be removed before any amplitude metric means anything.

This module owns that preparation step and the per-recording report built on
it, then sweeps the report across a whole study so recordings can be compared
and ranked rather than inspected one at a time.

Three things it is careful about:

* **Rail excursions before filtering.** A recording usually opens with a few
  seconds of the amplifier railing at +/-750 mV while the electrodes settle.
  High-passing without excising those first rings for tens of seconds and
  inflates every downstream number; the settling transient alone can make a
  clean recording look unusable. Railed and non-physiological samples are
  interpolated out, *then* the filters run.

* **OSCAR-processed files are not raw files.** g.tec's OSCAR removes the
  offsets and artifacts during acquisition, so rail counts and offset headroom
  read zero on such a file. That is the metric being inapplicable, not the
  recording being perfect. Reports branch on ``meta["processing"]`` and mark
  the inapplicable fields as NaN rather than as good news.

* **Hand side is contralateral.** The electrode that carries a hand's movement
  sits in the opposite hemisphere. This gets inverted often enough to be worth
  stating once, in one place: see ``CONTRALATERAL``.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Sequence

import numpy as np
from scipy.signal import butter, filtfilt, iirnotch, sosfiltfilt, welch

# The Unicorn Hybrid Black's amplifier range is +/-750 mV. A sample pinned at
# that value is not a measurement, it is the amplifier giving up, and it must
# be treated as missing rather than as a very large signal.
UNICORN_RAIL_UV = 749999.0

# Excursions beyond this far from a channel's own baseline are electrode pops
# -- momentary contact loss where the half-cell offset jumps by tens of mV.
# Physiological EEG never moves this far, so anything past it is excised.
EXCURSION_UV = 20000.0

BANDS: dict[str, tuple[float, float]] = {
    "delta": (1.0, 4.0),
    "theta": (4.0, 8.0),
    "alpha": (8.0, 13.0),
    "beta": (13.0, 30.0),
    "gamma": (30.0, 45.0),
}

# Movement of one hand desynchronises the sensorimotor cortex of the OPPOSITE
# hemisphere. Reading these the other way round inverts both motor classes and
# costs a study its motor results, so the mapping lives here and nowhere else.
CONTRALATERAL: dict[str, str] = {"left": "C4", "right": "C3"}

OCCIPITAL: tuple[str, ...] = ("PO7", "Oz", "PO8")
MIDLINE_MOTOR = "Cz"

# A channel is usable when at least this share of its 1-second epochs survive.
_USABLE_CLEAN_PCT = 70.0


# --------------------------------------------------------------------------
# preparation
# --------------------------------------------------------------------------

def prepare(
    data: np.ndarray,
    sfreq: float,
    processing: str = "raw",
    l_freq: float = 1.0,
    h_freq: float = 45.0,
    mains: float = 60.0,
    rail_uv: float = UNICORN_RAIL_UV,
    excursion_uv: float = EXCURSION_UV,
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(filtered, bad_mask)`` ready for amplitude metrics.

    ``bad_mask`` marks samples that were not measurements -- railed, or so far
    from the channel's own baseline that only a broken contact explains them.
    They are interpolated across *before* filtering, because a zero-phase
    filter smears a single 750 mV step across seconds of otherwise good signal
    and turns one bad moment into one bad minute.

    An OSCAR-processed file has already had its offsets removed upstream, so
    only the excursion test is meaningful there; the rail test would flag
    nothing regardless and is skipped rather than reported as a clean bill.
    """
    data = np.asarray(data, dtype=np.float64)
    if data.ndim != 2:
        raise ValueError(f"expected (channels, samples), got shape {data.shape}")

    n_ch, n = data.shape
    out = np.empty_like(data)
    bad = np.zeros(data.shape, dtype=bool)
    idx = np.arange(n)

    nyq = sfreq / 2.0
    hi = min(h_freq, nyq - 1.0)
    sos = butter(4, [l_freq, hi], btype="band", fs=sfreq, output="sos")
    do_notch = 0.0 < mains < nyq - 1.0
    if do_notch:
        b_n, a_n = iirnotch(mains, 30.0, fs=sfreq)

    is_raw = str(processing).lower() != "oscar"

    for i in range(n_ch):
        x = data[i]
        median = float(np.median(x))
        mask = np.abs(x - median) > excursion_uv
        if is_raw:
            mask |= np.abs(x) >= rail_uv
        bad[i] = mask

        y = x.copy()
        if mask.all():
            # Nothing survives; a flat zero trace is honest here and keeps the
            # filters from producing NaNs that would poison every later metric.
            out[i] = 0.0
            continue
        if mask.any():
            y[mask] = np.interp(idx[mask], idx[~mask], y[~mask])

        y = sosfiltfilt(sos, y)
        if do_notch:
            y = filtfilt(b_n, a_n, y)
        out[i] = y

    return out, bad


def _rel_bands(x: np.ndarray, sfreq: float, mains: float = 60.0) -> dict[str, float]:
    """Relative band powers plus a mains ratio, all normalised to 1-45 Hz."""
    nper = int(min(len(x), sfreq * 2))
    if nper < 8:
        return {name: float("nan") for name in (*BANDS, "line")}
    freqs, psd = welch(x, fs=sfreq, nperseg=nper)
    total = psd[(freqs >= 1.0) & (freqs <= 45.0)].sum()
    if not np.isfinite(total) or total <= 0:
        return {name: float("nan") for name in (*BANDS, "line")}

    out = {name: float(psd[(freqs >= lo) & (freqs < hi)].sum() / total)
           for name, (lo, hi) in BANDS.items()}
    out["line"] = float(psd[(freqs >= mains - 2) & (freqs <= mains + 2)].sum() / total)
    return out


# --------------------------------------------------------------------------
# reports
# --------------------------------------------------------------------------

@dataclass
class ChannelReport:
    """One electrode's story for one recording."""

    name: str
    clean_pct: float
    rms_uv: float
    dc_offset_mv: float
    headroom_mv: float
    rail_pct: float
    excursion_pct: float
    line_ratio: float
    bands: dict[str, float] = field(default_factory=dict)

    @property
    def usable(self) -> bool:
        return self.clean_pct >= _USABLE_CLEAN_PCT

    @property
    def verdict(self) -> str:
        if self.clean_pct > 90.0:
            return "excellent"
        if self.clean_pct > 75.0:
            return "good"
        if self.clean_pct >= _USABLE_CLEAN_PCT:
            return "marginal"
        return "reject"


@dataclass
class RecordingReport:
    """Everything sections 3-8 and the sweep need about one recording."""

    path: Path
    participant: str
    session: str
    processing: str
    sfreq: float
    duration_s: float
    n_channels: int
    channels: list[ChannelReport]
    labels: dict[str, dict[str, float]]
    settle_s: float
    berger: float
    erd: dict[str, float]
    integrity: dict[str, Any]
    score: float = 0.0
    tier: str = ""

    @property
    def good_channels(self) -> list[str]:
        return [c.name for c in self.channels if c.usable]

    @property
    def bad_channels(self) -> list[str]:
        return [c.name for c in self.channels if not c.usable]

    @property
    def clean_seconds(self) -> float:
        return float(sum(v["clean_s"] for v in self.labels.values()))

    @property
    def labelled_seconds(self) -> float:
        return float(sum(v["total_s"] for v in self.labels.values()))

    @property
    def yield_pct(self) -> float:
        total = self.labelled_seconds
        return 100.0 * self.clean_seconds / total if total else float("nan")

    def motor_ready(self) -> bool:
        """True when BOTH hands have their contralateral electrode intact.

        One surviving central channel is not enough: with only C3 the left-hand
        class has no contralateral electrode at all, and a classifier trained
        on it is reading the wrong hemisphere.
        """
        good = set(self.good_channels)
        return all(name in good for name in CONTRALATERAL.values())


def _score(r: RecordingReport) -> tuple[float, str]:
    """Weighted 0-100 quality score and its tier.

    The weights encode what actually makes a recording usable for this study,
    in order: how much labelled data survives, how many electrodes survive,
    whether both hands are decodable at all, occipital coverage for the eye
    classes, whether the motor response points the right way, class balance,
    genuine occipital alpha, and how fast the headset settled.
    """
    y = r.yield_pct
    n_good = len(r.good_channels)
    occ_ok = sum(1 for c in r.channels if c.name in OCCIPITAL and c.usable)
    erd_ok = sum(1 for v in r.erd.values() if v < 1.0)

    clean = [v["clean_s"] for v in r.labels.values()]
    balance = min(clean) / max(clean) if clean and max(clean) > 0 else 0.0

    s = 0.0
    s += 26 * min((y if np.isfinite(y) else 0) / 70.0, 1.0)
    s += 16 * (n_good / max(r.n_channels, 1))
    s += 14 * float(r.motor_ready())
    s += 10 * min(occ_ok / 2.0, 1.0)
    s += 10 * (erd_ok / 2.0)
    s += 10 * balance
    s += 8 * min(max((r.berger - 1.0) / 0.8, 0.0), 1.0) if np.isfinite(r.berger) else 0
    s += 6 * (1.0 - min(r.settle_s / 120.0, 1.0))

    s = round(float(s), 1)
    if s >= 78:
        tier = "best"
    elif s >= 68:
        tier = "better"
    elif s >= 58:
        tier = "good"
    elif s >= 45:
        tier = "marginal"
    else:
        tier = "reject"
    return s, tier


def analyse(
    path: str | Path,
    mains: float = 60.0,
    epoch_s: float = 1.0,
    ptp_uv: float = 150.0,
    rms_range: tuple[float, float] = (0.3, 50.0),
) -> RecordingReport:
    """Build a full quality report for one recording."""
    path = Path(path)
    with np.load(path, allow_pickle=False) as z:
        raw = z["data"].astype(np.float64)
        meta = json.loads(str(z["meta"]))

    sfreq = float(meta["sfreq"])
    names = list(meta["ch_names"])
    spans = list(meta.get("annotations") or [])
    processing = str(meta.get("processing", "raw"))
    is_raw = processing.lower() != "oscar"

    n_ch, n = raw.shape
    filt, bad = prepare(raw, sfreq, processing, mains=mains)

    ep = max(int(round(epoch_s * sfreq)), 1)
    n_ep = n // ep
    if n_ep < 1:
        raise ValueError(f"{path.name} is shorter than one {epoch_s}s epoch")

    D = filt[:, : n_ep * ep].reshape(n_ch, n_ep, ep)
    B = bad[:, : n_ep * ep].reshape(n_ch, n_ep, ep).any(axis=2)
    ptp = D.max(axis=2) - D.min(axis=2)
    rms = np.sqrt((D ** 2).mean(axis=2))
    lo_rms, hi_rms = rms_range
    bad_ep = B | (ptp > ptp_uv) | (rms > hi_rms) | (rms < lo_rms)

    # Settling: the first second from which 90% of the next 20 epochs hold at
    # least 6 good channels. Reported so a slow-settling cap is visible rather
    # than silently inflating every artifact count.
    ok_per_ep = (~bad_ep).sum(axis=0)
    enough = ok_per_ep >= 6
    settle = float(n_ep)
    for k in range(max(n_ep - 20, 0)):
        if enough[k:k + 20].mean() >= 0.9:
            settle = float(k)
            break

    channels: list[ChannelReport] = []
    for i, name in enumerate(names):
        keep = ~bad_ep[i]
        if keep.sum() >= 5:
            sig = D[i][keep].ravel()
            ch_rms = float(np.sqrt((sig ** 2).mean()))
            bands = _rel_bands(sig, sfreq, mains)
        else:
            ch_rms = float("nan")
            bands = {k: float("nan") for k in (*BANDS, "line")}

        offset_mv = float(np.median(raw[i])) / 1000.0 if is_raw else float("nan")
        headroom = 750.0 - abs(offset_mv) if is_raw else float("nan")
        rail_pct = (100.0 * float((np.abs(raw[i]) >= UNICORN_RAIL_UV).mean())
                    if is_raw else float("nan"))

        channels.append(ChannelReport(
            name=name,
            clean_pct=100.0 * float(keep.mean()),
            rms_uv=ch_rms,
            dc_offset_mv=offset_mv,
            headroom_mv=headroom,
            rail_pct=rail_pct,
            excursion_pct=100.0 * float(bad[i].mean()),
            line_ratio=float(bands.get("line", float("nan"))),
            bands={k: bands[k] for k in BANDS},
        ))

    good_idx = [i for i, c in enumerate(channels) if c.usable]
    all_good_clean = ((~bad_ep[good_idx]).all(axis=0) if good_idx
                      else np.zeros(n_ep, dtype=bool))

    labels: dict[str, dict[str, float]] = {}
    for a in spans:
        e0 = max(int(a["t_start"] * sfreq) // ep, 0)
        e1 = min(int(a["t_end"] * sfreq) // ep, n_ep)
        if e1 <= e0:
            continue
        entry = labels.setdefault(str(a["label"]),
                                  {"spans": 0, "total_s": 0.0, "clean_s": 0.0})
        entry["spans"] += 1
        entry["total_s"] += float(e1 - e0) * epoch_s
        entry["clean_s"] += float(all_good_clean[e0:e1].sum()) * epoch_s

    def _pool(label: str, ch_idx: int) -> np.ndarray | None:
        """Concatenate the clean epochs of one channel under one label."""
        out = []
        for a in spans:
            if str(a["label"]).lower() != label:
                continue
            e0 = max(int(a["t_start"] * sfreq) // ep, 0)
            e1 = min(int(a["t_end"] * sfreq) // ep, n_ep)
            out += [D[ch_idx, k] for k in range(e0, e1) if not bad_ep[ch_idx, k]]
        return np.concatenate(out) if out else None

    def _alpha(label: str) -> float:
        vals = []
        for name in OCCIPITAL:
            if name not in names:
                continue
            i = names.index(name)
            if not channels[i].usable:
                continue
            sig = _pool(label, i)
            if sig is not None and len(sig) >= sfreq * 4:
                vals.append(_rel_bands(sig, sfreq, mains)["alpha"])
        return float(np.mean(vals)) if vals else float("nan")

    a_close, a_open = _alpha("eye close"), _alpha("eye open")
    berger = a_close / a_open if a_open and np.isfinite(a_open) else float("nan")

    def _mu(label: str, ch_name: str) -> float:
        if ch_name not in names:
            return float("nan")
        sig = _pool(label, names.index(ch_name))
        if sig is None or len(sig) < sfreq * 4:
            return float("nan")
        b = _rel_bands(sig, sfreq, mains)
        return b["alpha"] + b["beta"]

    erd: dict[str, float] = {}
    for side, ch_name in CONTRALATERAL.items():
        task = _mu(f"clenching {side} hand", ch_name)
        rest = _mu("eye open", ch_name)
        erd[side] = task / rest if rest and np.isfinite(rest) else float("nan")

    stem = path.stem
    session = ""
    if "session" in stem:
        session = "".join(c for c in stem.split("session", 1)[1][:2] if c.isdigit())
    participant = (spans[0].get("participant") if spans else None) or path.parent.name

    integrity = {
        "n_nan": int(np.isnan(raw).sum()),
        "n_inf": int(np.isinf(raw).sum()),
        "constant_channels": [names[i] for i in range(n_ch)
                              if float(np.var(raw[i])) == 0.0],
        "n_spans": len(spans),
        "classes": sorted({str(a["label"]) for a in spans}),
    }

    report = RecordingReport(
        path=path,
        participant=str(participant),
        session=session,
        processing=processing,
        sfreq=sfreq,
        duration_s=n / sfreq,
        n_channels=n_ch,
        channels=channels,
        labels=labels,
        settle_s=settle,
        berger=berger,
        erd=erd,
        integrity=integrity,
    )
    report.score, report.tier = _score(report)
    return report


_CACHE: dict[tuple, RecordingReport] = {}


def analyse_cached(path: str | Path, **kw) -> RecordingReport:
    """``analyse`` memoised on (path, mtime, options).

    The sweep and the per-recording sections both walk the same files; without
    this, opening the notebook re-reads and re-filters the whole study twice.
    Keyed on mtime so a re-recorded session is never served stale.
    """
    path = Path(path)
    key = (str(path.resolve()), path.stat().st_mtime_ns, tuple(sorted(kw.items())))
    if key not in _CACHE:
        _CACHE[key] = analyse(path, **kw)
    return _CACHE[key]


# --------------------------------------------------------------------------
# tables and text
# --------------------------------------------------------------------------

def channel_table(report: RecordingReport):
    """Per-channel detail for one recording, as a DataFrame."""
    import pandas as pd

    return pd.DataFrame([{
        "channel": c.name,
        "clean_%": round(c.clean_pct, 1),
        "verdict": c.verdict,
        "rms_uV": round(c.rms_uv, 1),
        "dc_offset_mV": round(c.dc_offset_mv, 1),
        "headroom_mV": round(c.headroom_mv, 1),
        "rail_%": round(c.rail_pct, 3),
        "pop_%": round(c.excursion_pct, 2),
        "line_ratio": round(c.line_ratio, 3),
        **{b: round(c.bands.get(b, float("nan")), 3) for b in BANDS},
    } for c in report.channels])


def label_table(report: RecordingReport):
    import pandas as pd

    return pd.DataFrame([{
        "class": name,
        "spans": int(v["spans"]),
        "total_s": round(v["total_s"], 1),
        "clean_s": round(v["clean_s"], 1),
        "yield_%": round(100.0 * v["clean_s"] / v["total_s"], 1) if v["total_s"] else 0.0,
    } for name, v in sorted(report.labels.items())])


def describe(report: RecordingReport) -> str:
    """A short plain-language verdict for one recording."""
    r = report
    lines = [f"{r.participant} session {r.session}: {r.tier.upper()} "
             f"(score {r.score}/100, {r.processing})"]

    line = f"  {len(r.good_channels)}/{r.n_channels} channels usable"
    if r.bad_channels:
        line += f"; lost {', '.join(r.bad_channels)}"
    lines.append(line)

    lines.append(f"  {r.clean_seconds:.0f}s clean of {r.labelled_seconds:.0f}s "
                 f"labelled ({r.yield_pct:.0f}%)")

    if not r.motor_ready():
        missing = [f"{side}-hand needs {ch}" for side, ch in CONTRALATERAL.items()
                   if ch in r.bad_channels]
        if missing:
            lines.append(f"  motor incomplete: {', '.join(missing)}")

    if np.isfinite(r.berger):
        if r.berger >= 1.3:
            lines.append(f"  Berger {r.berger:.2f} -- genuine occipital alpha")
        else:
            lines.append(f"  Berger {r.berger:.2f} -- weak eyes-closed alpha")

    reversed_sides = [s for s, v in r.erd.items() if np.isfinite(v) and v > 1.0]
    if reversed_sides:
        lines.append(f"  ERD reversed for {', '.join(reversed_sides)} hand -- "
                     f"power rose during clenching, likely EMG, not cortical")

    if r.integrity["constant_channels"]:
        lines.append(f"  flat channels: {', '.join(r.integrity['constant_channels'])}")

    return "\n".join(lines)


def sweep(paths: Iterable[str | Path], progress: bool = True, **kw):
    """Analyse many recordings; return a ranked pandas DataFrame."""
    import pandas as pd

    paths = [Path(p) for p in paths]
    rows = []
    for n, p in enumerate(paths, 1):
        if progress:
            print(f"\r  [{n}/{len(paths)}] {p.name:<60}", end="")
        try:
            r = analyse_cached(p, **kw)
        except Exception as exc:                       # one bad file must not
            rows.append({"participant": p.parent.name,  # kill the whole sweep
                         "session": "", "recording": p.name,
                         "processing": "", "score": float("nan"),
                         "tier": f"ERROR: {type(exc).__name__}"})
            continue
        rows.append({
            "participant": r.participant,
            "session": r.session,
            "recording": r.path.name,
            "processing": r.processing,
            "score": r.score,
            "tier": r.tier,
            "duration_s": round(r.duration_s, 1),
            "labelled_s": round(r.labelled_seconds, 1),
            "clean_s": round(r.clean_seconds, 1),
            "yield_%": round(r.yield_pct, 1),
            "good_ch": len(r.good_channels),
            "motor_ready": r.motor_ready(),
            "berger": round(r.berger, 2),
            "erd_left": round(r.erd.get("left", float("nan")), 2),
            "erd_right": round(r.erd.get("right", float("nan")), 2),
            "settle_s": round(r.settle_s, 1),
            "bad_channels": ", ".join(r.bad_channels),
            "n_spans": r.integrity["n_spans"],
        })
    if progress:
        print("\r" + " " * 78 + "\r", end="")

    df = pd.DataFrame(rows).sort_values("score", ascending=False,
                                        na_position="last").reset_index(drop=True)
    df.insert(0, "rank", np.arange(1, len(df) + 1))
    return df


# --------------------------------------------------------------------------
# rendering
# --------------------------------------------------------------------------

def _plot_overview(report: RecordingReport, mains: float = 60.0,
                   window_s: float = 10.0) -> None:
    """Stacked traces plus a per-channel clean-percentage bar."""
    import matplotlib.pyplot as plt

    r = report
    with np.load(r.path, allow_pickle=False) as z:
        raw = z["data"].astype(np.float64)
    filt, _ = prepare(raw, r.sfreq, r.processing, mains=mains)

    n = min(int(window_s * r.sfreq), filt.shape[1])
    t = np.arange(n) / r.sfreq

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(11, 7),
                                   gridspec_kw={"height_ratios": [2.5, 1]})
    fig.suptitle(f"{r.participant} session {r.session} -- {r.path.name}"
                 f"  |  score {r.score}/100 ({r.tier}), {r.processing}")

    spacing = 100.0
    for i, c in enumerate(r.channels):
        offset = (len(r.channels) - 1 - i) * spacing
        ax1.plot(t, filt[i, :n] + offset, linewidth=0.6,
                 color="#1f7a5c" if c.usable else "#d6412b")
        ax1.text(-0.5, offset, c.name, ha="right", va="center", fontsize=8)
    ax1.set_xlabel("time (s)")
    ax1.set_ylabel(f"filtered (spacing {spacing:.0f} uV)")
    ax1.set_yticks([])
    ax1.margins(x=0)

    names = [c.name for c in r.channels]
    vals = [c.clean_pct for c in r.channels]
    ax2.bar(names, vals, color=["#1f7a5c" if c.usable else "#d6412b"
                                for c in r.channels])
    ax2.axhline(_USABLE_CLEAN_PCT, color="black", linewidth=0.8, linestyle="--")
    ax2.set_ylim(0, 100)
    ax2.set_ylabel("clean %")
    fig.tight_layout()


def render(report: RecordingReport, plots: bool = True, mains: float = 60.0,
           window_s: float = 10.0, display_fn=None) -> None:
    """Print the sections 3-8 content for ONE recording."""
    show = display_fn or (lambda obj: print(obj.to_string(index=False)))

    print("=" * 78)
    print(describe(report))
    print("=" * 78)

    integ = report.integrity
    print(f"\nintegrity: {integ['n_nan']} NaN, {integ['n_inf']} Inf, "
          f"{integ['n_spans']} spans, classes {integ['classes']}")
    if integ["constant_channels"]:
        print(f"  constant channels: {integ['constant_channels']}")
    print(f"settling: {report.settle_s:.0f}s before 6+ channels stayed clean")

    print("\nper channel:")
    show(channel_table(report))
    print("\nper class:")
    show(label_table(report))

    if plots:
        _plot_overview(report, mains=mains, window_s=window_s)


def report_all(paths: Iterable[str | Path], plots: bool = True,
               limit: int | None = None, mains: float = 60.0,
               display_fn=None, **kw) -> list[RecordingReport]:
    """Run the per-recording report for EVERY recording given."""
    paths = [Path(p) for p in paths]
    if limit is not None:
        paths = paths[:limit]

    reports = []
    for p in paths:
        try:
            r = analyse_cached(p, mains=mains, **kw)
        except Exception as exc:
            print(f"{p.name}: FAILED -- {type(exc).__name__}: {exc}")
            continue
        render(r, plots=plots, mains=mains, display_fn=display_fn)
        print()
        reports.append(r)
    return reports
