"""Filtering, feature extraction and signal quality."""
