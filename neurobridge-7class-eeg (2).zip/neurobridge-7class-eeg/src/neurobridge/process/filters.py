"""Filtering and epoch-level transforms.

Mathematical notes
------------------
Real-time filtering is *causal and stateful*. Filtering each overlapping epoch
independently (the usual beginner mistake, and what ``filtfilt`` inside a loop
does) produces edge transients at every window boundary and a discontinuous
control signal. Here the IIR filter runs once over the sample stream with its
delay line carried across chunks::

    y[n], zf = sosfilt(sos, x[n], zi=zi)      # zi <- zf every chunk

Second-order sections are used rather than a single (b, a) polynomial because
direct-form IIR of order > 4 is numerically fragile at typical EEG sampling
rates -- the poles cluster near the unit circle and the transfer function can
become unstable in float64.

For offline analysis the package still exposes zero-phase ``filtfilt``; the
distinction is made explicit rather than hidden, because the group delay of the
causal filter is part of the end-to-end latency this project measures.
"""

from __future__ import annotations

import numpy as np
from scipy import signal

from ..core.pipeline import BaseStage
from ..core.types import Epoch
from ..registry import register


class StreamFilter:
    """Stateful causal filter applied to raw chunks before buffering.

    Args:
        sfreq: sampling rate in Hz.
        l_freq: high-pass edge in Hz (None to skip).
        h_freq: low-pass edge in Hz (None to skip).
        notch: mains frequency to notch out, 50.0 or 60.0 (None to skip).
        notch_q: quality factor of the notch; higher = narrower.
        order: Butterworth order of the band-pass.
        n_channels: number of channels, needed to size the delay line.

    The band-pass is designed once at construction. Its group delay at the
    band centre is exposed as ``group_delay_s`` and should be added to the
    reported end-to-end latency budget.
    """

    def __init__(
        self,
        sfreq: float,
        n_channels: int,
        l_freq: float | None = 1.0,
        h_freq: float | None = 45.0,
        notch: float | None = 60.0,
        notch_q: float = 30.0,
        order: int = 4,
    ) -> None:
        self.sfreq = float(sfreq)
        self.n_channels = int(n_channels)
        self.l_freq, self.h_freq, self.notch = l_freq, h_freq, notch
        nyq = self.sfreq / 2.0

        if h_freq is not None and h_freq >= nyq:
            raise ValueError(
                f"h_freq={h_freq} Hz is at or above Nyquist ({nyq} Hz) for "
                f"sfreq={sfreq}. Choose h_freq < {nyq}."
            )
        if l_freq is not None and h_freq is not None and l_freq >= h_freq:
            raise ValueError(f"l_freq ({l_freq}) must be below h_freq ({h_freq})")

        sos_list = []
        if l_freq is not None and h_freq is not None:
            sos_list.append(
                signal.butter(order, [l_freq / nyq, h_freq / nyq],
                              btype="bandpass", output="sos")
            )
        elif l_freq is not None:
            sos_list.append(
                signal.butter(order, l_freq / nyq, btype="highpass", output="sos")
            )
        elif h_freq is not None:
            sos_list.append(
                signal.butter(order, h_freq / nyq, btype="lowpass", output="sos")
            )

        if notch is not None:
            if notch >= nyq:
                raise ValueError(f"notch {notch} Hz exceeds Nyquist {nyq} Hz")
            # Cascade the fundamental and harmonics that fit below Nyquist.
            f = notch
            while f < nyq * 0.95:
                b, a = signal.iirnotch(f, notch_q, self.sfreq)
                sos_list.append(signal.tf2sos(b, a))
                f += notch

        self.sos = np.vstack(sos_list) if sos_list else None
        self._zi = None
        if self.sos is not None:
            zi_single = signal.sosfilt_zi(self.sos)          # (n_sections, 2)
            # Broadcast to (n_sections, n_channels, 2) for axis=-1 filtering.
            self._zi = np.repeat(zi_single[:, None, :], self.n_channels, axis=1)
            self._primed = False

    @property
    def group_delay_s(self) -> float:
        """Group delay in seconds at the geometric centre of the pass band."""
        if self.sos is None:
            return 0.0
        if self.l_freq and self.h_freq:
            f0 = math_sqrt(self.l_freq * self.h_freq)
        else:
            f0 = self.h_freq or self.l_freq or 10.0
        w = 2 * np.pi * f0 / self.sfreq
        b, a = signal.sos2tf(self.sos)
        _, gd = signal.group_delay((b, a), w=[w])
        return float(gd[0] / self.sfreq)

    def __call__(self, data: np.ndarray) -> np.ndarray:
        """Filter one chunk, carrying filter state forward."""
        if self.sos is None:
            return data
        if data.shape[0] != self.n_channels:
            raise ValueError(
                f"filter built for {self.n_channels} channels, got {data.shape[0]}"
            )
        if not self._primed:
            # Initialise the delay line to the first sample so the filter does
            # not ring for the first ~order/f_low seconds of every session.
            self._zi = self._zi * data[None, :, :1]
            self._primed = True
        out, self._zi = signal.sosfilt(self.sos, data, axis=-1, zi=self._zi)
        return out

    def reset(self) -> None:
        if self.sos is not None:
            zi_single = signal.sosfilt_zi(self.sos)
            self._zi = np.repeat(zi_single[:, None, :], self.n_channels, axis=1)
            self._primed = False

    def get_params(self) -> dict:
        return {
            "sfreq": self.sfreq, "l_freq": self.l_freq, "h_freq": self.h_freq,
            "notch": self.notch, "n_channels": self.n_channels,
        }


def math_sqrt(x: float) -> float:
    return float(np.sqrt(x))


@register("transform", "detrend")
class Detrend(BaseStage):
    """Remove per-epoch mean or linear trend.

    Applied after the causal band-pass, this only removes residual drift within
    the window, so it does not fight the high-pass filter.
    """

    def __init__(self, mode: str = "constant") -> None:
        if mode not in ("constant", "linear"):
            raise ValueError("mode must be 'constant' or 'linear'")
        self.mode = mode
        self._record(mode=mode)

    def __call__(self, epoch: Epoch) -> Epoch:
        epoch.data = signal.detrend(epoch.data, axis=-1, type=self.mode)
        return epoch


@register("transform", "rereference")
class Rereference(BaseStage):
    """Re-reference to the common average or to named channels.

    The common average reference is only meaningful with reasonable spatial
    coverage; with fewer than 4 channels it distorts more than it helps, so
    this raises rather than silently degrading the signal.
    """

    def __init__(self, mode: str = "average", channels: list[str] | None = None) -> None:
        self.mode, self.channels = mode, channels
        self._record(mode=mode, channels=channels)

    def __call__(self, epoch: Epoch) -> Epoch:
        if self.mode == "average":
            if epoch.data.shape[0] < 4:
                raise ValueError(
                    "common average reference needs >= 4 channels; this device "
                    f"has {epoch.data.shape[0]}. Use mode='channels' instead."
                )
            epoch.data = epoch.data - epoch.data.mean(axis=0, keepdims=True)
        elif self.mode == "channels":
            if not self.channels:
                raise ValueError("mode='channels' requires channel names")
            idx = [epoch.ch_names.index(c) for c in self.channels]
            epoch.data = epoch.data - epoch.data[idx].mean(axis=0, keepdims=True)
        elif self.mode == "none":
            pass
        else:
            raise ValueError(f"unknown reference mode {self.mode!r}")
        return epoch


@register("transform", "laplacian")
class SurfaceLaplacian(BaseStage):
    """Small Laplacian: subtract the mean of each channel's nearest neighbours.

    Sharpens focal sources (mu rhythm over C3/C4, SSVEP over Oz) by suppressing
    spatially broad activity. Neighbours are found via the approximate montage
    geometry, so this works on any labelled headset rather than a fixed layout.
    """

    def __init__(self, radius: float = 0.6, min_neighbours: int = 2) -> None:
        self.radius, self.min_neighbours = radius, min_neighbours
        self._neighbours: dict[int, list[int]] | None = None
        self._record(radius=radius, min_neighbours=min_neighbours)

    def _build(self, ch_names: tuple[str, ...]) -> dict[int, list[int]]:
        from ..core.montage import distance

        nb: dict[int, list[int]] = {}
        for i, a in enumerate(ch_names):
            d = sorted(
                ((distance(a, b), j) for j, b in enumerate(ch_names) if j != i)
            )
            near = [j for dist, j in d if dist <= self.radius]
            if len(near) < self.min_neighbours:
                near = [j for _, j in d[: self.min_neighbours]]
            nb[i] = near
        return nb

    def __call__(self, epoch: Epoch) -> Epoch:
        if self._neighbours is None:
            self._neighbours = self._build(epoch.ch_names)
        out = np.empty_like(epoch.data)
        for i in range(epoch.data.shape[0]):
            nb = self._neighbours[i]
            out[i] = epoch.data[i] - (epoch.data[nb].mean(axis=0) if nb else 0.0)
        epoch.data = out
        return epoch


@register("transform", "reject")
class AmplitudeReject(BaseStage):
    """Flag (do not silently drop) epochs containing gross artefacts.

    Uses a robust criterion: an epoch is rejected if any channel's peak-to-peak
    amplitude exceeds ``ptp_uv``, or if its median absolute deviation implies a
    scale far outside the running estimate. Rejected epochs are marked in
    ``epoch.meta['reject']`` so the decoder can hold its previous output rather
    than emitting a garbage control signal -- important when the person on the
    other end of the socket is an eleven-year-old who will otherwise conclude
    the game is broken when they blink.
    """

    def __init__(self, ptp_uv: float = 150.0, flat_uv: float = 0.5) -> None:
        self.ptp_uv, self.flat_uv = ptp_uv, flat_uv
        self._record(ptp_uv=ptp_uv, flat_uv=flat_uv)

    def __call__(self, epoch: Epoch) -> Epoch:
        ptp = np.ptp(epoch.data, axis=-1)
        bad_high = np.where(ptp > self.ptp_uv)[0]
        bad_flat = np.where(ptp < self.flat_uv)[0]
        epoch.meta["reject"] = bool(len(bad_high) or len(bad_flat))
        epoch.meta["reject_channels"] = [
            epoch.ch_names[i] for i in np.concatenate([bad_high, bad_flat])
        ]
        epoch.meta["ptp_uv"] = {epoch.ch_names[i]: float(ptp[i])
                                for i in range(len(ptp))}
        return epoch
