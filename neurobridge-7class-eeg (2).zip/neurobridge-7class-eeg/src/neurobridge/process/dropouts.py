"""Repair of Bluetooth dropouts in a raw EEG stream.

Why this exists
---------------
Over Bluetooth, lost Unicorn packets reach BrainFlow as the last received
sample repeated for the length of the gap: every channel identical to the
previous sample, the sample count (and so the timing) preserved. A repeated
sample looks harmless. It is not, because a dry-electrode raw stream carries
tens to hundreds -- on a poorly seated electrode, over a thousand --
microvolts of mains hum. Freezing that hum mid-cycle for a 40-100 ms gap
leaves a rectangular error as large as the hum itself, which no notch can
remove because it is no longer a sinusoid. After the band-pass it is a
transient of hundreds of microvolts: exactly the "RMS and peak-to-peak far
too high, usable channels jumping about" picture on the live scope.

Measured on this project's own recordings, replayed through the live scope's
code path (``06_live_scope.py``: 20-sample chunks, 1-45 Hz, 60 Hz notch,
quality on the last 5 s): in a session with 10.9% dropped samples, big
excursions (> 200 uV) were twice as likely within 0.5 s of a dropout as
elsewhere, and repairing the dropouts took median channel RMS from 28.9 to
14.8 uV, median peak-to-peak from 299 to 113 uV (Pz: 1653 -> 473 uV), and the
share of windows with >= 6/8 usable channels from 58% to 82%. Sessions with
~1% dropouts improved a little; a session with none was unchanged.

The repair
----------
Each held run is replaced by the last good sample plus the mains oscillation
continued through the gap: the fundamental and second harmonic are fitted,
with a constant and a linear trend, on the preceding ``fit_s`` seconds of good
samples and extrapolated. Mains is the one component of the signal that is
predictable across a 100 ms gap; the EEG in the gap is not, and is held, as
it was. Samples that were not dropped are returned bit-for-bit, so a stream
with no dropouts passes through unchanged.

The repair is causal and chunk-by-chunk, and a chunked stream gives the same
result as the whole file at once (runs that straddle a chunk boundary are
re-anchored on their true start). So the same object serves a live source and
an offline recording, and a classifier trained on repaired recordings sees
what the live system sees.
"""

from __future__ import annotations

import numpy as np

__all__ = ["DropoutRepair", "repair_dropouts"]


def _mains_design(t: np.ndarray, mains: float, harmonics: tuple[int, ...]) -> np.ndarray:
    return np.stack([f(2 * np.pi * h * mains * t)
                     for h in harmonics for f in (np.sin, np.cos)], axis=-1)


class DropoutRepair:
    """Causal repair of held (dropped) samples, one chunk at a time.

    Args:
        n_channels: channels in the stream.
        sfreq: sampling rate in Hz.
        mains: 50.0 or 60.0 -- the hum being continued through each gap.
        fit_s: seconds of good samples before a gap used to fit the hum.
        min_fit: fewer good samples than this before a gap (the very start of
            a stream, or back-to-back gaps) and the gap is left as it was.

    ``n_repaired`` / ``n_samples`` count what was done, and ``last_mask``
    marks the repaired samples of the most recent chunk.
    """

    def __init__(self, n_channels: int, sfreq: float, mains: float = 60.0,
                 fit_s: float = 0.5, min_fit: int = 25) -> None:
        self.n_channels = int(n_channels)
        self.sfreq = float(sfreq)
        self.mains = float(mains)
        self.harmonics = tuple(h for h in (1, 2) if h * self.mains < self.sfreq / 2)
        self.min_fit = int(min_fit)
        self.n_fit = max(int(round(fit_s * self.sfreq)), self.min_fit)
        # History long enough to re-anchor a gap that straddles chunks: the fit
        # window plus up to a second of gap.
        self._keep = self.n_fit + int(self.sfreq)
        self.reset()

    def reset(self) -> None:
        self._hist = np.zeros((self.n_channels, 0))
        self._good = np.zeros(0, dtype=bool)
        self._prev: np.ndarray | None = None
        self.n_samples = 0
        self.n_repaired = 0
        self.last_mask = np.zeros(0, dtype=bool)

    @property
    def fraction(self) -> float:
        """Share of all samples so far that were dropped and repaired."""
        return self.n_repaired / self.n_samples if self.n_samples else 0.0

    def __call__(self, data: np.ndarray) -> np.ndarray:
        x = np.asarray(data, dtype=np.float64)
        n = x.shape[1]
        if n == 0:
            return x
        if self._prev is None:
            held = np.zeros(n, dtype=bool)
            held[1:] = np.all(x[:, 1:] == x[:, :-1], axis=0)
        else:
            full = np.concatenate([self._prev[:, None], x], axis=1)
            held = np.all(full[:, 1:] == full[:, :-1], axis=0)
        self._prev = x[:, -1].copy()

        buf = np.concatenate([self._hist, x], axis=1)
        good = np.concatenate([self._good, ~held])
        off = self._hist.shape[1]
        if held.any() and self.harmonics:
            edges = np.diff(np.concatenate([[0], held.astype(np.int8), [0]]))
            for a, b in zip(np.flatnonzero(edges == 1), np.flatnonzero(edges == -1)):
                A, B = a + off, b + off
                # A gap continuing from the previous chunk: find its true start,
                # so it is filled exactly as it would be in one piece.
                while A > 0 and not good[A - 1]:
                    A -= 1
                if A == 0:
                    continue
                lo = max(0, A - self.n_fit)
                idx = np.arange(lo, A)[good[lo:A]]
                if idx.size < self.min_fit:
                    continue
                t = idx / self.sfreq
                D = np.column_stack([np.ones(idx.size), t - t[-1],
                                     _mains_design(t, self.mains, self.harmonics)])
                coef, *_ = np.linalg.lstsq(D, buf[:, idx].T, rcond=None)
                tg = np.arange(A - 1, B) / self.sfreq
                m = _mains_design(tg, self.mains, self.harmonics) @ coef[2:]
                fill = buf[:, A - 1][:, None] + (m[1:] - m[0]).T
                s = max(A, off)                  # never rewrite emitted samples
                buf[:, s:B] = fill[:, s - A:]
        out = buf[:, off:]
        self._hist = buf[:, -self._keep:]
        self._good = good[-self._keep:]
        self.n_samples += n
        self.n_repaired += int(held.sum())
        self.last_mask = held
        return out


def repair_dropouts(data: np.ndarray, sfreq: float, mains: float = 60.0) -> np.ndarray:
    """Repair a whole recording at once; identical to streaming it through
    :class:`DropoutRepair`. A no-op on data with no held samples."""
    data = np.asarray(data)
    return DropoutRepair(data.shape[0], sfreq, mains)(data)
