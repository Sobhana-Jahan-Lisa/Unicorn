"""Signal quality assessment.

Why this is a first-class module rather than a utility
------------------------------------------------------
In a lab, a researcher watches the raw traces and notices a lifting electrode.
In a classroom with thirty children and one adult, nobody is watching. Every
failure mode -- a dry electrode losing contact, a cable brushing a desk, a child
resting their head on their hand -- produces a plausible-looking control signal
that is pure artefact. Without an automatic, interpretable quality score the
education study cannot distinguish "the student could not modulate their EEG"
from "the electrode was not on their head", and that confound is fatal to the
whole design.

Each metric below is scored to [0, 1] and combined into a per-channel index.
The metrics are deliberately physiological rather than device-specific, so they
transfer across headsets that do not report impedance.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from scipy import signal, stats

from .features import welch_psd


@dataclass
class ChannelQuality:
    name: str
    score: float                     # 0 = unusable, 1 = clean
    rms_uv: float
    ptp_uv: float
    line_ratio: float                # mains power / neighbouring background
    spectral_slope: float            # exponent of the 1/f^a background
    flat: bool
    saturated: bool
    flags: list[str] = field(default_factory=list)
    line_contamination: float = float("nan")  # residual mains RMS / 1-45 Hz RMS
    saturated_fraction: float = 0.0            # share of samples past the limit

    @property
    def usable(self) -> bool:
        return self.score >= 0.5

    def advice(self) -> str:
        """Plain-language guidance a teacher can act on."""
        if self.flat:
            return f"{self.name}: no signal. Check the electrode is connected."
        if self.saturated:
            return f"{self.name}: signal is railing. Reseat the electrode."
        if (self.line_contamination > 0.4 if np.isfinite(self.line_contamination)
                else self.line_ratio > 4):
            return (f"{self.name}: heavy mains interference. Move away from "
                    f"chargers and monitors, and check the reference clip.")
        if self.rms_uv > 60:
            return f"{self.name}: very large signal. Ask the student to sit still."
        if self.spectral_slope > -0.3:
            return (f"{self.name}: spectrum looks like electrical noise, not "
                    f"brain activity. Add gel or reseat the electrode.")
        if self.score < 0.5:
            return f"{self.name}: poor contact. Adjust the headset."
        return f"{self.name}: good."


def _score_range(x: float, good: tuple[float, float], hard: tuple[float, float]) -> float:
    """1.0 inside ``good``, tapering linearly to 0.0 at the ``hard`` limits."""
    lo_g, hi_g = good
    lo_h, hi_h = hard
    if lo_g <= x <= hi_g:
        return 1.0
    if x < lo_g:
        return float(np.clip((x - lo_h) / max(lo_g - lo_h, 1e-9), 0.0, 1.0))
    return float(np.clip((hi_h - x) / max(hi_h - hi_g, 1e-9), 0.0, 1.0))


def spectral_slope(freqs: np.ndarray, psd: np.ndarray,
                   fit_range: tuple[float, float] = (2.0, 24.0),
                   exclude: tuple[float, float] = (7.0, 14.0)) -> float:
    """Exponent ``a`` of the aperiodic background ``P(f) ~ f^a``.

    Fitted by robust (Theil-Sen) regression of ``log10 P`` on ``log10 f``,
    excluding the alpha band so a strong Berger rhythm does not bias the slope.
    Real EEG gives roughly ``a`` in [-2.5, -0.8]; a slope near zero means the
    channel is recording broadband electrical noise, not cortex.

    Theil-Sen is used instead of least squares because a single spectral peak
    or a 60 Hz harmonic leaking into the range would otherwise drag the fit.
    """
    mask = (freqs >= fit_range[0]) & (freqs <= fit_range[1])
    mask &= ~((freqs >= exclude[0]) & (freqs <= exclude[1]))
    if mask.sum() < 5:
        return float("nan")
    x = np.log10(freqs[mask])
    y = np.log10(np.maximum(psd[mask], 1e-15))
    slope, _, _, _ = stats.theilslopes(y, x)
    return float(slope)


def line_noise_ratio(freqs: np.ndarray, psd: np.ndarray, mains: float = 60.0,
                     half_width: float = 1.5, gap: float = 3.0) -> float:
    """Mains-band power divided by the power of adjacent background bins.

    A ratio near 1 means no line contamination; values above ~4 mean the
    channel is dominated by interference. Uses side bands offset by ``gap`` Hz
    so the estimate is local and does not depend on the overall power level.
    """
    if mains >= freqs[-1]:
        return float("nan")
    peak = (freqs >= mains - half_width) & (freqs <= mains + half_width)
    side = (
        ((freqs >= mains - gap - half_width) & (freqs <= mains - gap + half_width))
        | ((freqs >= mains + gap - half_width) & (freqs <= mains + gap + half_width))
    )
    if peak.sum() == 0 or side.sum() == 0:
        return float("nan")
    return float(psd[peak].mean() / max(psd[side].mean(), 1e-15))


def line_contamination(freqs: np.ndarray, psd: np.ndarray, mains: float = 60.0,
                       half_width: float = 2.0,
                       band: tuple[float, float] = (1.0, 45.0)) -> float:
    """Residual mains RMS divided by the RMS of the analysis band.

    Mains is summed over the fundamental and every harmonic below Nyquist,
    both terms from the same spectrum, so the answer is "how much of what will
    be analysed is mains": 0.2 means the residual is a fifth of the EEG's
    amplitude (4% of its power).

    ``line_noise_ratio`` asks a different question -- is the mains bin higher
    than its neighbours -- which is right on raw data and wrong on data that
    has already been notched and low-passed: the neighbours at mains +/- 3 Hz
    sit in the low-pass stopband, so a residual of a microvolt or two,
    harmless and outside every band a decoder reads, scores as heavy
    interference. On this project's Unicorn recordings that one check failed
    channels whose amplitude and 1/f slope were physiological, turning a
    session the Unicorn Suite showed as 6/8 good into 1/8 usable.
    """
    if len(freqs) < 2:
        return float("nan")
    df = float(freqs[1] - freqs[0])
    line, h = 0.0, float(mains)
    while h - half_width < freqs[-1]:
        m = (freqs >= h - half_width) & (freqs <= h + half_width)
        line += float(psd[m].sum()) * df
        h += mains
    hi = min(band[1], mains - 2 * half_width - 1.0)
    inband = (freqs >= band[0]) & (freqs <= hi)
    if not inband.any():
        return float("nan")
    return float(np.sqrt(line / max(float(psd[inband].sum()) * df, 1e-15)))


class QualityMonitor:
    """Computes per-channel quality for an epoch of data.

    Args:
        mains: 50.0 in most of the world, 60.0 in North America. Getting this
            wrong makes the notch filter and this metric both useless, so it is
            a required decision rather than a hidden default.
        saturation_uv: amplitude at which the amplifier is assumed to be
            railing. Device-specific; the Unicorn's usable range is far wider
            than any physiological signal, so the default is generous.
        saturation_fraction: share of the window that must sit past
            ``saturation_uv`` before the channel counts as saturated. Railing
            is sustained; a single sample past the limit is a blink or a
            knock, and letting it zero the channel made the readout flip
            between 8/8 and 0/8 from one second to the next.
        line_good / line_hard: residual-mains-to-EEG amplitude ratio (see
            :func:`line_contamination`) at which the mains score starts to
            fall, and at which it reaches zero.
    """

    def __init__(self, mains: float = 60.0, saturation_uv: float = 500.0,
                 saturation_fraction: float = 0.01, line_good: float = 0.2,
                 line_hard: float = 0.6) -> None:
        self.mains = float(mains)
        self.saturation_uv = float(saturation_uv)
        self.saturation_fraction = float(saturation_fraction)
        self.line_good = float(line_good)
        self.line_hard = float(line_hard)

    def __call__(self, data: np.ndarray, sfreq: float,
                 ch_names: tuple[str, ...] | list[str]) -> list[ChannelQuality]:
        freqs, psd = welch_psd(data, sfreq)
        out: list[ChannelQuality] = []

        for i, name in enumerate(ch_names):
            x = data[i]
            rms = float(np.sqrt(np.mean((x - x.mean()) ** 2)))
            ptp = float(np.ptp(x))
            flat = rms < 0.1
            sat_frac = float(np.mean(np.abs(x) >= self.saturation_uv))
            saturated = sat_frac > self.saturation_fraction
            lnr = line_noise_ratio(freqs, psd[i], self.mains)
            contam = line_contamination(freqs, psd[i], self.mains)
            slope = spectral_slope(freqs, psd[i])

            flags: list[str] = []
            if flat:
                flags.append("flat")
            if saturated:
                flags.append("saturated")

            if flat or saturated:
                score = 0.0
            else:
                # Physiological EEG RMS sits in roughly 5-40 uV at the scalp.
                s_amp = _score_range(rms, good=(3.0, 45.0), hard=(0.5, 120.0))
                # Scored on contamination, not on line_ratio: see
                # line_contamination() for why the ratio misfires on
                # notched, low-passed data. line_ratio is still reported.
                s_line = 1.0 if not np.isfinite(contam) else _score_range(
                    contam, good=(0.0, self.line_good), hard=(0.0, self.line_hard))
                s_slope = 1.0 if not np.isfinite(slope) else _score_range(
                    slope, good=(-2.5, -0.7), hard=(-4.0, 0.3)
                )
                # Geometric mean: any single catastrophic metric drags the
                # composite down, which an arithmetic mean would mask.
                score = float((max(s_amp, 1e-6) * max(s_line, 1e-6)
                               * max(s_slope, 1e-6)) ** (1 / 3))
                if s_line < 0.5:
                    flags.append("line_noise")
                if s_slope < 0.5:
                    flags.append("non_physiological_spectrum")
                if s_amp < 0.5:
                    flags.append("amplitude_out_of_range")

            out.append(ChannelQuality(
                name=name, score=round(score, 3), rms_uv=round(rms, 2),
                ptp_uv=round(ptp, 2),
                line_ratio=round(lnr, 2) if np.isfinite(lnr) else float("nan"),
                spectral_slope=round(slope, 2) if np.isfinite(slope) else float("nan"),
                flat=flat, saturated=saturated, flags=flags,
                line_contamination=(round(contam, 3) if np.isfinite(contam)
                                    else float("nan")),
                saturated_fraction=round(sat_frac, 4),
            ))
        return out

    def summary(self, qualities: list[ChannelQuality]) -> dict:
        scores = [q.score for q in qualities]
        return {
            "mean_score": round(float(np.mean(scores)), 3) if scores else 0.0,
            "n_usable": sum(q.usable for q in qualities),
            "n_channels": len(qualities),
            "worst": min(qualities, key=lambda q: q.score).name if qualities else None,
            "per_channel": {q.name: q.score for q in qualities},
            "advice": [q.advice() for q in qualities if not q.usable],
        }
