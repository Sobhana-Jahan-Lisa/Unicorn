"""Core data types.

These five types are the entire contract between layers. A Source produces
Chunks, a Buffer turns Chunks into Epochs, a Pipeline turns Epochs into
Features and then a Prediction, and a Transport serialises Predictions.

Nothing below this module imports anything above it.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np


@dataclass(frozen=True)
class DeviceInfo:
    """Everything downstream code is allowed to know about the hardware.

    This is the hardware-abstraction contract. Any Source must be able to fill
    it in. Pipelines are written against *this*, never against a device id, so
    swapping a Unicorn (8ch @ 250 Hz) for a Muse (4ch @ 256 Hz) changes only
    which Source is constructed.
    """

    name: str
    sfreq: float
    ch_names: tuple[str, ...]
    ch_types: tuple[str, ...] = ()          # 'eeg', 'eog', 'accel', 'misc'
    unit: str = "uV"
    extra: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.sfreq <= 0:
            raise ValueError(f"sfreq must be positive, got {self.sfreq}")
        if not self.ch_names:
            raise ValueError("device must declare at least one channel")
        if self.ch_types and len(self.ch_types) != len(self.ch_names):
            raise ValueError("ch_types must match ch_names in length")

    @property
    def n_channels(self) -> int:
        return len(self.ch_names)

    def eeg_indices(self) -> list[int]:
        """Indices of EEG channels; all channels if types were not declared."""
        if not self.ch_types:
            return list(range(self.n_channels))
        return [i for i, t in enumerate(self.ch_types) if t == "eeg"]

    def pick(self, names: list[str]) -> list[int]:
        """Resolve channel names to indices, raising a useful error if absent.

        Lets a config say ``channels: [O1, O2]`` and fail loudly on a headset
        that does not have them, instead of silently mis-indexing.
        """
        missing = [n for n in names if n not in self.ch_names]
        if missing:
            raise KeyError(
                f"{self.name} has no channel(s) {missing}. "
                f"Available: {list(self.ch_names)}"
            )
        return [self.ch_names.index(n) for n in names]


@dataclass
class Chunk:
    """A block of samples as they arrive from the device.

    Attributes:
        data: shape (n_channels, n_samples), float64, in ``DeviceInfo.unit``.
        t_start: monotonic seconds of the FIRST sample in this chunk.
        seq: monotonically increasing chunk counter, used to detect drops.
        aux: optional per-sample side rows the device delivers with the EEG,
            keyed by name -- ``"timestamp"``, ``"package_num"``, ``"marker"``
            and ``"battery"`` for a BrainFlow board -- each ``(n_samples,)``
            and aligned with ``data``'s columns. ``None`` when there are none.
    """

    data: np.ndarray
    t_start: float
    seq: int = 0
    aux: dict[str, np.ndarray] | None = None

    @property
    def n_samples(self) -> int:
        return self.data.shape[1]


@dataclass
class Epoch:
    """A fixed-length analysis window carved out of the buffer."""

    data: np.ndarray            # (n_channels, n_samples)
    t_start: float
    sfreq: float
    ch_names: tuple[str, ...]
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def duration(self) -> float:
        return self.data.shape[1] / self.sfreq


@dataclass
class Prediction:
    """What the pipeline emits to the game.

    ``value`` is the control signal (class label or continuous score),
    ``confidence`` drives whether the game should act on it, and ``quality``
    carries per-channel signal quality so the front end can tell a student
    "electrode O1 has fallen off" instead of just behaving strangely.
    """

    value: float | int | str
    confidence: float = 1.0
    t_epoch: float = 0.0                                  # epoch start time
    t_emit: float = 0.0                                   # when we produced it
    features: dict[str, float] = field(default_factory=dict)
    quality: dict[str, float] = field(default_factory=dict)

    @property
    def latency(self) -> float:
        """Seconds from the start of the analysed window to emission."""
        return self.t_emit - self.t_epoch
