"""Pipeline: the ordered list of stages that turns an Epoch into a Prediction.

There are exactly three stage kinds, and each is a plain callable with a
declared input/output type. Keeping the taxonomy this small is what makes the
YAML config legible to a beginner:

    Transform : Epoch     -> Epoch        (filtering, re-referencing, artefact)
    Extractor : Epoch     -> dict[str, float]   (band power, ERP amplitude...)
    Decoder   : dict      -> Prediction   (threshold, sklearn model, rule)

Every stage also exposes ``get_params()`` so the whole pipeline can be
serialised back to the config that produced it -- that round-trip is the
reproducibility guarantee.
"""

from __future__ import annotations

import time
from typing import Any, Protocol, runtime_checkable

from .types import Epoch, Prediction
from .clock import now


@runtime_checkable
class Stage(Protocol):
    """Anything a pipeline can hold."""

    def get_params(self) -> dict[str, Any]: ...


class Transform(Protocol):
    def __call__(self, epoch: Epoch) -> Epoch: ...
    def get_params(self) -> dict[str, Any]: ...


class Extractor(Protocol):
    def __call__(self, epoch: Epoch) -> dict[str, float]: ...
    def get_params(self) -> dict[str, Any]: ...


class Decoder(Protocol):
    def __call__(self, features: dict[str, float]) -> Prediction: ...
    def get_params(self) -> dict[str, Any]: ...


class BaseStage:
    """Convenience base: records constructor kwargs for serialisation."""

    _params: dict[str, Any]

    def _record(self, **params: Any) -> None:
        self._params = params

    def get_params(self) -> dict[str, Any]:
        return dict(getattr(self, "_params", {}))

    def __repr__(self) -> str:
        args = ", ".join(f"{k}={v!r}" for k, v in self.get_params().items())
        return f"{type(self).__name__}({args})"


class Pipeline:
    """Runs transforms -> extractor -> decoder on each epoch.

    The decoder is optional: leave it out and the pipeline emits raw features,
    which is exactly what a "show me my alpha power" classroom demo needs
    before anyone introduces the word *classifier*.
    """

    def __init__(
        self,
        transforms: list[Transform] | None = None,
        extractor: Extractor | None = None,
        decoder: Decoder | None = None,
        name: str = "pipeline",
    ) -> None:
        self.transforms = list(transforms or [])
        self.extractor = extractor
        self.decoder = decoder
        self.name = name

    def __call__(self, epoch: Epoch) -> Prediction:
        for tf in self.transforms:
            epoch = tf(epoch)

        features: dict[str, float] = {}
        if self.extractor is not None:
            features = self.extractor(epoch)

        if self.decoder is not None:
            pred = self.decoder(features)
        else:
            first = next(iter(features.values()), 0.0)
            pred = Prediction(value=first, confidence=1.0)

        pred.features = features
        pred.t_epoch = epoch.t_start
        pred.t_emit = now()
        return pred

    def describe(self) -> dict[str, Any]:
        """Full pipeline provenance -- log this at the top of every session."""
        return {
            "name": self.name,
            "transforms": [
                {"type": type(t).__name__, "params": t.get_params()}
                for t in self.transforms
            ],
            "extractor": (
                None
                if self.extractor is None
                else {
                    "type": type(self.extractor).__name__,
                    "params": self.extractor.get_params(),
                }
            ),
            "decoder": (
                None
                if self.decoder is None
                else {
                    "type": type(self.decoder).__name__,
                    "params": self.decoder.get_params(),
                }
            ),
        }
