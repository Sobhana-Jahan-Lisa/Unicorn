"""The session timebase.

Every timestamp in this package -- chunk arrival, epoch start, prediction
emission, transport send, learning event -- comes from ``now()``. They are
subtracted from one another constantly, so they must all come from the *same*
clock; mixing two monotonic sources gives differences that are meaningless and
occasionally negative.

``time.perf_counter()`` rather than ``time.monotonic()``, because on Windows
before Python 3.13 ``monotonic()`` is backed by ``GetTickCount64`` with a
resolution of about 15.6 ms. That is catastrophic here: this package reports
end-to-end latency as a study outcome, and a 15.6 ms quantum makes every
sub-tick measurement read as either 0 ms or 16 ms. A real pipeline step of
0.9 ms was being reported as 16.0 ms on Windows and 0.0 ms on the synthetic
source -- both wrong, and wrong in a way that looks plausible.

``perf_counter()`` is monotonic on every supported platform and uses the
highest-resolution clock available (``QueryPerformanceCounter`` on Windows,
sub-microsecond). It carries no epoch, which is fine: nothing here needs wall
time except the human-readable ``wall`` field in the event log, which uses
``datetime`` separately.
"""

from __future__ import annotations

import time


def now() -> float:
    """Seconds on the shared monotonic, high-resolution session clock."""
    return time.perf_counter()


def resolution() -> float:
    """Measured tick size of the session clock, in seconds.

    Recorded in the session manifest so a reader can tell whether reported
    sub-millisecond timings were actually resolvable on the machine that
    produced them.
    """
    t0 = now()
    t1 = now()
    while t1 == t0:
        t1 = now()
    return t1 - t0
