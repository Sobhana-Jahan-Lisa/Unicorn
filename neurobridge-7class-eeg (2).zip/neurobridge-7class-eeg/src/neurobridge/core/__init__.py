"""Core types and streaming primitives."""
