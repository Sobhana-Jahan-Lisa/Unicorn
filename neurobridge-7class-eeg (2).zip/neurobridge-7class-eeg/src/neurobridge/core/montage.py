"""Functional montage resolution: the layer that actually makes pipelines portable.

The problem
-----------
BrainFlow abstracts the *wire protocol* across headsets, but not the *montage*.
A pipeline written as ``channels: ["O1", "O2"]`` silently breaks on a headset
that calls them ``PO7``/``PO8`` (Unicorn) or has no occipital electrode at all
(Muse: TP9, AF7, AF8, TP10). Every published beginner toolkit pushes this
problem onto the user.

The approach
------------
Pipelines request a *functional role* -- ``occipital``, ``central_left``,
``frontal_midline`` -- and this module resolves it against whatever montage the
connected device reports, with an explicit, logged fallback when the ideal
electrode is absent. A config becomes device-independent without pretending
that all devices are equivalent: ``resolve()`` returns the substitution it made
and a 0-1 fidelity score, so a study can report exactly how each headset was
mapped instead of hiding it.

Coordinates
-----------
Positions are derived from the 10-20 label itself rather than a hard-coded
coordinate table. In the 10-20/10-10 system the letter prefix names a coronal
line and the digit names a lateral step, so a label like ``CP3`` fully
determines an approximate grid position. This is a topological approximation
suitable for neighbourhood queries, not a head model for source localisation --
see ``fidelity`` for how uncertainty is propagated.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass

# Coronal lines from anterior (+) to posterior (-), in 10-10 order.
_ROW_ORDER = [
    "NZ", "FP", "AF", "F", "FT", "FC", "C", "TP", "CP", "P", "PO", "O", "I",
]
# Anterior-posterior coordinate for each prefix, normalised to [-1, 1].
_ROW_Y = {
    "NZ": 1.15, "FP": 1.00, "AF": 0.72, "F": 0.45, "FT": 0.33, "FC": 0.22,
    "T": 0.00, "C": 0.00, "A": 0.00, "TP": -0.22, "CP": -0.22, "P": -0.45,
    "PO": -0.72, "O": -1.00, "I": -1.15,
}
# Lateral coordinate per digit. Odd = left (negative x), even = right.
_DIGIT_X = {0: 0.0, 1: 0.25, 2: 0.50, 3: 0.75, 4: 0.95, 5: 1.10}

# Non-greedy prefix: a greedy one swallows the 'z' in midline labels, so 'Oz'
# would parse as prefix 'OZ' (unknown) instead of prefix 'O' with suffix 'z'.
_LABEL_RE = re.compile(r"^([A-Za-z]+?)([zZ]|\d+)?$")

REGIONS: dict[str, tuple[str, ...]] = {
    "frontopolar": ("FP",),
    "frontal": ("FP", "AF", "F"),
    "frontocentral": ("FC", "FT"),
    "central": ("C", "FC", "CP"),
    "temporal": ("T", "FT", "TP"),
    "parietal": ("P", "CP"),
    "parietooccipital": ("PO",),
    "occipital": ("O", "PO", "I"),
    "posterior": ("P", "PO", "O", "I"),
    "anterior": ("FP", "AF", "F"),
}

#: Roles a pipeline may request, with the ideal 10-20 sites for each.
#: ``ROLES`` is intentionally small and physiologically motivated; adding a role
#: means naming what it is *for*.
ROLES: dict[str, dict] = {
    # Posterior alpha (Berger rhythm) -- eyes-closed / relaxation signal.
    "alpha_posterior": {"ideal": ("O1", "O2", "Oz", "PO7", "PO8", "POz"),
                        "region": "occipital", "min": 1},
    # SSVEP responds best over primary visual cortex.
    "ssvep": {"ideal": ("Oz", "O1", "O2", "POz", "PO3", "PO4", "PO7", "PO8"),
              "region": "occipital", "min": 1},
    # Sensorimotor mu/beta, left and right hand areas.
    "motor_left": {"ideal": ("C3", "CP3", "FC3", "C1"), "region": "central", "min": 1},
    "motor_right": {"ideal": ("C4", "CP4", "FC4", "C2"), "region": "central", "min": 1},
    "motor_midline": {"ideal": ("Cz", "CPz", "FCz"), "region": "central", "min": 1},
    # Frontal midline theta -- workload / sustained attention.
    "theta_frontal": {"ideal": ("Fz", "FCz", "AFz", "F1", "F2"),
                      "region": "frontal", "min": 1},
    # Frontal alpha asymmetry -- approach/withdrawal affect.
    "asym_left": {"ideal": ("F3", "F7", "AF7", "FP1"), "region": "frontal", "min": 1},
    "asym_right": {"ideal": ("F4", "F8", "AF8", "FP2"), "region": "frontal", "min": 1},
    # P300 / oddball.
    "p300": {"ideal": ("Pz", "CPz", "Cz", "POz"), "region": "parietal", "min": 1},
    # Blink/EOG proxy for artefact detection.
    "eog_proxy": {"ideal": ("FP1", "FP2", "AF7", "AF8", "FPz"),
                  "region": "frontopolar", "min": 1},
}


def parse_label(label: str) -> tuple[str, float, float] | None:
    """Return (prefix, x, y) for a 10-20 label, or None if unparseable.

    x runs left(-) to right(+), y runs posterior(-) to anterior(+).
    """
    m = _LABEL_RE.match(label.strip())
    if not m:
        return None
    prefix, suffix = m.group(1).upper(), m.group(2)
    if prefix not in _ROW_Y:
        # Handle 'TP9' style where prefix is multi-letter but unknown.
        return None
    y = _ROW_Y[prefix]
    if suffix is None or suffix.upper() == "Z":
        x = 0.0
    else:
        n = int(suffix)
        step = (n + 1) // 2                      # 1,2->1  3,4->2  5,6->3 ...
        x = _DIGIT_X.get(step, 1.10 + 0.1 * (step - 5))
        if n % 2 == 1:
            x = -x
    # Pure temporal labels (T7/T8) sit on the equator but far laterally.
    if prefix == "T":
        x = math.copysign(max(abs(x), 0.95), x if x != 0 else 1.0)
    return prefix, x, y


def distance(a: str, b: str) -> float:
    """Approximate scalp distance between two labels (0 = same site)."""
    pa, pb = parse_label(a), parse_label(b)
    if pa is None or pb is None:
        return float("inf")
    return math.hypot(pa[1] - pb[1], pa[2] - pb[2])


@dataclass(frozen=True)
class RoleMatch:
    """Result of resolving one functional role against a real montage."""

    role: str
    indices: tuple[int, ...]
    names: tuple[str, ...]
    fidelity: float          # 1.0 = ideal site present; decays with distance
    exact: bool
    note: str = ""

    @property
    def ok(self) -> bool:
        return len(self.indices) > 0


class Montage:
    """Resolves functional roles against one device's channel list."""

    #: Fidelity floor below which a role is treated as unavailable.
    MIN_FIDELITY = 0.35

    def __init__(self, ch_names: tuple[str, ...] | list[str]) -> None:
        self.ch_names = tuple(ch_names)
        self._upper = {n.upper(): i for i, n in enumerate(self.ch_names)}
        self._parsed = {n: parse_label(n) for n in self.ch_names}

    def has(self, label: str) -> int | None:
        return self._upper.get(label.upper())

    def in_region(self, region: str) -> list[int]:
        prefixes = REGIONS.get(region.lower())
        if prefixes is None:
            raise KeyError(f"unknown region {region!r}; known: {sorted(REGIONS)}")
        out = []
        for name, parsed in self._parsed.items():
            if parsed and parsed[0] in prefixes:
                out.append(self._upper[name.upper()])
        return sorted(out)

    def resolve(self, role: str, max_channels: int = 4) -> RoleMatch:
        """Find the best available channels for a functional role.

        Strategy, in order:
          1. exact ideal sites present on the device;
          2. otherwise the nearest available electrodes to the ideal sites,
             with fidelity = exp(-d / 0.5) averaged over the picked channels;
          3. otherwise anything in the anatomical region;
          4. otherwise an empty match, which the caller must handle.
        """
        if role not in ROLES:
            raise KeyError(f"unknown role {role!r}; known: {sorted(ROLES)}")
        spec = ROLES[role]
        ideal: tuple[str, ...] = spec["ideal"]

        exact_idx = [self._upper[s.upper()] for s in ideal if s.upper() in self._upper]
        if len(exact_idx) >= spec["min"]:
            idx = tuple(exact_idx[:max_channels])
            return RoleMatch(
                role=role,
                indices=idx,
                names=tuple(self.ch_names[i] for i in idx),
                fidelity=1.0,
                exact=True,
            )

        # Nearest-site substitution.
        scored: list[tuple[float, int]] = []
        for name, parsed in self._parsed.items():
            if parsed is None:
                continue
            d = min(distance(name, s) for s in ideal)
            scored.append((d, self._upper[name.upper()]))
        scored.sort()

        picked = [i for d, i in scored[: max(spec["min"], min(max_channels, 2))]
                  if math.isfinite(d)]
        if picked:
            dists = [d for d, i in scored if i in picked]
            fidelity = sum(math.exp(-d / 0.5) for d in dists) / len(dists)
            if fidelity >= self.MIN_FIDELITY:
                return RoleMatch(
                    role=role,
                    indices=tuple(picked),
                    names=tuple(self.ch_names[i] for i in picked),
                    fidelity=round(fidelity, 3),
                    exact=False,
                    note=(
                        f"no ideal site {ideal} on this montage; substituted "
                        f"nearest available"
                    ),
                )

        region_idx = self.in_region(spec["region"])
        if region_idx:
            idx = tuple(region_idx[:max_channels])
            return RoleMatch(
                role=role,
                indices=idx,
                names=tuple(self.ch_names[i] for i in idx),
                fidelity=self.MIN_FIDELITY,
                exact=False,
                note=f"fell back to any {spec['region']} electrode",
            )

        return RoleMatch(
            role=role, indices=(), names=(), fidelity=0.0, exact=False,
            note=f"device has no usable electrode for role {role!r}",
        )

    def report(self, roles: list[str] | None = None) -> dict[str, dict]:
        """Resolve several roles at once -- log this in the session manifest."""
        roles = roles or list(ROLES)
        out = {}
        for r in roles:
            m = self.resolve(r)
            out[r] = {
                "channels": list(m.names),
                "fidelity": m.fidelity,
                "exact": m.exact,
                "note": m.note,
            }
        return out
