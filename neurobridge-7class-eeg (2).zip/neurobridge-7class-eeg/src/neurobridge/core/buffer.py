"""Lock-free-enough ring buffer and sliding-window epocher.

Design notes
------------
The acquisition thread and the processing loop run at different rates: the
device pushes irregular chunks (BrainFlow returns whatever has accumulated),
while the pipeline wants regular windows (e.g. 1.0 s every 0.25 s). Decoupling
them through a ring buffer is what keeps jitter out of the feature stream.

The buffer stores a fixed number of samples in a pre-allocated array and never
reallocates, so per-chunk cost is O(n_new) with no GC pressure. Windows are
emitted on a *sample-count* schedule, not a wall-clock schedule, so the epoch
grid stays locked to the device clock even if a chunk arrives late.
"""

from __future__ import annotations

import threading

import numpy as np

from .types import Chunk, DeviceInfo, Epoch


class RingBuffer:
    """Fixed-capacity circular buffer of shape (n_channels, capacity)."""

    def __init__(self, n_channels: int, capacity: int) -> None:
        if capacity <= 0:
            raise ValueError("capacity must be positive")
        self._buf = np.zeros((n_channels, capacity), dtype=np.float64)
        self._capacity = capacity
        self._write = 0          # next write position
        self._total = 0          # total samples ever written
        self._lock = threading.Lock()

    @property
    def capacity(self) -> int:
        return self._capacity

    @property
    def total_written(self) -> int:
        return self._total

    @property
    def n_available(self) -> int:
        return min(self._total, self._capacity)

    def push(self, data: np.ndarray) -> None:
        """Append samples, overwriting the oldest when full."""
        if data.ndim != 2 or data.shape[0] != self._buf.shape[0]:
            raise ValueError(
                f"expected ({self._buf.shape[0]}, n_samples), got {data.shape}"
            )
        n = data.shape[1]
        if n == 0:
            return
        if n >= self._capacity:
            # Chunk larger than the buffer: keep only the newest capacity samples.
            data = data[:, -self._capacity:]
            n = self._capacity
        with self._lock:
            end = self._write + n
            if end <= self._capacity:
                self._buf[:, self._write:end] = data
            else:
                split = self._capacity - self._write
                self._buf[:, self._write:] = data[:, :split]
                self._buf[:, : n - split] = data[:, split:]
            self._write = end % self._capacity
            self._total += n

    def latest(self, n: int) -> np.ndarray:
        """Return the most recent ``n`` samples in chronological order."""
        if n > self._capacity:
            raise ValueError(f"requested {n} samples, capacity is {self._capacity}")
        with self._lock:
            if n > self.n_available:
                raise ValueError(
                    f"only {self.n_available} samples buffered, {n} requested"
                )
            start = (self._write - n) % self._capacity
            if start + n <= self._capacity:
                return self._buf[:, start:start + n].copy()
            split = self._capacity - start
            out = np.empty((self._buf.shape[0], n), dtype=np.float64)
            out[:, :split] = self._buf[:, start:]
            out[:, split:] = self._buf[:, : n - split]
            return out


class SlidingWindow:
    """Turns a stream of Chunks into evenly spaced Epochs.

    Args:
        device: describes channels and sampling rate.
        window: analysis window length in seconds (e.g. 1.0).
        step: hop between consecutive windows in seconds (e.g. 0.25).
            ``window / step`` sets the update rate the game sees; overlap is
            what buys you a responsive control signal without shrinking the
            window below the frequency resolution band-power needs.
        history: seconds retained in the ring buffer. Must exceed ``window``;
            extra headroom absorbs scheduling hiccups without dropping data.
    """

    def __init__(
        self,
        device: DeviceInfo,
        window: float = 1.0,
        step: float = 0.25,
        history: float | None = None,
    ) -> None:
        if step <= 0 or window <= 0:
            raise ValueError("window and step must be positive")
        if step > window:
            # Legal, but it means you are discarding data between windows.
            pass
        self.device = device
        self.window = window
        self.step = step
        self.n_window = max(1, int(round(window * device.sfreq)))
        self.n_step = max(1, int(round(step * device.sfreq)))

        history = history if history is not None else max(4 * window, window + 2.0)
        if history < window:
            raise ValueError("history must be >= window")
        capacity = int(round(history * device.sfreq))
        self.buffer = RingBuffer(device.n_channels, capacity)

        self._t0: float | None = None      # time of the very first sample
        self._next_emit = self.n_window    # emit once we have a full window
        self.dropped_chunks = 0
        self._last_seq: int | None = None

    def push(self, chunk: Chunk) -> list[Epoch]:
        """Feed a chunk in; return every window that became complete.

        Returns zero, one, or several epochs -- several when a chunk arrives
        late and covers more than one step. Handling that here is what keeps
        the epoch grid regular under wireless jitter.

        This deliberately returns a list rather than being a generator. As a
        generator, a caller who ignored the return value would silently fail to
        buffer the data at all, since the body would never execute -- a bug
        that looks like a dead headset and is very hard to find.
        """
        out: list[Epoch] = []
        if self._t0 is None:
            self._t0 = chunk.t_start
        if self._last_seq is not None and chunk.seq != self._last_seq + 1:
            self.dropped_chunks += 1
        self._last_seq = chunk.seq

        self.buffer.push(chunk.data)

        while self.buffer.total_written >= self._next_emit:
            end_idx = self._next_emit                      # sample index (exclusive)
            lag = self.buffer.total_written - end_idx      # samples arrived since
            if lag + self.n_window > self.buffer.capacity:
                # We fell so far behind the window has been overwritten. Skip
                # ahead rather than emit corrupted data.
                self._next_emit += self.n_step
                continue
            data = self.buffer.latest(lag + self.n_window)[:, : self.n_window]
            t_start = self._t0 + (end_idx - self.n_window) / self.device.sfreq
            out.append(Epoch(
                data=data,
                t_start=t_start,
                sfreq=self.device.sfreq,
                ch_names=self.device.ch_names,
                meta={"index": (end_idx - self.n_window) // self.n_step},
            ))
            self._next_emit += self.n_step
        return out
