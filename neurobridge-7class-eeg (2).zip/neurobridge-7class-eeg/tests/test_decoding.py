"""Decoding: spatial filters, manifold geometry, decision rules, ITR."""

import math

import numpy as np
import pytest
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.model_selection import cross_val_score
from sklearn.pipeline import make_pipeline

from neurobridge.classify.decoders import (
    ArgmaxDecoder, ProportionalDecoder, ThresholdDecoder,
    information_transfer_rate,
)
from neurobridge.classify.transformers import (
    CSP, MDM, TangentSpace, distance_riemann, riemannian_mean,
)


def synth_two_class(n=60, n_ch=6, n_samp=250, seed=0):
    """Two classes differing only in which source is strong, then mixed.

    This is the generative model CSP is designed for: a linear mixture of
    sources whose variance differs by class. If CSP cannot recover it, the
    implementation is wrong.
    """
    rng = np.random.default_rng(seed)
    A = rng.normal(0, 1, (n_ch, n_ch))               # fixed mixing matrix
    X, y = [], []
    for i in range(n):
        cls = i % 2
        s = rng.normal(0, 1, (n_ch, n_samp))
        s[0] *= 3.0 if cls == 0 else 0.4
        s[1] *= 0.4 if cls == 0 else 3.0
        X.append(A @ s)
        y.append(cls)
    return np.stack(X), np.array(y)


# -- CSP --------------------------------------------------------------------

def test_csp_recovers_a_linear_mixture():
    X, y = synth_two_class()
    clf = make_pipeline(CSP(n_components=4), LinearDiscriminantAnalysis())
    acc = cross_val_score(clf, X, y, cv=5).mean()
    assert acc > 0.9, acc


def test_csp_eigenvalues_lie_in_the_unit_interval():
    X, y = synth_two_class()
    csp = CSP(n_components=4).fit(X, y)
    assert np.all(csp.eigenvalues_ >= -1e-9)
    assert np.all(csp.eigenvalues_ <= 1 + 1e-9)


def test_csp_log_variance_features_are_finite_and_shaped():
    X, y = synth_two_class()
    F = CSP(n_components=4).fit(X, y).transform(X)
    assert F.shape == (len(X), 4)
    assert np.all(np.isfinite(F))


def test_csp_rejects_more_components_than_channels():
    X, y = synth_two_class(n_ch=4)
    with pytest.raises(ValueError, match="channels"):
        CSP(n_components=8).fit(X, y)


def test_csp_rejects_three_classes():
    X, y = synth_two_class()
    y3 = y.copy()
    y3[:5] = 2
    with pytest.raises(ValueError, match="two-class"):
        CSP().fit(X, y3)


# -- Riemannian geometry ----------------------------------------------------

def test_riemannian_mean_of_identical_matrices_is_that_matrix():
    rng = np.random.default_rng(1)
    A = rng.normal(0, 1, (5, 5))
    C = A @ A.T + 5 * np.eye(5)
    M = riemannian_mean(np.stack([C] * 6))
    assert np.allclose(M, C, atol=1e-6)


def test_riemannian_mean_is_spd():
    rng = np.random.default_rng(2)
    covs = []
    for _ in range(8):
        A = rng.normal(0, 1, (4, 12))
        covs.append(A @ A.T / 12 + 0.1 * np.eye(4))
    M = riemannian_mean(np.stack(covs))
    assert np.allclose(M, M.T)
    assert np.linalg.eigvalsh(M).min() > 0


def test_riemannian_mean_avoids_determinant_swelling():
    """The property that motivates using it instead of the arithmetic mean."""
    C1 = np.diag([9.0, 1.0])
    C2 = np.diag([1.0, 9.0])
    geo = riemannian_mean(np.stack([C1, C2]))
    arith = (C1 + C2) / 2
    assert np.linalg.det(geo) < np.linalg.det(arith)
    # Geodesic midpoint of these two is the identity times 3.
    assert np.allclose(geo, 3.0 * np.eye(2), atol=1e-6)


def test_riemannian_distance_is_a_metric_on_a_simple_case():
    A = np.eye(3)
    B = np.diag([np.e**2, 1.0, 1.0])
    assert distance_riemann(A, A) == pytest.approx(0.0, abs=1e-9)
    assert distance_riemann(A, B) == pytest.approx(2.0, rel=1e-6)
    assert distance_riemann(A, B) == pytest.approx(distance_riemann(B, A), rel=1e-9)


def test_tangent_space_preserves_the_frobenius_norm():
    """The sqrt(2) off-diagonal scaling is what makes this hold."""
    rng = np.random.default_rng(3)
    X = rng.normal(0, 1, (5, 4, 200))
    ts = TangentSpace().fit(X)
    v = ts.transform(X)
    from neurobridge.classify.transformers import _logm, _sqrtm_inv
    from neurobridge.process.features import covariance
    C = covariance(X[0])
    S = _logm(ts.mean_isqrt_ @ C @ ts.mean_isqrt_)
    assert np.linalg.norm(v[0]) == pytest.approx(np.linalg.norm(S, "fro"), rel=1e-9)


def test_tangent_space_maps_the_mean_to_the_origin():
    rng = np.random.default_rng(4)
    X = np.stack([rng.normal(0, 1, (4, 300)) for _ in range(10)])
    ts = TangentSpace().fit(X)
    v = ts.transform(X)
    assert np.abs(v.mean(axis=0)).max() < 0.35


def test_mdm_classifies_separable_data():
    X, y = synth_two_class(n=40)
    acc = cross_val_score(MDM(), X, y, cv=4).mean()
    assert acc > 0.85, acc


def test_mdm_probabilities_are_normalised():
    X, y = synth_two_class(n=20)
    p = MDM().fit(X, y).predict_proba(X)
    assert np.allclose(p.sum(axis=1), 1.0)


# -- decoders ---------------------------------------------------------------

def test_threshold_hysteresis_suppresses_chatter():
    d = ThresholdDecoder("a", low=0.3, high=0.7)
    seq = [0.0, 0.8, 0.5, 0.5, 0.6, 0.2, 0.4, 0.9]
    out = [d({"a": x}).value for x in seq]
    assert out == [0, 1, 1, 1, 1, 0, 0, 1]


def test_threshold_requires_low_below_high():
    with pytest.raises(ValueError):
        ThresholdDecoder("a", low=0.8, high=0.2)


def test_threshold_reports_the_missing_feature_by_name():
    d = ThresholdDecoder("alpha", 0.2, 0.5)
    with pytest.raises(KeyError, match="alpha"):
        d({"beta": 1.0})


def test_proportional_saturates_and_smooths():
    d = ProportionalDecoder("a", x_lo=0.0, x_hi=1.0, tau=0.0)
    assert d({"a": -5.0}).value == 0.0
    assert d({"a": 5.0}).value == 1.0
    smooth = ProportionalDecoder("a", 0.0, 1.0, tau=1.0, update_rate=4.0)
    assert smooth({"a": 0.0}).value == 0.0          # seeds on first sample
    first = smooth({"a": 1.0}).value
    second = smooth({"a": 1.0}).value
    assert 0.0 < first < second < 1.0               # then approaches it


def test_argmax_abstains_on_a_near_tie():
    d = ArgmaxDecoder(min_score=0.05, min_margin=0.2, n_confirm=1)
    assert d({"rho_10": 0.50, "rho_12": 0.49}).value == "none"


def test_argmax_selects_a_clear_winner_after_confirmation():
    d = ArgmaxDecoder(min_score=0.05, min_margin=0.2, n_confirm=2)
    d({"rho_10": 0.9, "rho_12": 0.1})
    assert d({"rho_10": 0.9, "rho_12": 0.1}).value == "10"


def test_argmax_abstains_when_all_scores_are_weak():
    d = ArgmaxDecoder(min_score=0.5, min_margin=0.1, n_confirm=1)
    assert d({"rho_10": 0.2, "rho_12": 0.01}).value == "none"


# -- ITR --------------------------------------------------------------------

def test_itr_perfect_binary_is_one_bit():
    r = information_transfer_rate(1.0, 2, 60.0)
    assert r["bits_per_selection"] == pytest.approx(1.0)
    assert r["bits_per_minute"] == pytest.approx(1.0)


def test_itr_at_chance_is_zero():
    assert information_transfer_rate(0.5, 2, 10.0)["bits_per_selection"] == 0.0
    assert information_transfer_rate(0.25, 4, 10.0)["bits_per_selection"] == 0.0


def test_itr_known_value():
    """4 classes at 80% accuracy: 2 + 0.8*log2(0.8) + 0.2*log2(0.2/3)."""
    expected = 2 + 0.8 * math.log2(0.8) + 0.2 * math.log2(0.2 / 3)
    r = information_transfer_rate(0.8, 4, 5.0)
    assert r["bits_per_selection"] == pytest.approx(expected, abs=1e-4)
    assert r["bits_per_selection"] == pytest.approx(0.9611, abs=1e-3)
    assert r["bits_per_minute"] == pytest.approx(expected * 12, abs=1e-3)


def test_itr_prices_the_abstention_tradeoff():
    """Slower but more accurate can still be worse -- ITR is what shows it."""
    greedy = information_transfer_rate(0.70, 4, 2.0)["bits_per_minute"]
    cautious = information_transfer_rate(0.95, 4, 6.0)["bits_per_minute"]
    assert greedy > cautious
