"""Ring buffer and sliding-window epoching."""

import numpy as np
import pytest

from neurobridge.core.buffer import RingBuffer, SlidingWindow
from neurobridge.core.types import Chunk, DeviceInfo

DEV = DeviceInfo(name="t", sfreq=100.0, ch_names=("a", "b"))


def test_ring_buffer_preserves_order_across_wrap():
    rb = RingBuffer(2, 10)
    for i in range(15):
        rb.push(np.full((2, 1), float(i)))
    assert np.allclose(rb.latest(10)[0], np.arange(5, 15))


def test_ring_buffer_rejects_oversized_request():
    rb = RingBuffer(2, 8)
    rb.push(np.zeros((2, 8)))
    with pytest.raises(ValueError):
        rb.latest(9)


def test_ring_buffer_reports_insufficient_data():
    rb = RingBuffer(2, 100)
    rb.push(np.zeros((2, 10)))
    with pytest.raises(ValueError):
        rb.latest(50)


def test_chunk_larger_than_capacity_keeps_newest():
    rb = RingBuffer(1, 5)
    rb.push(np.arange(20, dtype=float)[None, :])
    assert np.allclose(rb.latest(5)[0], np.arange(15, 20))


def test_sliding_window_grid_is_regular():
    """Windows must be evenly spaced however irregularly chunks arrive."""
    sw = SlidingWindow(DEV, window=1.0, step=0.25, history=4.0)
    starts, counter = [], 0
    rng = np.random.default_rng(0)
    for seq in range(1, 60):
        n = int(rng.integers(3, 40))
        data = np.arange(counter, counter + n, dtype=float)
        counter += n
        for ep in sw.push(Chunk(np.vstack([data, data]), 0.0, seq)):
            starts.append(ep.t_start)
    assert np.allclose(np.diff(starts), 0.25, atol=1e-9)


def test_sliding_window_content_matches_its_timestamp():
    sw = SlidingWindow(DEV, window=1.0, step=0.5, history=4.0)
    counter, epochs = 0, []
    for seq in range(1, 30):
        data = np.arange(counter, counter + 17, dtype=float)
        counter += 17
        epochs += list(sw.push(Chunk(np.vstack([data, data]), 0.0, seq)))
    assert epochs
    for ep in epochs:
        start = round(ep.t_start * DEV.sfreq)
        assert np.allclose(ep.data[0], np.arange(start, start + 100))


def test_sliding_window_counts_dropped_chunks():
    sw = SlidingWindow(DEV, window=1.0, step=0.5)
    sw.push(Chunk(np.zeros((2, 10)), 0.0, seq=1))
    sw.push(Chunk(np.zeros((2, 10)), 0.0, seq=5))
    assert sw.dropped_chunks == 1


def test_device_info_validates():
    with pytest.raises(ValueError):
        DeviceInfo(name="x", sfreq=0, ch_names=("a",))
    with pytest.raises(ValueError):
        DeviceInfo(name="x", sfreq=100, ch_names=())
    with pytest.raises(KeyError):
        DEV.pick(["zz"])
