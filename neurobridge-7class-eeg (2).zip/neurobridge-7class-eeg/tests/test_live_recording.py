"""Crash-safe recording, sample-exact label markers and threaded acquisition."""

import csv
import json
import time

import numpy as np
import pytest

from neurobridge import SyntheticSource
from neurobridge.core.types import Chunk, DeviceInfo
from neurobridge.io.acquisition import AcquisitionThread
from neurobridge.io.recording import (END_OFFSET, StreamingRecorder, load_recording,
                                      recover_csv_recording, spans_from_markers)
from neurobridge.io.sources import packet_counter_gaps

SF = 250.0
NAMES = ("Fz", "C3", "Cz", "C4", "Pz", "PO7", "Oz", "PO8")
DEVICE = DeviceInfo(name="Unicorn", sfreq=SF, ch_names=NAMES, ch_types=("eeg",) * 8)


def _chunk(rng, start, n=50, marker=None):
    """A raw-looking Unicorn chunk: EEG on a 130 mV offset, plus side rows."""
    data = rng.normal(0, 10, (8, n)) + 130_000.0
    mk = np.zeros(n)
    for i, v in (marker or {}).items():
        mk[i] = v
    aux = {"timestamp": 1.7e9 + (start + np.arange(n)) / SF,
           "package_num": np.arange(start, start + n, dtype=float), "marker": mk}
    return Chunk(data=data, t_start=start / SF, aux=aux)


def test_packet_counter_gaps_counts_skips_and_repeats_but_not_a_wrap():
    assert packet_counter_gaps(np.array([253., 254., 255., 0., 1., 3., 3., 4.])) == (1, 1)
    assert packet_counter_gaps(np.array([5., 6.]), previous=3.0) == (1, 0)
    assert packet_counter_gaps(np.array([7.])) == (0, 0)


def test_spans_from_markers_pairs_each_open_with_its_close():
    m = np.zeros(1000)
    m[100], m[350] = 1, 1 + END_OFFSET
    m[400], m[650] = 3, 3 + END_OFFSET
    m[700] = 2 + END_OFFSET          # closed without being opened
    m[800] = 4                        # never closed
    codes = {1: "Eye Open", 2: "Eye Close", 3: "Clenching Left Hand",
             4: "Clenching Right Hand"}
    spans, problems = spans_from_markers(m, SF, codes, participant="PT-001", session=2)
    assert [(s["label"], s["start_sample"], s["end_sample"]) for s in spans] == [
        ("Eye Open", 100, 350), ("Clenching Left Hand", 400, 650)]
    assert spans[0]["t_start"] == pytest.approx(0.4)
    assert spans[0]["t_end"] == pytest.approx(1.4)
    assert spans[0]["participant"] == "PT-001" and spans[0]["session"] == 2
    assert len(problems) == 2


def test_streaming_recorder_is_on_disk_before_close_and_never_overwrites(tmp_path):
    rng = np.random.default_rng(0)
    rec = StreamingRecorder(DEVICE, tmp_path / "s.npz", extra_meta={"mains": 60.0})
    first = _chunk(rng, 0)
    rec.add(first)
    with (tmp_path / "s.csv").open(encoding="utf-8", newline="") as fh:
        rows = list(csv.reader(fh))
    assert rows[0][:4] == ["sample", "brainflow_timestamp_s", "package_counter", "marker"]
    assert len(rows) == 1 + 50                       # already flushed, before close
    assert json.loads((tmp_path / "s.json").read_text())["status"] == "recording"
    with pytest.raises(FileExistsError):
        StreamingRecorder(DEVICE, tmp_path / "s.npz")

    rec.add(_chunk(rng, 50))
    rec.close(annotations=[{"label": "Eye Open", "t_start": 0.0, "t_end": 0.2}])
    with np.load(tmp_path / "s.npz") as z:
        assert {"data", "chunk_starts", "timestamps", "package_num", "marker",
                "meta"} <= set(z.files)
    data, device, meta = load_recording(tmp_path / "s.npz", repair_dropouts=False)
    assert data.shape == (8, 100) and device.ch_names == NAMES
    assert np.allclose(data[:, :50], first.data, atol=0.01)
    assert meta["annotations"][0]["label"] == "Eye Open"
    assert meta["mains"] == 60.0
    assert json.loads((tmp_path / "s.json").read_text())["status"] == "complete"


def test_recorder_reports_held_samples_and_counter_gaps(tmp_path):
    rng = np.random.default_rng(1)
    rec = StreamingRecorder(DEVICE, tmp_path / "g.npz")
    a = _chunk(rng, 0)
    a.data[:, 10:15] = a.data[:, 9:10]              # five held samples
    rec.add(a)
    rec.add(_chunk(rng, 53))                         # counter skips 50, 51, 52
    rec.close()
    with np.load(tmp_path / "g.npz") as z:
        meta = json.loads(str(z["meta"]))
    assert meta["packet_loss"] == {"held_samples": 5, "counter_missing": 3,
                                   "counter_repeated": 0}


def test_a_crashed_session_is_rebuilt_from_its_csv_with_its_labels(tmp_path):
    rng = np.random.default_rng(2)
    rec = StreamingRecorder(DEVICE, tmp_path / "c.npz", extra_meta={
        "marker_codes": {1: "Eye Open"}, "participant": "PT-001", "session": 4})
    rec.add(_chunk(rng, 0, marker={20: 1}))
    rec.add(_chunk(rng, 50))
    rec.add(_chunk(rng, 100, marker={20: 1 + END_OFFSET}))
    rec._fh.close()                                  # the process died here: no close()
    out = recover_csv_recording(tmp_path / "c.csv")
    data, _, meta = load_recording(out, repair_dropouts=False)
    assert data.shape == (8, 150) and meta["recovered_from_csv"]
    (span,) = meta["annotations"]
    assert (span["label"], span["start_sample"], span["end_sample"]) == ("Eye Open", 20, 120)
    assert span["participant"] == "PT-001" and span["session"] == 4


def test_acquisition_thread_records_what_consumers_see_and_places_markers(tmp_path):
    src = SyntheticSource(seed=3)
    src.start()
    rec = StreamingRecorder(src.device, tmp_path / "a.npz")
    seen = []
    acq = AcquisitionThread(src, recorder=rec, consumers=[lambda c: seen.append(c.n_samples)])
    acq.start()
    time.sleep(0.4)
    acq.mark(1)
    time.sleep(0.6)
    acq.mark(1 + END_OFFSET)
    time.sleep(0.3)
    acq.close()
    assert acq.error is None
    assert sum(seen) == rec.n_samples == acq.total > 0
    spans, problems = spans_from_markers(rec.markers, src.device.sfreq, {1: "Eye Open"})
    assert problems == [] and len(spans) == 1
    assert spans[0]["t_end"] - spans[0]["t_start"] == pytest.approx(0.6, abs=0.15)
    rec.close()


def test_brainflow_synthetic_board_end_to_end(tmp_path):
    """The real BrainFlow path without a headset: side rows, markers, drain."""
    pytest.importorskip("brainflow")
    from neurobridge import BrainFlowSource

    src = BrainFlowSource("SYNTHETIC_BOARD", repair_dropouts=False)
    src.start()
    rec = StreamingRecorder(src.device, tmp_path / "b.npz")
    acq = AcquisitionThread(src, recorder=rec)
    acq.start()
    time.sleep(0.5)
    acq.mark(2)
    time.sleep(0.8)
    acq.mark(2 + END_OFFSET)
    time.sleep(0.4)
    acq.close()
    assert acq.error is None and acq.problems == []
    spans, problems = spans_from_markers(rec.markers, src.device.sfreq, {2: "Eye Close"})
    assert problems == [] and len(spans) == 1
    assert spans[0]["t_end"] - spans[0]["t_start"] == pytest.approx(0.8, abs=0.15)
    with np.load(rec.close(annotations=spans)) as z:
        assert np.isfinite(z["timestamps"]).all() and np.isfinite(z["package_num"]).all()
        assert json.loads(str(z["meta"]))["packet_loss"]["counter_missing"] == 0
    assert src.counter_missing_total == 0
