"""Config validation and a full end-to-end session on synthetic data."""

import time
from pathlib import Path

import numpy as np
import pytest

from neurobridge import Config, ConfigError, Session, SyntheticSource
from neurobridge.core.types import DeviceInfo, Epoch
from neurobridge.io.recording import (
    Recorder, epochs_from_recording, load_recording,
)
from neurobridge.process.quality import QualityMonitor
from neurobridge.reproducibility import build_manifest, config_hash, diff_manifests

CONFIGS = Path(__file__).resolve().parents[1] / "configs"
UNICORN = DeviceInfo(name="u", sfreq=250.0,
                     ch_names=("Fz", "C3", "Cz", "C4", "Pz", "PO7", "Oz", "PO8"),
                     ch_types=tuple(["eeg"] * 8))
MUSE = DeviceInfo(name="m", sfreq=256.0, ch_names=("TP9", "AF7", "AF8", "TP10"),
                  ch_types=tuple(["eeg"] * 4))


def base_config(**over):
    cfg = {
        "session": {"paradigm": "alpha", "participant": "SCH-0001",
                    "mains": 60.0, "privacy_tier": "derived"},
        "acquisition": {"source": {"type": "synthetic", "sfreq": 250.0,
                                   "realtime": False}},
        "preprocess": {"l_freq": 1.0, "h_freq": 45.0, "notch": 60.0},
        "epoching": {"window": 2.0, "step": 0.25, "history": 8.0},
        "pipeline": {
            "transforms": [{"type": "detrend", "mode": "constant"}],
            "extractor": {"type": "attention",
                          "channels": {"role": "alpha_posterior"}},
            "decoder": {"type": "proportional", "feature": "alpha",
                        "x_lo": 0.0, "x_hi": 1.0},
        },
        "transport": {"host": "127.0.0.1", "port": 8799},
        "logging": {"dir": "/tmp/nb-tests", "raw": False},
    }
    for k, v in over.items():
        cfg[k] = {**cfg.get(k, {}), **v} if isinstance(v, dict) else v
    return cfg


# -- shipped configs --------------------------------------------------------

@pytest.mark.parametrize("name", ["alpha_attention.yaml", "ssvep_speller.yaml",
                                  "motor_imagery.yaml"])
def test_shipped_configs_load_and_build_on_a_unicorn(name):
    cfg = Config.from_file(CONFIGS / name)
    cfg.validate_against_device(UNICORN)
    pipe = cfg.build_pipeline(UNICORN)
    assert pipe.describe()["extractor"] is not None


def test_alpha_config_also_builds_on_a_four_channel_muse():
    """The portability claim, exercised on a real config file."""
    cfg = Config.from_file(CONFIGS / "alpha_attention.yaml")
    report = cfg.validate_against_device(MUSE)
    assert report["alpha_posterior"]["fidelity"] < 1.0     # honest about the swap
    assert cfg.build_pipeline(MUSE) is not None


def test_ssvep_frequencies_are_not_harmonics_of_each_other():
    cfg = Config.from_file(CONFIGS / "ssvep_speller.yaml")
    freqs = cfg.get("pipeline.extractor.freqs")
    for a in freqs:
        for b in freqs:
            if a != b:
                assert abs(round(b / a) - b / a) > 0.02 or b / a < 1.5


# -- validation -------------------------------------------------------------

def test_rejects_inverted_filter_band():
    with pytest.raises(ConfigError, match="l_freq"):
        Config.from_dict(base_config(preprocess={"l_freq": 40.0, "h_freq": 10.0}))


def test_rejects_step_larger_than_window():
    with pytest.raises(ConfigError, match="step"):
        Config.from_dict(base_config(epoching={"window": 1.0, "step": 2.0,
                                               "history": 8.0}))


def test_rejects_wrong_mains_frequency():
    with pytest.raises(ConfigError, match="50 or 60"):
        Config.from_dict(base_config(session={"mains": 55.0}))


def test_rejects_unknown_stage_type_and_lists_alternatives():
    cfg = base_config()
    cfg["pipeline"]["extractor"] = {"type": "telepathy"}
    with pytest.raises(ConfigError, match="Available"):
        Config.from_dict(cfg)


def test_raw_streaming_requires_explicit_acknowledgement():
    with pytest.raises(ConfigError, match="explicitly"):
        Config.from_dict(base_config(session={"privacy_tier": "raw"}))


def test_rejects_h_freq_above_nyquist_for_the_connected_device():
    cfg = Config.from_dict(base_config(preprocess={"l_freq": 1.0, "h_freq": 90.0}))
    slow = DeviceInfo(name="slow", sfreq=128.0, ch_names=UNICORN.ch_names)
    with pytest.raises(ConfigError, match="Nyquist"):
        cfg.validate_against_device(slow)


def test_rejects_a_band_too_narrow_for_the_window():
    cfg = base_config(epoching={"window": 1.0, "step": 0.25, "history": 8.0})
    cfg["pipeline"]["extractor"] = {
        "type": "bandpower", "bands": {"narrow": [9.5, 10.5]},
        "channels": {"role": "alpha_posterior"},
    }
    with pytest.raises(ConfigError, match="resolution"):
        Config.from_dict(cfg).validate_against_device(UNICORN)


def test_rejects_a_role_the_device_cannot_serve():
    cfg = Config.from_dict(base_config())
    bare = DeviceInfo(name="bare", sfreq=250.0, ch_names=("EXG1", "EXG2"))
    with pytest.raises(ConfigError):
        cfg.validate_against_device(bare)


def test_explicit_channel_names_are_checked_against_the_device():
    cfg = Config.from_dict(base_config())
    with pytest.raises(KeyError):
        cfg.resolve_channels(["O1", "O2"], UNICORN)      # Unicorn has neither


# -- reproducibility --------------------------------------------------------

def test_config_hash_is_order_independent():
    a = {"x": 1, "y": {"b": 2, "a": 3}}
    b = {"y": {"a": 3, "b": 2}, "x": 1}
    assert config_hash(a) == config_hash(b)


def test_config_hash_changes_with_content():
    assert config_hash({"x": 1}) != config_hash({"x": 2})


def test_manifest_diff_ignores_incidental_fields_and_finds_real_ones():
    a = build_manifest("s1", "SCH-1", {"epoching": {"window": 1.0}}, {}, {})
    time.sleep(0.01)
    b = build_manifest("s2", "SCH-2", {"epoching": {"window": 2.0}}, {}, {})
    d = diff_manifests(a, b)
    assert any("window" in x for x in d)
    assert not any("session_id" in x for x in d)


# -- quality ----------------------------------------------------------------

def test_quality_flags_a_flat_channel():
    rng = np.random.default_rng(0)
    data = rng.normal(0, 10, (3, 1000))
    data[1] = 0.0
    q = QualityMonitor(mains=60.0)(data, 250.0, ("a", "b", "c"))
    assert q[1].flat and q[1].score == 0.0
    assert "connected" in q[1].advice()


def test_quality_flags_mains_interference():
    rng = np.random.default_rng(1)
    t = np.arange(1000) / 250.0
    clean = rng.normal(0, 10, 1000)
    noisy = clean + 60 * np.sin(2 * np.pi * 60 * t)
    q = QualityMonitor(mains=60.0)(np.vstack([clean, noisy]), 250.0, ("a", "b"))
    assert q[1].line_ratio > q[0].line_ratio
    assert q[1].score < q[0].score


def test_quality_flags_a_flat_spectrum_as_non_physiological():
    """White noise has slope ~0; real EEG has a 1/f background."""
    rng = np.random.default_rng(2)
    white = rng.normal(0, 15, 2000)
    pink = np.cumsum(rng.normal(0, 1, 2000))
    pink = 15 * pink / pink.std()
    q = QualityMonitor(mains=60.0)(np.vstack([pink, white]), 250.0, ("eeg", "junk"))
    assert q[0].spectral_slope < q[1].spectral_slope
    assert q[0].score > q[1].score


def test_quality_summary_lists_actionable_advice():
    data = np.zeros((2, 500))
    s = QualityMonitor()(data, 250.0, ("a", "b"))
    summary = QualityMonitor().summary(s)
    assert summary["n_usable"] == 0 and summary["advice"]


# -- recording round trip ---------------------------------------------------

def test_recording_round_trips_with_its_device_info(tmp=None):
    import tempfile
    src = SyntheticSource(realtime=False, seed=1)
    src.start()
    with tempfile.TemporaryDirectory() as d:
        rec = Recorder(src.device, Path(d) / "raw.npz")
        for _ in range(20):
            c = src.read()
            if c:
                rec.add(c)
        path = rec.close()
        data, dev, meta = load_recording(path)
    src.stop()
    assert dev.ch_names == src.device.ch_names
    assert dev.sfreq == src.device.sfreq
    assert data.shape[0] == 8 and data.shape[1] == meta["n_samples"]


def test_offline_epoching_matches_the_online_window_grid():
    rng = np.random.default_rng(3)
    data = rng.normal(0, 10, (8, 2500))
    X, y = epochs_from_recording(data, UNICORN, window=1.0, step=0.5)
    assert X.shape[1:] == (8, 250)
    assert X.shape[0] == (2500 - 250) // 125 + 1


def test_partially_overlapping_windows_are_discarded_not_mislabelled():
    rng = np.random.default_rng(4)
    data = rng.normal(0, 10, (8, 2500))
    X, y = epochs_from_recording(data, UNICORN, 1.0, 0.5,
                                 labels=[(0.0, 2.0, "a"), (5.0, 8.0, "b")])
    assert set(y) == {"a", "b"}
    assert len(X) < 19                       # ambiguous windows dropped


# -- end to end -------------------------------------------------------------

def test_full_session_produces_predictions_and_a_manifest():
    import json
    import tempfile

    with tempfile.TemporaryDirectory() as d:
        cfg = base_config(logging={"dir": d, "raw": False})
        got = []
        s = Session(cfg, source=SyntheticSource(realtime=True, seed=2),
                    on_prediction=lambda p, e: got.append(p))
        s.start(serve=False)
        time.sleep(4.0)
        s.stop()

        assert len(got) > 5, f"only {len(got)} windows in 4 s"
        assert all(0.0 <= p.value <= 1.0 for p in got)

        manifest = json.loads((Path(s.out_dir) / "manifest.json").read_text())
        assert manifest["config_sha256"]
        assert manifest["montage_resolution"]["alpha_posterior"]["exact"] is True
        assert manifest["latency_budget"]["structural_latency_ms"] > 0

        rep = s.report()
        assert rep["metrics"]["n_windows"] > 5
        assert rep["metrics"]["latency_ms_p50"] > 0


def test_session_measures_latency_within_the_structural_budget():
    import tempfile
    with tempfile.TemporaryDirectory() as d:
        s = Session(base_config(logging={"dir": d}),
                    source=SyntheticSource(realtime=True, seed=3))
        s.start(serve=False)
        time.sleep(4.0)
        s.stop()
        snap = s.metrics.snapshot()
        # Latency is measured from the window START, so it must exceed the
        # window length and stay close to it -- not vastly above.
        assert snap["latency_ms_p50"] >= 2000
        assert snap["latency_ms_p95"] < 2600
        assert snap["compute_ms_p95"] < 200


def test_synthetic_source_looks_like_eeg_not_like_a_broken_electrode():
    """The generator must survive the package's own quality check.

    A synthetic source that QualityMonitor flags as non-physiological is
    useless: every tutorial and CI run built on it would look broken.
    """
    from neurobridge.process.features import integrate_band, welch_psd
    from neurobridge.process.quality import QualityMonitor

    src = SyntheticSource(realtime=False, seed=4, blink_rate=0.0)
    src.start()
    data = np.hstack([c.data for c in (src.read() for _ in range(60)) if c])
    src.stop()

    q = QualityMonitor(mains=60.0)(data[:, :2000], 250.0, src.device.ch_names)
    assert all(ch.usable for ch in q), [(c.name, c.score, c.flags) for c in q]
    # Physiological amplitude and an aperiodic 1/f background, not white noise.
    assert 4.0 < data.std() < 40.0
    assert all(-3.0 < ch.spectral_slope < -0.5 for ch in q)

    f, p = welch_psd(data, 250.0, nperseg=1024)
    alpha = integrate_band(f, p, 8, 13)
    names = src.device.ch_names
    assert alpha[names.index("Oz")] > 2 * alpha[names.index("Fz")]


def test_synthetic_alpha_amplitude_is_controllable_at_runtime():
    """Faking eyes-open/eyes-closed is how a lesson is rehearsed without a headset."""
    from neurobridge.process.features import integrate_band, welch_psd

    def alpha_power(src, n=60):
        data = np.hstack([c.data for c in (src.read() for _ in range(n)) if c])
        f, p = welch_psd(data, 250.0, nperseg=512)
        return integrate_band(f, p, 8, 13)[src.device.ch_names.index("Oz")]

    src = SyntheticSource(realtime=False, seed=5, blink_rate=0.0, alpha_amp=2.0)
    src.start()
    alpha_power(src, 20)                      # discard the transition
    quiet = alpha_power(src)
    src.alpha_amp = 30.0
    alpha_power(src, 20)
    loud = alpha_power(src)
    src.stop()
    assert loud > 10 * quiet


def test_synthetic_blinks_are_caught_by_artifact_rejection():
    from neurobridge.process.filters import AmplitudeReject

    # Blinks are largest at the frontal pole, so use a montage that has one.
    src = SyntheticSource(realtime=False, seed=6, blink_rate=240.0,
                          ch_names=("Fp1", "Fp2", "C3", "C4", "P7", "P8",
                                    "O1", "O2"))
    src.start()
    data = np.hstack([c.data for c in (src.read() for _ in range(80)) if c])
    src.stop()

    reject = AmplitudeReject(ptp_uv=150.0)
    flagged = 0
    for start in range(0, data.shape[1] - 250, 250):
        ep = Epoch(data[:, start:start + 250].copy(), 0.0, 250.0,
                   src.device.ch_names)
        if reject(ep).meta["reject"]:
            flagged += 1
    assert flagged > 0, "blinks must be detectable as artifacts"
