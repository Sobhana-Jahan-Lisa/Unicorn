"""Feature math checked against analytic ground truth, not against itself."""

import numpy as np
import pytest

from neurobridge.core.types import Epoch
from neurobridge.process.features import (
    BandPower, FilterBankCCA, cca_correlation, covariance, integrate_band,
    reference_signals, welch_psd,
)

SF = 250.0


def make_epoch(data, ch_names=None, sfreq=SF):
    data = np.atleast_2d(data)
    names = ch_names or tuple(f"ch{i}" for i in range(data.shape[0]))
    return Epoch(data=data.astype(float), t_start=0.0, sfreq=sfreq,
                 ch_names=tuple(names))


def sine(freq, seconds=4.0, amp=10.0, sfreq=SF, phase=0.0):
    t = np.arange(int(seconds * sfreq)) / sfreq
    return amp * np.sin(2 * np.pi * freq * t + phase)


# -- Parseval / power normalisation ----------------------------------------

def test_psd_integral_equals_signal_variance():
    """Parseval: the integral of the one-sided PSD is the variance."""
    rng = np.random.default_rng(0)
    x = rng.normal(0, 7.0, int(8 * SF))
    freqs, psd = welch_psd(x[None, :], SF, nperseg=512)
    total = np.trapezoid(psd[0], freqs)
    assert total == pytest.approx(x.var(), rel=0.10)


def test_sine_band_power_equals_half_amplitude_squared():
    """A sine of amplitude A carries power A^2/2, all inside its band."""
    amp = 12.0
    x = sine(10.0, seconds=4.0, amp=amp)
    freqs, psd = welch_psd(x[None, :], SF)
    p = integrate_band(freqs, psd, 8.0, 13.0)[0]
    assert p == pytest.approx(amp**2 / 2, rel=0.05)


def test_power_is_absent_outside_the_signal_band():
    x = sine(10.0, seconds=4.0, amp=12.0)
    freqs, psd = welch_psd(x[None, :], SF)
    beta = integrate_band(freqs, psd, 13.0, 30.0)[0]
    alpha = integrate_band(freqs, psd, 8.0, 13.0)[0]
    assert beta < alpha / 1000


def test_relative_band_powers_sum_to_one():
    """Contiguous bands covering the whole range must partition the power."""
    rng = np.random.default_rng(1)
    x = rng.normal(0, 5, int(8 * SF))
    ep = make_epoch(np.vstack([x, x]))
    feats = BandPower(relative=True, total_band=(1.0, 45.0))(ep)
    assert sum(feats.values()) == pytest.approx(1.0, rel=0.02)


def test_relative_power_is_invariant_to_amplitude_scaling():
    """The property that makes relative power comparable across electrodes."""
    rng = np.random.default_rng(2)
    x = rng.normal(0, 5, int(8 * SF)) + sine(10.0, 8.0, 8.0)
    a = BandPower(relative=True)(make_epoch(np.vstack([x, x])))
    b = BandPower(relative=True)(make_epoch(np.vstack([x, x]) * 37.0))
    for k in a:
        assert a[k] == pytest.approx(b[k], rel=1e-8)


def test_narrow_band_on_short_window_raises_with_guidance():
    x = sine(10.0, seconds=0.5)
    freqs, psd = welch_psd(x[None, :], SF)
    with pytest.raises(ValueError, match="resolution"):
        integrate_band(freqs, psd, 9.5, 10.5)


def test_bandpower_per_channel_labels():
    ep = make_epoch(np.vstack([sine(10), sine(20)]), ch_names=("PO7", "Oz"))
    feats = BandPower(relative=True, aggregate="none")(ep)
    assert "alpha_PO7" in feats and "beta_Oz" in feats
    assert feats["alpha_PO7"] > feats["alpha_Oz"]


# -- CCA --------------------------------------------------------------------

def test_cca_of_identical_signals_is_one():
    rng = np.random.default_rng(3)
    X = rng.normal(0, 1, (3, 500))
    assert cca_correlation(X, X.copy()) == pytest.approx(1.0, abs=1e-8)


def test_cca_of_independent_noise_is_small():
    rng = np.random.default_rng(4)
    a = rng.normal(0, 1, (2, 2000))
    b = rng.normal(0, 1, (2, 2000))
    assert cca_correlation(a, b) < 0.2


def test_cca_matches_the_stimulation_frequency():
    n = int(4 * SF)
    x = sine(12.0, 4.0)[None, :]
    on = cca_correlation(x, reference_signals(12.0, n, SF, 3))
    off = cca_correlation(x, reference_signals(17.0, n, SF, 3))
    assert on > 0.95 and off < 0.3


def test_reference_harmonics_stop_below_nyquist():
    """A 40 Hz stimulus at 100 Hz sampling has no usable second harmonic."""
    Y = reference_signals(40.0, 200, 100.0, n_harmonics=4)
    assert Y.shape[0] == 2                       # fundamental only


def test_reference_raises_when_fundamental_above_nyquist():
    with pytest.raises(ValueError):
        reference_signals(60.0, 100, 100.0)


def test_fbcca_identifies_the_attended_frequency():
    """Simulated SSVEP: attended flicker + harmonic buried in pink-ish noise."""
    rng = np.random.default_rng(5)
    target, distractors = 10.0, [8.0, 12.0, 15.0]
    n = int(4 * SF)
    t = np.arange(n) / SF
    signal_ = 3.0 * np.sin(2 * np.pi * target * t) + 1.2 * np.sin(
        2 * np.pi * 2 * target * t)
    noise = np.cumsum(rng.normal(0, 1, (3, n)), axis=1)
    noise = 8.0 * noise / noise.std()
    data = noise + signal_[None, :]

    ep = make_epoch(data, ch_names=("PO7", "Oz", "PO8"))
    scores = FilterBankCCA(freqs=[target] + distractors)(ep)
    best = max(scores, key=scores.get)
    assert best == f"rho_{target:g}"


def test_fbcca_rejects_a_window_too_short_for_the_frequency():
    ep = make_epoch(np.vstack([sine(8.0, 0.15)] * 2))
    with pytest.raises(ValueError, match="cycles"):
        FilterBankCCA(freqs=[8.0])(ep)


# -- covariance -------------------------------------------------------------

def test_covariance_is_symmetric_positive_definite():
    rng = np.random.default_rng(6)
    C = covariance(rng.normal(0, 1, (8, 250)))
    assert np.allclose(C, C.T)
    assert np.linalg.eigvalsh(C).min() > 0


def test_shrinkage_conditions_an_underdetermined_covariance():
    """8 channels, 20 samples: the sample covariance is singular, shrinkage is not."""
    rng = np.random.default_rng(7)
    X = rng.normal(0, 1, (8, 20))
    emp = covariance(X, "empirical")
    lw = covariance(X, "ledoit_wolf")
    assert np.linalg.cond(lw) < np.linalg.cond(emp)
