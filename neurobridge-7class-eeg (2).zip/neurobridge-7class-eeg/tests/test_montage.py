"""Role resolution across different headsets -- the portability claim."""

import pytest

from neurobridge.core.montage import Montage, distance, parse_label

UNICORN = ("Fz", "C3", "Cz", "C4", "Pz", "PO7", "Oz", "PO8")
MUSE = ("TP9", "AF7", "AF8", "TP10")
OPENBCI8 = ("Fp1", "Fp2", "C3", "C4", "P7", "P8", "O1", "O2")
BIOSEMI32 = ("Fp1", "AF3", "F7", "F3", "FC1", "FC5", "T7", "C3", "CP1", "CP5",
             "P7", "P3", "Pz", "PO3", "O1", "Oz", "O2", "PO4", "P4", "P8",
             "CP6", "CP2", "C4", "T8", "FC6", "FC2", "F4", "F8", "AF4", "Fp2",
             "Fz", "Cz")


def test_label_geometry_is_sane():
    assert parse_label("C3")[1] < 0 < parse_label("C4")[1]
    assert parse_label("Fz")[2] > parse_label("Oz")[2]
    assert parse_label("Cz")[1] == 0.0
    assert distance("C3", "C3") == 0.0
    assert distance("O1", "O2") < distance("O1", "Fp2")


def test_unicorn_resolves_ssvep_without_o1():
    """Unicorn has PO7/Oz/PO8 but no O1/O2, and must still resolve exactly."""
    match = Montage(UNICORN).resolve("ssvep")
    assert match.ok and match.exact
    assert "Oz" in match.names


def test_muse_substitutes_and_admits_it():
    """Muse has no occipital electrode; the fallback must be flagged, not hidden."""
    match = Montage(MUSE).resolve("ssvep")
    assert not match.exact
    assert match.fidelity < 1.0
    assert match.note


def test_motor_roles_are_lateralised():
    m = Montage(BIOSEMI32)
    assert m.resolve("motor_left").names[0] == "C3"
    assert m.resolve("motor_right").names[0] == "C4"


@pytest.mark.parametrize("chs", [UNICORN, MUSE, OPENBCI8, BIOSEMI32])
def test_one_role_works_on_every_headset(chs):
    assert Montage(chs).resolve("alpha_posterior").ok


def test_report_covers_all_roles():
    rep = Montage(OPENBCI8).report()
    assert set(rep) and all("fidelity" in v for v in rep.values())


def test_unknown_role_raises():
    with pytest.raises(KeyError):
        Montage(UNICORN).resolve("telepathy")
