"""Education layer: control convergence, Rasch tracing, curriculum, screening."""

import math

import numpy as np
import pytest

from neurobridge.classify.calibration import (
    Calibrator, cohens_d, permutation_test, wilson_interval,
)
from neurobridge.core.types import Epoch
from neurobridge.education.adaptive import (
    DifficultyController, EngagementModulator, KnowledgeTracer, sigmoid,
)
from neurobridge.education.events import EventLog, PrivacyViolation
from neurobridge.education.lessons import (
    CURRICULUM, Concept, Curriculum, calibrate_difficulties,
)


# -- difficulty control -----------------------------------------------------

def simulated_student(difficulty: float, ability: float, rng) -> bool:
    """Success probability falls as difficulty rises: P = sigmoid(k*(a - d))."""
    return rng.random() < sigmoid(6.0 * (ability - difficulty))


def test_difficulty_controller_converges_to_the_target_rate():
    rng = np.random.default_rng(0)
    ctrl = DifficultyController(target=0.75, d0=0.1)
    for _ in range(600):
        ctrl.update(simulated_student(ctrl.d, ability=0.5, rng=rng))
    recent = [h[2] for h in ctrl.history[-300:]]
    assert 0.68 < np.mean(recent) < 0.82, np.mean(recent)


def test_difficulty_tracks_a_student_who_improves():
    """The step-size floor is what allows this; without it the controller freezes."""
    rng = np.random.default_rng(1)
    ctrl = DifficultyController(target=0.75, d0=0.3)
    for _ in range(300):
        ctrl.update(simulated_student(ctrl.d, 0.3, rng))
    easy_phase = ctrl.d
    for _ in range(300):
        ctrl.update(simulated_student(ctrl.d, 0.9, rng))   # student got better
    assert ctrl.d > easy_phase + 0.1


def test_difficulty_stays_inside_bounds():
    ctrl = DifficultyController(target=0.75, d0=0.5)
    for _ in range(500):
        ctrl.update(True)
    assert ctrl.d <= 1.0
    for _ in range(500):
        ctrl.update(False)
    assert ctrl.d >= 0.0


def test_difficulty_rejects_invalid_hyperparameters():
    with pytest.raises(ValueError, match="target"):
        DifficultyController(target=1.5)
    with pytest.raises(ValueError, match="gamma"):
        DifficultyController(gamma=0.3)


# -- knowledge tracing ------------------------------------------------------

def test_sigmoid_is_stable_at_extremes():
    assert sigmoid(-1000) == pytest.approx(0.0, abs=1e-12)
    assert sigmoid(1000) == pytest.approx(1.0, abs=1e-12)
    assert sigmoid(0.0) == 0.5


def test_rasch_ability_rises_with_correct_answers():
    kt = KnowledgeTracer(eta=0.4)
    before = kt.state("rhythms").theta
    for _ in range(10):
        kt.update("rhythms", True)
    assert kt.state("rhythms").theta > before
    assert kt.state("rhythms").mastery > 0.7


def test_rasch_update_is_the_likelihood_gradient():
    """theta <- theta + eta*(y - P) must match a hand computation exactly."""
    kt = KnowledgeTracer(eta=0.5, prior_theta=0.0)
    kt.update("c", correct=True, item_difficulty=0.0)
    assert kt.state("c").theta == pytest.approx(0.5 * (1 - 0.5))


def test_a_harder_item_moves_ability_more_when_answered_correctly():
    a = KnowledgeTracer(eta=0.4)
    b = KnowledgeTracer(eta=0.4)
    a.update("c", True, item_difficulty=-2.0)      # easy item, little evidence
    b.update("c", True, item_difficulty=2.0)       # hard item, strong evidence
    assert b.state("c").theta > a.state("c").theta


def test_an_easy_item_answered_correctly_is_weak_evidence():
    """Rasch behaviour: getting an easy item right barely moves the estimate."""
    kt = KnowledgeTracer(eta=3.0)
    kt.update("c", True, item_difficulty=-3.0)
    assert kt.state("c").mastery < 0.65


def test_mastery_requires_evidence_not_just_one_lucky_answer():
    kt = KnowledgeTracer(eta=5.0)
    kt.update("c", True, item_difficulty=2.0)      # hard item, big update
    assert kt.state("c").mastery > 0.8
    assert not kt.mastered("c", threshold=0.8, min_attempts=3)


# -- engagement modulator ---------------------------------------------------

def test_modulator_refuses_to_interpret_a_bad_signal():
    m = EngagementModulator()
    out = m.update(0.5, quality=0.2)
    assert out["state"] == "unknown" and out["action"] == "none"


def test_modulator_builds_a_baseline_before_acting():
    m = EngagementModulator(min_samples=20)
    for _ in range(10):
        out = m.update(1.0, quality=1.0)
    assert out["state"] == "calibrating"


def test_modulator_flags_a_sustained_drop():
    rng = np.random.default_rng(2)
    m = EngagementModulator(min_samples=20, dwell=5)
    for _ in range(60):
        m.update(float(rng.normal(1.0, 0.1)), 1.0)
    out = {}
    for _ in range(20):
        out = m.update(0.2, 1.0)                    # far below baseline
    assert out["state"] == "low"
    assert out["action"] == "prompt_break"


# -- curriculum -------------------------------------------------------------

def test_default_curriculum_is_acyclic_and_complete():
    c = Curriculum()
    order = c.order()
    assert len(order) == len(c.concepts)
    seen = set()
    for cid in order:
        for p in c.concepts[cid].prerequisites:
            assert p in seen, f"{cid} appears before its prerequisite {p}"
        seen.add(cid)


def test_every_concept_has_items_with_a_valid_answer():
    for c in CURRICULUM.values():
        assert c.items, f"{c.concept_id} has no assessment items"
        for it in c.items:
            assert 0 <= it.answer < len(it.options)
            assert it.explanation


def test_cyclic_curriculum_is_rejected():
    bad = {
        "a": Concept("a", "A", "6-8", "", ("b",)),
        "b": Concept("b", "B", "6-8", "", ("a",)),
    }
    with pytest.raises(ValueError, match="cycle"):
        Curriculum(bad)


def test_dangling_prerequisite_is_rejected():
    bad = {"a": Concept("a", "A", "6-8", "", ("ghost",))}
    with pytest.raises(ValueError, match="not"):
        Curriculum(bad)


def test_next_concept_respects_prerequisites():
    c = Curriculum()
    kt = KnowledgeTracer()
    first = c.next_concept(kt)
    assert c.concepts[first].prerequisites == ()


def test_next_item_targets_the_requested_success_probability():
    c = Curriculum()
    kt = KnowledgeTracer()
    easy = c.next_item("rhythms", kt, difficulty=0.9)
    hard = c.next_item("rhythms", kt, difficulty=0.3)
    assert easy.difficulty <= hard.difficulty


def test_difficulty_recalibration_is_anchored():
    """The Rasch model is identified only up to a shift; the mean must stay at 0."""
    responses = [("i1", True)] * 30 + [("i2", False)] * 30
    b = calibrate_difficulties(responses)
    assert sum(b.values()) == pytest.approx(0.0, abs=1e-6)
    assert b["i2"] > b["i1"]                        # the missed item is harder


# -- calibration statistics -------------------------------------------------

def test_wilson_interval_known_values():
    lo, hi = wilson_interval(8, 10)
    assert 0.49 < lo < 0.51 and 0.93 < hi < 0.95


def test_wilson_interval_stays_in_range_at_the_boundary():
    lo, hi = wilson_interval(10, 10)
    assert 0.0 <= lo <= 1.0 and hi <= 1.0
    lo, hi = wilson_interval(0, 5)
    assert lo == 0.0 and hi < 1.0


def test_cohens_d_matches_a_hand_computation():
    a = np.array([1.0, 2.0, 3.0])
    b = np.array([4.0, 5.0, 6.0])
    # Both have variance 1, so pooled sd = 1 and d = -3.
    assert cohens_d(a, b) == pytest.approx(-3.0)


def test_permutation_test_finds_no_effect_in_noise():
    rng = np.random.default_rng(3)
    from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
    X = rng.normal(0, 1, (40, 4))
    y = np.array([0, 1] * 20)
    _, p, _ = permutation_test(LinearDiscriminantAnalysis(), X, y, n_perm=100)
    assert p > 0.05


def test_permutation_p_value_is_never_zero():
    """The (1 + count)/(1 + n) estimator: p = 0 is never a defensible claim."""
    rng = np.random.default_rng(4)
    from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
    X = np.vstack([rng.normal(-5, 0.1, (20, 3)), rng.normal(5, 0.1, (20, 3))])
    y = np.array([0] * 20 + [1] * 20)
    _, p, _ = permutation_test(LinearDiscriminantAnalysis(), X, y, n_perm=50)
    assert p > 0.0


def _epoch(vals):
    return Epoch(np.asarray(vals, float), 0.0, 250.0, ("a", "b"))


def test_calibrator_reports_good_for_separable_data():
    rng = np.random.default_rng(5)
    cal = Calibrator("alpha", featurizer=lambda ep: {"alpha": float(ep.data[0, 0])})
    for i in range(40):
        label = "rest_open" if i % 2 else "rest_closed"
        value = 1.0 if label == "rest_closed" else 5.0
        cal.add(_epoch([[value + rng.normal(0, 0.2)] * 4] * 2), label)
    res = cal.fit(n_perm=100)
    assert res.status == "good"
    assert res.accuracy > 0.9 and res.p_value < 0.05
    assert abs(res.effect_size) > 2.0
    assert "brain signals" in res.message()


def test_calibrator_falls_back_on_unseparable_data():
    rng = np.random.default_rng(6)
    cal = Calibrator("alpha", featurizer=lambda ep: {"alpha": float(ep.data[0, 0])})
    for i in range(40):
        label = "rest_open" if i % 2 else "rest_closed"
        cal.add(_epoch([[float(rng.normal(0, 1))] * 4] * 2), label)
    res = cal.fit(n_perm=100)
    assert res.status == "fallback"
    assert "practice mode" in res.message()
    assert res.notes


def test_calibration_result_never_uses_stigmatising_language():
    rng = np.random.default_rng(7)
    cal = Calibrator("alpha", featurizer=lambda ep: {"a": float(ep.data[0, 0])})
    for i in range(30):
        cal.add(_epoch([[float(rng.normal(0, 1))] * 4] * 2),
                "rest_open" if i % 2 else "rest_closed")
    msg = cal.fit(n_perm=50).message().lower()
    assert "illiterate" not in msg and "fail" not in msg


# -- event log --------------------------------------------------------------

def test_event_log_round_trips(tmp_path=None):
    import tempfile
    from pathlib import Path
    with tempfile.TemporaryDirectory() as d:
        path = Path(d) / "events.jsonl"
        log = EventLog(path, "SCH-0142")
        log.log("session_start", {"device": "synthetic"})
        log.response("rhythms", "rhythms-1", True, 1234.0, answer=0,
                     neuro={"alpha": 0.3})
        log.close()
        events = list(EventLog.read(path))
        assert len(events) == 2
        assert events[1].payload["correct"] is True
        assert events[1].neuro["alpha"] == 0.3
        assert events[1].t >= events[0].t


def test_event_log_rejects_a_real_name_as_participant():
    import tempfile
    from pathlib import Path
    with tempfile.TemporaryDirectory() as d:
        with pytest.raises(PrivacyViolation):
            EventLog(Path(d) / "e.jsonl", "Ayesha Khan")


def test_event_log_rejects_identifying_payload_keys():
    import tempfile
    from pathlib import Path
    with tempfile.TemporaryDirectory() as d:
        log = EventLog(Path(d) / "e.jsonl", "SCH-0001")
        with pytest.raises(PrivacyViolation, match="identifying"):
            log.log("note", {"student": {"name": "Sam"}})
        log.close()


def test_event_log_survives_a_truncated_final_line():
    import tempfile
    from pathlib import Path
    with tempfile.TemporaryDirectory() as d:
        path = Path(d) / "e.jsonl"
        log = EventLog(path, "SCH-0001")
        log.log("note", {"a": 1})
        log.close()
        with path.open("a") as fh:
            fh.write('{"kind": "note", "t": 1.0, "wa')     # simulated crash
        assert len(list(EventLog.read(path))) == 1


def test_calibrator_excludes_a_feature_that_is_undefined_until_calibration():
    """Regression: a single NaN column used to discard every epoch."""
    rng = np.random.default_rng(8)

    def featurizer(ep):
        return {"alpha": float(ep.data[0, 0]),
                "alpha_suppression": float("nan")}   # needs a baseline we lack

    cal = Calibrator("alpha", featurizer=featurizer)
    for i in range(40):
        label = "rest_open" if i % 2 else "rest_closed"
        value = 1.0 if label == "rest_closed" else 5.0
        cal.add(_epoch([[value + rng.normal(0, 0.2)] * 4] * 2), label)
    res = cal.fit(n_perm=100)
    assert res.n_trials == 40, "the usable feature must survive the NaN column"
    assert res.features == ["alpha"]
    assert any("alpha_suppression" in n for n in res.notes)


def test_calibrator_reports_why_it_has_no_data():
    cal = Calibrator("alpha", featurizer=lambda ep: {"a": float(ep.data[0, 0])})
    with pytest.raises(RuntimeError, match="set_calibration_label"):
        cal.fit()
