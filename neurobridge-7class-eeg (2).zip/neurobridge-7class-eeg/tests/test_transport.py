"""Transport: real handshake, real frames, real backpressure."""

import base64
import hashlib
import json
import os
import socket
import struct
import threading
import time

import pytest

from neurobridge.transport.metrics import LatencyBudget, Metrics
from neurobridge.transport.protocol import (
    Hello, Neuro, ProtocolError, parse_upstream,
)
from neurobridge.transport.websocket import Frame, WebSocketServer

GUID = "258EAFA5-E914-47DA-95CA-5AB0DC85B11C"


class MiniClient:
    """A stdlib WebSocket client, so the test exercises the wire, not a mock."""

    def __init__(self, host: str, port: int) -> None:
        self.sock = socket.create_connection((host, port), timeout=5)
        key = base64.b64encode(os.urandom(16)).decode()
        self.sock.sendall(
            f"GET / HTTP/1.1\r\nHost: {host}:{port}\r\nUpgrade: websocket\r\n"
            f"Connection: Upgrade\r\nSec-WebSocket-Key: {key}\r\n"
            f"Sec-WebSocket-Version: 13\r\n\r\n".encode()
        )
        resp = b""
        # One byte at a time: a bulk recv can pull in the start of the first
        # WebSocket frame with the HTTP response, and dropping that buffer
        # silently loses the server's opening message.
        while not resp.endswith(b"\r\n\r\n"):
            part = self.sock.recv(1)
            if not part:
                break
            resp += part
        assert b"101" in resp.split(b"\r\n")[0]
        expected = base64.b64encode(
            hashlib.sha1((key + GUID).encode()).digest()).decode()
        assert expected.encode() in resp, "server computed the wrong accept key"

    def send(self, text: str) -> None:
        payload = text.encode()
        mask = os.urandom(4)
        masked = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        n = len(payload)
        head = bytearray([0x81])
        if n < 126:
            head.append(0x80 | n)
        elif n < (1 << 16):
            head.append(0x80 | 126)
            head += struct.pack("!H", n)
        else:
            head.append(0x80 | 127)
            head += struct.pack("!Q", n)
        self.sock.sendall(bytes(head) + mask + masked)

    def recv(self, timeout: float = 3.0) -> dict:
        self.sock.settimeout(timeout)
        opcode, payload = Frame.read(self.sock)
        assert opcode == 0x1
        return json.loads(payload.decode())

    def close(self) -> None:
        try:
            self.sock.close()
        except OSError:
            pass


def wait_for_clients(srv, n=1, timeout=3.0):
    """Wait for the server to register a connection before broadcasting."""
    end = time.time() + timeout
    while time.time() < end:
        if srv.n_clients >= n:
            return True
        time.sleep(0.01)
    raise AssertionError(f"only {srv.n_clients} clients after {timeout}s")


def free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


# -- framing ----------------------------------------------------------------

def test_frame_lengths_use_the_right_encoding():
    assert Frame.encode(b"x")[1] == 1
    assert Frame.encode(b"y" * 300)[1] == 126
    assert Frame.encode(b"z" * 70000)[1] == 127


def test_server_frames_are_unmasked():
    """RFC 6455: a server must not mask frames it sends."""
    assert Frame.encode(b"hello")[1] & 0x80 == 0


# -- end to end -------------------------------------------------------------

def test_handshake_and_broadcast_round_trip():
    port = free_port()
    got = []
    srv = WebSocketServer(port=port, on_message=lambda c, m: got.append(m))
    srv.start()
    try:
        c = MiniClient("127.0.0.1", port)
        wait_for_clients(srv)
        assert srv.n_clients == 1

        srv.broadcast(Hello(device="synthetic", sfreq=250.0,
                            channels=["Oz", "PO7"]))
        msg = c.recv()
        assert msg["type"] == "hello" and msg["sfreq"] == 250.0
        assert msg["v"] == "1.0"

        c.send(json.dumps({"type": "control", "action": "stop"}))
        time.sleep(0.3)
        assert got and got[0]["action"] == "stop"
        c.close()
    finally:
        srv.stop()


def test_invalid_upstream_gets_an_error_not_a_crash():
    port = free_port()
    srv = WebSocketServer(port=port, on_message=lambda c, m: None)
    srv.start()
    try:
        c = MiniClient("127.0.0.1", port)
        wait_for_clients(srv)
        c.send(json.dumps({"type": "control", "action": "launch_missiles"}))
        err = c.recv()
        assert err["type"] == "error" and "action" in err["detail"]
        # The connection must survive a bad message.
        srv.broadcast(Neuro(value=1.0))
        assert c.recv()["type"] == "neuro"
        c.close()
    finally:
        srv.stop()


def test_backpressure_drops_neuro_and_keeps_the_connection():
    """A stalled client must lose stale windows, not accumulate a backlog."""
    port = free_port()
    srv = WebSocketServer(port=port, queue_size=4)
    srv.start()
    try:
        c = MiniClient("127.0.0.1", port)
        wait_for_clients(srv)
        client = srv.clients[0]
        client.alive = True
        # Fill the queue behind the writer's back.
        for i in range(200):
            client.queue.put_nowait(("neuro", "{}")) if not client.queue.full() \
                else client.send(json.dumps({"type": "neuro", "value": i}), "neuro")
        assert client.dropped > 0
        assert client.alive, "dropping neuro messages must not close the socket"
        c.close()
    finally:
        srv.stop()


def test_large_message_survives_extended_length_framing():
    port = free_port()
    srv = WebSocketServer(port=port)
    srv.start()
    try:
        c = MiniClient("127.0.0.1", port)
        wait_for_clients(srv)
        big = {"type": "neuro", "value": 1.0,
               "features": {f"f{i}": i * 0.001 for i in range(4000)}}
        srv.broadcast(big)
        got = c.recv(timeout=5)
        assert len(got["features"]) == 4000
        c.close()
    finally:
        srv.stop()


# -- protocol validation ----------------------------------------------------

def test_parse_upstream_accepts_valid_messages():
    m = parse_upstream(json.dumps({"type": "learning",
                                   "event": {"kind": "response"}}))
    assert m["type"] == "learning"


@pytest.mark.parametrize("payload", [
    "not json",
    '["a list"]',
    '{"type": "unknown_kind"}',
    '{"type": "control"}',
    '{"type": "learning", "event": {}}',
    '{"type": "game"}',
])
def test_parse_upstream_rejects_bad_messages(payload):
    with pytest.raises(ProtocolError):
        parse_upstream(payload)


def test_protocol_major_version_mismatch_is_rejected():
    with pytest.raises(ProtocolError, match="version"):
        parse_upstream(json.dumps({"type": "ready", "v": "2.0"}))


def test_message_serialises_numpy_scalars():
    import numpy as np
    msg = Neuro(value=np.float64(0.5), features={"a": np.float32(1.5)})
    assert json.loads(msg.to_json())["value"] == 0.5


# -- metrics ----------------------------------------------------------------

def test_latency_is_measured_from_the_window_start():
    m = Metrics()
    m.record_epoch(t_epoch=10.0, t_emit=10.25)
    assert m.snapshot()["latency_ms_p50"] == pytest.approx(250.0, abs=1e-6)


def test_percentiles_expose_a_tail_a_mean_would_hide():
    m = Metrics()
    for _ in range(90):
        m.record_epoch(0.0, 0.05)
    for _ in range(10):
        m.record_epoch(0.0, 0.9)
    s = m.snapshot()
    assert s["latency_ms_p50"] == pytest.approx(50.0, abs=1e-6)
    assert s["latency_ms_p95"] > 500.0
    # A mean of 135 ms would describe this as a comfortable system.
    assert s["latency_ms_max"] == pytest.approx(900.0, abs=1e-6)


def test_jitter_is_zero_for_a_perfectly_regular_stream():
    m = Metrics()
    for i in range(50):
        m.record_arrival(t_sent=i * 0.25, t_received=100 + i * 0.25)
    assert m.jitter_ms == pytest.approx(0.0, abs=1e-6)


def test_jitter_grows_with_irregular_arrival():
    m = Metrics()
    rng = __import__("random").Random(0)
    for i in range(200):
        m.record_arrival(i * 0.25, 100 + i * 0.25 + rng.uniform(0, 0.05))
    assert m.jitter_ms > 1.0


def test_loss_rate_from_sequence_gaps():
    m = Metrics()
    for seq in [0, 1, 2, 5, 6]:
        m.record_sequence(seq)
    assert m.loss_rate == pytest.approx(2 / 7, rel=1e-6)


def test_latency_budget_reports_structural_delay():
    b = LatencyBudget(window=1.0, filter_group_delay=0.02, step=0.25)
    # window midpoint (500 ms) + group delay (20 ms) + half a step (125 ms)
    assert b.structural_ms == pytest.approx(645.0, abs=1e-6)


def test_state_message_survives_a_backlog_of_droppable_traffic():
    """Regression: a client that briefly stops reading must not be disconnected.

    A backgrounded tab or a full socket buffer lets neuro/quality messages pile
    up. A calibration or lesson message arriving at that moment used to close
    the connection -- punishing the client for exactly the traffic the transport
    already promised to shed.
    """
    port = free_port()
    srv = WebSocketServer(port=port, queue_size=8)
    srv.start()
    try:
        c = MiniClient("127.0.0.1", port)
        wait_for_clients(srv)
        client = srv.clients[0]

        # Fill the queue with droppable traffic, bypassing the writer.
        while not client.queue.full():
            client.queue.put_nowait(("neuro", '{"type":"neuro"}'))

        assert client.send('{"type":"calibration"}', "calibration") is True
        assert client.alive, "a state message must not close a healthy client"
        assert any(m[0] == "calibration" for m in list(client.queue.queue))
        c.close()
    finally:
        srv.stop()


def test_client_is_closed_when_it_cannot_keep_up_with_state_messages():
    """The genuine failure case is still handled: no droppable entry to evict."""
    port = free_port()
    srv = WebSocketServer(port=port, queue_size=4)
    srv.start()
    try:
        c = MiniClient("127.0.0.1", port)
        wait_for_clients(srv)
        client = srv.clients[0]

        while not client.queue.full():
            client.queue.put_nowait(("lesson", '{"type":"lesson"}'))

        assert client.send('{"type":"calibration"}', "calibration") is False
        assert not client.alive
        c.close()
    finally:
        srv.stop()


def test_first_message_is_not_lost_in_the_handshake_buffer():
    """A client must receive a message broadcast the instant it connects.

    Regression: reading the HTTP handshake with a bulk recv() can pull the
    start of the first WebSocket frame into the same buffer. Discarding that
    buffer loses the message and looks exactly like a server that never sent
    one.
    """
    port = free_port()
    srv = WebSocketServer(
        port=port,
        on_connect=lambda c: c.send(Hello(device="synthetic", sfreq=250.0,
                                          channels=["Oz"]).to_json(), "hello"),
    )
    srv.start()
    try:
        c = MiniClient("127.0.0.1", port)
        first = c.recv(timeout=3)
        assert first["type"] == "hello"
        assert first["device"] == "synthetic"
        c.close()
    finally:
        srv.stop()
