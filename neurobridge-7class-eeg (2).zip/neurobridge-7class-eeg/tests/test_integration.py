"""The loop a browser actually drives: connect, calibrate, answer, adapt."""

import json
import socket
import tempfile
import time
from pathlib import Path

from neurobridge import Session, SyntheticSource
from test_transport import MiniClient, free_port, wait_for_clients


def config(port: int, log_dir: str) -> dict:
    return {
        "session": {"paradigm": "alpha", "participant": "SCH-0007",
                    "mains": 60.0, "privacy_tier": "features"},
        "acquisition": {"source": {"type": "synthetic"}},
        "preprocess": {"l_freq": 1.0, "h_freq": 45.0, "notch": 60.0},
        "epoching": {"window": 1.0, "step": 0.25, "history": 6.0},
        "pipeline": {
            "transforms": [{"type": "detrend", "mode": "constant"},
                           {"type": "reject", "ptp_uv": 400.0}],
            "extractor": {"type": "attention",
                          "channels": {"role": "alpha_posterior"}},
            "decoder": {"type": "proportional", "feature": "alpha",
                        "x_lo": 0.0, "x_hi": 1.0},
        },
        "transport": {"host": "127.0.0.1", "port": port, "queue_size": 32},
        "education": {"grade_band": "6-8", "target_success": 0.75},
        "logging": {"dir": log_dir, "raw": False},
    }


def drain(client, want, timeout=8.0):
    """Collect messages until one of type ``want`` arrives."""
    end = time.time() + timeout
    seen = []
    while time.time() < end:
        try:
            msg = client.recv(timeout=max(0.1, end - time.time()))
        except (socket.timeout, OSError, TypeError):
            continue
        seen.append(msg)
        if msg.get("type") == want:
            return msg, seen
    raise AssertionError(f"no {want!r} message; saw {[m.get('type') for m in seen]}")


def test_browser_receives_hello_with_the_resolved_montage():
    port = free_port()
    with tempfile.TemporaryDirectory() as d:
        s = Session(config(port, d), source=SyntheticSource(seed=1))
        s.start()
        try:
            c = MiniClient("127.0.0.1", port)
            wait_for_clients(s.server)
            hello, _ = drain(c, "hello")
            assert hello["v"] == "1.0"
            assert hello["sfreq"] == 250.0
            assert hello["privacy_tier"] == "features"
            assert hello["montage"]["alpha_posterior"]["exact"] is True
            assert hello["session_id"] == s.session_id
            c.close()
        finally:
            s.stop()


def test_neuro_messages_carry_measured_latency():
    port = free_port()
    with tempfile.TemporaryDirectory() as d:
        s = Session(config(port, d), source=SyntheticSource(seed=2))
        s.start()
        try:
            c = MiniClient("127.0.0.1", port)
            wait_for_clients(s.server)
            neuro, _ = drain(c, "neuro")
            assert 0.0 <= neuro["value"] <= 1.0
            assert neuro["latency_ms"] >= 1000.0     # a 1 s window cannot be faster
            assert neuro["features"]                 # 'features' tier sends them
            assert 0.0 <= neuro["quality"] <= 1.0
            c.close()
        finally:
            s.stop()


def test_derived_tier_withholds_features_from_the_network():
    port = free_port()
    with tempfile.TemporaryDirectory() as d:
        cfg = config(port, d)
        cfg["session"]["privacy_tier"] = "derived"
        s = Session(cfg, source=SyntheticSource(seed=3))
        s.start()
        try:
            c = MiniClient("127.0.0.1", port)
            wait_for_clients(s.server)
            neuro, _ = drain(c, "neuro")
            assert neuro["features"] == {}
            assert neuro["value"] is not None        # the control signal still flows
            c.close()
        finally:
            s.stop()


def test_browser_cannot_switch_the_server_into_raw_mode():
    """A student with the console open must not be able to unlock raw EEG."""
    port = free_port()
    with tempfile.TemporaryDirectory() as d:
        s = Session(config(port, d), source=SyntheticSource(seed=4))
        s.start()
        try:
            c = MiniClient("127.0.0.1", port)
            wait_for_clients(s.server)
            c.send(json.dumps({"type": "control", "action": "set_privacy",
                               "tier": "raw"}))
            time.sleep(0.5)
            assert s.config.get("session.privacy_tier") != "raw"
            c.close()
        finally:
            s.stop()


def test_ready_triggers_the_first_lesson_with_a_sized_item():
    port = free_port()
    with tempfile.TemporaryDirectory() as d:
        s = Session(config(port, d), source=SyntheticSource(seed=5))
        s.start()
        try:
            c = MiniClient("127.0.0.1", port)
            wait_for_clients(s.server)
            c.send(json.dumps({"type": "ready"}))
            lesson, _ = drain(c, "lesson")
            assert lesson["prompt"]["options"]
            assert lesson["concept_id"] in s.curriculum.concepts
            # The first concept must have no prerequisites.
            assert s.curriculum.concepts[lesson["concept_id"]].prerequisites == ()
            c.close()
        finally:
            s.stop()


def test_calibration_script_is_sent_and_can_be_driven_from_the_browser():
    port = free_port()
    with tempfile.TemporaryDirectory() as d:
        s = Session(config(port, d), source=SyntheticSource(seed=6))
        s.start()
        try:
            c = MiniClient("127.0.0.1", port)
            wait_for_clients(s.server)
            c.send(json.dumps({"type": "control", "action": "calibrate"}))
            cal, _ = drain(c, "calibration")
            assert cal["phase"] == "running"
            assert len(cal["blocks"]) >= 2
            assert all("instruction" in b for b in cal["blocks"])

            # Drive two labelled blocks the way the browser does.
            for label in ("rest_open", "rest_closed", "rest_open", "rest_closed"):
                c.send(json.dumps({"type": "control",
                                   "action": "calibration_block", "label": label}))
                time.sleep(1.2)
            c.send(json.dumps({"type": "control", "action": "calibration_finish"}))

            done, _ = drain(c, "calibration", timeout=15)
            while done.get("phase") != "done":
                done, _ = drain(c, "calibration", timeout=15)
            assert done["result"]["status"] in ("good", "marginal", "fallback")
            assert done["message"]
            c.close()
        finally:
            s.stop()


def test_a_wrong_answer_moves_difficulty_and_is_logged_with_neural_context():
    port = free_port()
    with tempfile.TemporaryDirectory() as d:
        s = Session(config(port, d), source=SyntheticSource(seed=7))
        s.start()
        try:
            c = MiniClient("127.0.0.1", port)
            wait_for_clients(s.server)
            time.sleep(1.5)                      # let some windows accumulate
            before = s.difficulty.d

            for i in range(6):
                c.send(json.dumps({
                    "type": "learning",
                    "event": {"kind": "response", "concept_id": "neurons",
                              "question_id": f"neurons-{i}", "correct": False,
                              "rt_ms": 2200, "answer": 1, "item_difficulty": 0.0},
                }))
                time.sleep(0.25)
            time.sleep(0.5)

            assert s.difficulty.d < before, "six wrong answers must lower difficulty"
            assert s.tracer.state("neurons").theta < 0.0

            from neurobridge.education.events import EventLog
            events = list(EventLog.read(Path(s.out_dir) / "events.jsonl"))
            responses = [e for e in events if e.kind == "response"]
            assert len(responses) == 6
            assert responses[-1].neuro, "responses must carry the neural snapshot"
            assert "alpha" in responses[-1].neuro
            c.close()
        finally:
            s.stop()


def test_session_survives_a_client_disconnecting_mid_stream():
    port = free_port()
    with tempfile.TemporaryDirectory() as d:
        s = Session(config(port, d), source=SyntheticSource(seed=8))
        s.start()
        try:
            c = MiniClient("127.0.0.1", port)
            wait_for_clients(s.server)
            drain(c, "neuro")
            c.close()
            time.sleep(1.5)
            assert s.metrics.snapshot()["n_windows"] > 0
            c2 = MiniClient("127.0.0.1", port)
            wait_for_clients(s.server)
            assert drain(c2, "hello")[0]["type"] == "hello"
            c2.close()
        finally:
            s.stop()
