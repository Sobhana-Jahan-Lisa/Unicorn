"""Bluetooth-dropout repair: untouched when nothing dropped, removes the
frozen-hum error when something did, and streams identically to offline."""

import numpy as np

from neurobridge.process.dropouts import DropoutRepair, repair_dropouts

SF = 250.0


def _stream(seed: int, n: int = 5000) -> np.ndarray:
    """EEG-sized noise + 800 uV of 60 Hz hum + a 130 mV electrode offset."""
    rng = np.random.default_rng(seed)
    t = np.arange(n) / SF
    eeg = np.cumsum(rng.normal(0, 1, (8, n)), axis=1)
    eeg = 10 * (eeg - eeg.mean(axis=1, keepdims=True)) / eeg.std()
    hum = 800 * np.sin(2 * np.pi * 60 * t + rng.uniform(0, 2 * np.pi, (8, 1)))
    return eeg + hum + 130_000.0


def _drop(x: np.ndarray, starts, length: int) -> np.ndarray:
    y = x.copy()
    for s in starts:
        y[:, s:s + length] = y[:, s - 1:s]      # what a lost packet looks like
    return y


def test_a_stream_without_dropouts_passes_through_unchanged():
    x = _stream(0)
    assert np.array_equal(repair_dropouts(x, SF), x)


def test_repair_removes_most_of_the_frozen_hum_error():
    x = _stream(1)
    y = _drop(x, range(300, 4800, 400), 20)
    gaps = np.any(y != x, axis=0)
    r = repair_dropouts(y, SF)
    err_held = np.sqrt(np.mean((y - x)[:, gaps] ** 2))
    err_fixed = np.sqrt(np.mean((r - x)[:, gaps] ** 2))
    assert err_fixed < 0.1 * err_held, (err_held, err_fixed)
    assert np.array_equal(r[:, ~gaps], x[:, ~gaps])       # good samples untouched


def test_streaming_in_chunks_matches_the_whole_file():
    starts = range(300, 4800, 333)
    y = _drop(_stream(2), starts, 15)
    offline = repair_dropouts(y, SF)
    live = DropoutRepair(8, SF)
    online = np.concatenate([live(y[:, a:a + 17]) for a in range(0, y.shape[1], 17)],
                            axis=1)
    assert np.allclose(online, offline)
    assert live.n_repaired == 15 * len(starts)
