"""Streaming filter correctness -- the property most real-time code gets wrong."""

import numpy as np
import pytest
from scipy import signal as sps

from neurobridge.core.types import Epoch
from neurobridge.process.features import integrate_band, welch_psd
from neurobridge.process.filters import (
    AmplitudeReject, Detrend, Rereference, StreamFilter, SurfaceLaplacian,
)

SF = 250.0


def make_epoch(data, names=None):
    data = np.atleast_2d(data).astype(float)
    return Epoch(data=data, t_start=0.0, sfreq=SF,
                 ch_names=tuple(names or [f"ch{i}" for i in range(data.shape[0])]))


def test_chunked_filtering_equals_whole_signal_filtering():
    """The core claim: carrying filter state gives the same result as one pass."""
    rng = np.random.default_rng(0)
    x = rng.normal(0, 10, (4, 2000))

    whole = StreamFilter(SF, 4, 1.0, 40.0, notch=None)
    ref = whole(x)

    chunked = StreamFilter(SF, 4, 1.0, 40.0, notch=None)
    pieces, i = [], 0
    for n in [7, 63, 1, 250, 129, 400, 33]:
        pieces.append(chunked(x[:, i:i + n]))
        i += n
    got = np.hstack(pieces)
    assert np.allclose(ref[:, :got.shape[1]], got, atol=1e-9)


def test_stateless_per_chunk_filtering_would_differ():
    """Demonstrates the bug this design avoids, so the test has a point."""
    rng = np.random.default_rng(1)
    x = rng.normal(0, 10, (2, 1000))
    ref = StreamFilter(SF, 2, 1.0, 40.0, notch=None)(x)
    naive = np.hstack([
        StreamFilter(SF, 2, 1.0, 40.0, notch=None)(x[:, i:i + 100])
        for i in range(0, 1000, 100)
    ])
    assert not np.allclose(ref, naive, atol=1e-3)


def test_notch_removes_mains_but_keeps_alpha():
    t = np.arange(int(4 * SF)) / SF
    x = (10 * np.sin(2 * np.pi * 10 * t) + 30 * np.sin(2 * np.pi * 60 * t))[None, :]
    y = StreamFilter(SF, 1, 1.0, 90.0, notch=60.0)(x)

    f0, p0 = welch_psd(x, SF)
    f1, p1 = welch_psd(y[:, int(SF):], SF)          # skip the settling transient
    before = integrate_band(f0, p0, 58, 62)[0]
    after = integrate_band(f1, p1, 58, 62)[0]
    alpha_after = integrate_band(f1, p1, 8, 13)[0]
    assert after < before / 100
    assert alpha_after > 0.5 * (10.0**2 / 2)


def test_bandpass_attenuates_out_of_band():
    t = np.arange(int(6 * SF)) / SF
    x = (5 * np.sin(2 * np.pi * 0.2 * t) + 5 * np.sin(2 * np.pi * 10 * t))[None, :]
    y = StreamFilter(SF, 1, 1.0, 45.0, notch=None)(x)[:, int(2 * SF):]
    f, p = welch_psd(y, SF)
    assert integrate_band(f, p, 1.0, 3.0)[0] < integrate_band(f, p, 8, 13)[0] / 50


def test_group_delay_is_reported_and_positive():
    f = StreamFilter(SF, 4, 1.0, 45.0, notch=None)
    assert 0.0 < f.group_delay_s < 0.5


def test_filter_rejects_impossible_bands():
    with pytest.raises(ValueError, match="Nyquist"):
        StreamFilter(SF, 2, 1.0, 130.0)
    with pytest.raises(ValueError):
        StreamFilter(SF, 2, 40.0, 10.0)


def test_filter_priming_avoids_startup_transient():
    """A large DC offset must not produce a huge ringing transient."""
    x = np.full((2, 500), 500.0)
    y = StreamFilter(SF, 2, 1.0, 45.0, notch=None)(x)
    assert np.abs(y[:, :10]).max() < 50.0


def test_detrend_removes_linear_drift():
    t = np.arange(500)
    ep = make_epoch(np.vstack([t * 0.5 + 3.0, t * -0.2]))
    out = Detrend("linear")(ep)
    assert np.abs(out.data).max() < 1e-8


def test_average_reference_zeroes_the_mean_and_needs_enough_channels():
    rng = np.random.default_rng(2)
    ep = make_epoch(rng.normal(0, 1, (8, 200)))
    out = Rereference("average")(ep)
    assert np.allclose(out.data.mean(axis=0), 0, atol=1e-12)
    with pytest.raises(ValueError, match="4 channels"):
        Rereference("average")(make_epoch(rng.normal(0, 1, (2, 100))))


def test_laplacian_suppresses_a_spatially_uniform_source():
    """A signal common to all electrodes is exactly what a Laplacian removes."""
    rng = np.random.default_rng(3)
    common = rng.normal(0, 10, 400)
    names = ("Fz", "C3", "Cz", "C4", "Pz", "PO7", "Oz", "PO8")
    ep = make_epoch(np.tile(common, (8, 1)), names)
    out = SurfaceLaplacian()(ep)
    assert np.abs(out.data).max() < 1e-9


def test_amplitude_reject_flags_and_names_the_bad_channel():
    rng = np.random.default_rng(4)
    data = rng.normal(0, 5, (4, 250))
    data[2] += 400
    data[2, 100] = 900
    ep = make_epoch(data, ("a", "b", "c", "d"))
    out = AmplitudeReject(ptp_uv=150.0)(ep)
    assert out.meta["reject"] is True
    assert "c" in out.meta["reject_channels"]
