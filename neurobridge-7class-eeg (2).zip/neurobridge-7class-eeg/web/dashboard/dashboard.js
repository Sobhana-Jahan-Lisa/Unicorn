/* neurobridge web dashboard client.
 *
 * Talks to 15_web_dashboard.py over plain HTTP polling, not a WebSocket.
 * An earlier version used a WebSocket, matching the game client's own
 * transport -- but on the machine this was first deployed to, every
 * WebSocket upgrade handshake was corrupted somewhere between the browser
 * and Python (confirmed with two independent server implementations and a
 * non-browser WebSocket client, all rejected identically), while plain
 * HTTP GET/POST to the very same process never showed the problem. That
 * points at something on the OS network layer specifically inspecting
 * WebSocket-upgrade traffic. Since there's no reliable way for a page to
 * know in advance whether a given machine has that problem, this version
 * just never sends an `Upgrade: websocket` header: it polls
 * GET /api/state roughly every 150ms and posts commands to
 * POST /api/command -- both same-origin, ordinary requests.
 */

(function () {
  "use strict";

  const style = getComputedStyle(document.documentElement);
  const COLORS = {
    pen: style.getPropertyValue("--pen").trim() || "#2b4cc4",
    highlight: style.getPropertyValue("--highlight").trim() || "#f0e442",
    red: style.getPropertyValue("--red-pen").trim() || "#d6412b",
    green: style.getPropertyValue("--green-pen").trim() || "#1f7a5c",
    ink: style.getPropertyValue("--ink").trim() || "#16232a",
    pencil: style.getPropertyValue("--pencil").trim() || "#6b7c76",
  };
  const BAND_ORDER = ["delta", "theta", "alpha", "beta", "gamma"];
  const BAND_COLORS = {
    delta: "#6b4fbb", theta: "#3b82c4", alpha: COLORS.green,
    beta: "#d99a2b", gamma: COLORS.red,
  };

  const POLL_MS = 150;
  let currentView = "scope";
  let channels = [];
  let activeLabel = null;
  let helloSeen = false;
  let topoChannels = [];
  let topoPositions = [];
  // Microvolts between channel baselines on the fixed-scale traces, and the
  // latest per-channel usable flags used to colour their labels. Both come
  // from the backend (--scale and the quality message).
  let scaleUv = 50;
  let alphaBand = [8, 13];
  let chanQuality = null;

  // -- connection ------------------------------------------------------------

  function setLink(state, text) {
    const pill = document.getElementById("pill-link");
    pill.dataset.state = state;
    pill.textContent = text;
  }

  function send(cmd) {
    fetch("/api/command", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(cmd),
    }).catch(() => {});
  }

  async function pollOnce() {
    const resp = await fetch(`/api/state?view=${encodeURIComponent(currentView)}`, {
      cache: "no-store",
    });
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const snapshot = await resp.json();
    setLink("on", "dashboard link: online");
    for (const [type, payload] of Object.entries(snapshot)) {
      if (type === "hello" && helloSeen) continue;
      if (type === "hello") helloSeen = true;
      handle({ type, ...payload });
    }
  }

  function connect() {
    setLink("off", "dashboard link: connecting...");
    const tick = () => {
      pollOnce()
        .catch(() => setLink("off", "dashboard link: offline (retrying...)"))
        .finally(() => setTimeout(tick, POLL_MS));
    };
    tick();
  }

  // -- canvas helpers ----------------------------------------------------------

  // A canvas marked data-fit in the HTML takes its pixel size from its rendered
  // box, so the stylesheet and the window decide how big the plot is instead of
  // the width/height attributes. Those attributes only give a canvas an
  // intrinsic aspect ratio, and with `canvas { width: 100% }` that ratio, not
  // the layout, was setting the height: the scope's Live EEG panel came out
  // 196px tall -- 24px per channel for eight channels -- beside a 381px
  // spectrum in the same row, with the rest of its card left blank.
  //
  // Every draw helper below already works in cv.width/cv.height units, so
  // resizing the backing store is the whole change; none of them need to know.
  // The paired CSS rule gives each data-fit canvas an explicit height, which is
  // what makes this safe: the box size never depends on the backing-store size,
  // so resizing here cannot feed back into layout.
  //
  // A canvas on a hidden tab measures 0x0. It keeps its previous size and is
  // refitted by the first draw after its tab is shown, one poll later.
  function fitCanvas(cv) {
    if (!cv.hasAttribute("data-fit")) return;
    const rect = cv.getBoundingClientRect();
    const w = Math.round(rect.width);
    const h = Math.round(rect.height);
    if (w < 2 || h < 2) return;
    if (cv.width !== w) cv.width = w;
    if (cv.height !== h) cv.height = h;
  }

  function ctxOf(id) {
    const cv = document.getElementById(id);
    fitCanvas(cv);
    const ctx = cv.getContext("2d");
    ctx.clearRect(0, 0, cv.width, cv.height);
    return { cv, ctx };
  }

  // Green/red per channel, exactly as 06_live_scope.py colours its y-tick
  // labels. Grey until the first quality message arrives, so a channel is
  // never claimed to be good before anything has been measured.
  function channelColor(name) {
    if (!chanQuality) return COLORS.pencil;
    const i = chanQuality.channels.indexOf(name);
    if (i < 0) return COLORS.pencil;
    return chanQuality.usable[i] ? COLORS.green : COLORS.red;
  }

  // The 20 µV bar from 06_live_scope.py: without an absolute reference the
  // trace amplitude on screen means nothing.
  function drawScaleBar(ctx, cv, pxPerUv) {
    const h = 20 * pxPerUv;
    const x = 12, y1 = cv.height - 10, y0 = y1 - h;
    ctx.strokeStyle = COLORS.ink;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(x, y0);
    ctx.lineTo(x, y1);
    ctx.stroke();
    ctx.fillStyle = COLORS.ink;
    ctx.font = "10px monospace";
    ctx.fillText("20 µV", x + 5, (y0 + y1) / 2 + 3);
  }

  // opts.fixedScale draws at a constant microvolts-per-baseline-spacing with a
  // scale bar and quality-coloured labels -- the convention 06_live_scope.py
  // and 19_record_focus_states.py both argue for, and the one their tabs here
  // now use. Auto-scaling to the loudest sample on screen (the default below,
  // kept for the ICA panels, which compare two versions of the same window and
  // want them on one shared scale) lets a single railing electrode inflate the
  // scale for every channel and makes the good ones look artificially flat: a
  // real signal should look like a real signal, and a bad channel should look
  // bad rather than flatten its neighbours.
  function drawStacked(id, labels, rows, opts) {
    opts = opts || {};
    const { cv, ctx } = ctxOf(id);
    const n = Math.max(labels.length, 1);
    const bandH = cv.height / n;
    let scale;
    if (opts.fixedScale) {
      scale = bandH / Math.max(scaleUv, 1e-6);
    } else {
      let maxAbs = 1e-6;
      rows.forEach((r) => r.forEach((v) => { if (Math.abs(v) > maxAbs) maxAbs = Math.abs(v); }));
      scale = (bandH * 0.42) / maxAbs;
    }
    ctx.font = "11px monospace";
    labels.forEach((name, i) => {
      const row = rows[i] || [];
      if (!row.length) return;
      const cy = bandH * i + bandH / 2;
      const mean = row.reduce((a, b) => a + b, 0) / row.length;
      ctx.strokeStyle = COLORS.pen;
      ctx.lineWidth = 1;
      ctx.beginPath();
      row.forEach((v, x) => {
        const px = (x / (row.length - 1 || 1)) * cv.width;
        const py = cy - (v - mean) * scale;
        if (x === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
      });
      ctx.stroke();
      ctx.fillStyle = opts.fixedScale ? channelColor(name) : COLORS.pencil;
      ctx.fillText(name, 4, cy - bandH * 0.28);
    });
    if (opts.fixedScale) drawScaleBar(ctx, cv, scale);
  }

  // Like drawStacked, but each row gets its OWN vertical scale -- matching
  // 08_band_filters.py, which gives every band its own auto-scaled panel.
  // A shared scale (drawStacked's approach, right for a multi-channel trace
  // where one scale bar applies to all channels) would make beta/gamma look
  // flat next to delta, since their typical amplitudes differ by an order
  // of magnitude or more.
  function drawStackedIndependent(id, labels, rows, colors) {
    const { cv, ctx } = ctxOf(id);
    const n = Math.max(labels.length, 1);
    const bandH = cv.height / n;
    ctx.font = "11px monospace";
    labels.forEach((name, i) => {
      const row = rows[i] || [];
      if (!row.length) return;
      const cy = bandH * i + bandH / 2;
      const mean = row.reduce((a, b) => a + b, 0) / row.length;
      let maxAbs = 1e-6;
      row.forEach((v) => { const d = Math.abs(v - mean); if (d > maxAbs) maxAbs = d; });
      const scale = (bandH * 0.42) / maxAbs;
      ctx.strokeStyle = (colors && colors[name]) || COLORS.pen;
      ctx.lineWidth = 1;
      ctx.beginPath();
      row.forEach((v, x) => {
        const px = (x / (row.length - 1 || 1)) * cv.width;
        const py = cy - (v - mean) * scale;
        if (x === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
      });
      ctx.stroke();
      ctx.fillStyle = COLORS.pencil;
      ctx.fillText(name, 4, cy - bandH * 0.28);
    });
  }

  // neurobridge.viz.ChannelStackView, on a canvas: one lane per channel at a
  // fixed ±scale, every lane the same, no auto-scaling and no clipping -- a
  // value beyond the view simply leaves its lane. The Good/Bad badge and the
  // "outside ±scale / peak-to-peak" readout come from the backend, which
  // measures them on the full-resolution window rather than on the decimated
  // trace drawn here, so they stay exact.
  function drawChannelStack(id, msg) {
    const { cv, ctx } = ctxOf(id);
    const names = msg.channels || [];
    const n = Math.max(names.length, 1);
    const laneH = cv.height / n;
    const scale = msg.scale || 50;
    ctx.font = "11px monospace";
    names.forEach((name, i) => {
      const row = (msg.data && msg.data[i]) || [];
      const top = laneH * i;
      const cy = top + laneH / 2;
      const pxPerUv = (laneH * 0.5) / scale;

      ctx.strokeStyle = "#e3e7e6";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, top + laneH);
      ctx.lineTo(cv.width, top + laneH);
      ctx.stroke();
      ctx.setLineDash([2, 3]);
      ctx.beginPath();
      ctx.moveTo(0, cy);
      ctx.lineTo(cv.width, cy);
      ctx.stroke();
      ctx.setLineDash([]);

      if (row.length) {
        ctx.save();
        ctx.beginPath();
        ctx.rect(0, top, cv.width, laneH);
        ctx.clip();
        ctx.strokeStyle = "#007fa3";
        ctx.lineWidth = 0.9;
        ctx.beginPath();
        row.forEach((v, x) => {
          const px = (x / (row.length - 1 || 1)) * cv.width;
          const py = cy - v * pxPerUv;
          if (x === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
        });
        ctx.stroke();
        ctx.restore();
      }

      const badge = (msg.badges && msg.badges[i]) || { text: "…", color: "#9e9e9e" };
      ctx.font = "bold 10px monospace";
      const bw = ctx.measureText(badge.text).width + 10;
      ctx.fillStyle = badge.color;
      ctx.fillRect(4, top + 4, bw, 14);
      ctx.fillStyle = "#fff";
      ctx.fillText(badge.text, 9, top + 15);

      ctx.font = "11px monospace";
      ctx.fillStyle = COLORS.ink;
      ctx.fillText(`Ch${i + 1} ${name}`, 8 + bw, top + 15);

      if (msg.outside && msg.ptp) {
        const readout = `outside ±${scale} µV: ${msg.outside[i]}%  |  p-p ${msg.ptp[i]} µV`;
        ctx.font = "10px monospace";
        ctx.save();
        ctx.textAlign = "right";
        ctx.fillStyle = COLORS.pencil;
        ctx.fillText(readout, cv.width - 6, top + 15);
        ctx.restore();
      }
    });
    ctx.font = "10px monospace";
    ctx.fillStyle = COLORS.pencil;
    ctx.fillText(`${msg.seconds || 8}s before the latest received sample`, 6, cv.height - 4);
  }

  function drawLine(id, xs, ys, opts) {
    opts = opts || {};
    const { cv, ctx } = ctxOf(id);
    if (!xs.length) return;
    const pad = 28;
    const tx = (x) => (opts.logX ? Math.log10(Math.max(x, 1e-3)) : x);
    const ty = (y) => (opts.logY ? Math.log10(Math.max(y, 1e-9)) : y);
    const xs2 = xs.map(tx), ys2 = ys.map(ty);
    const xmin = Math.min(...xs2), xmax = Math.max(...xs2);
    const ymin = Math.min(...ys2), ymax = Math.max(...ys2);
    const sx = (v) => pad + ((v - xmin) / (xmax - xmin || 1)) * (cv.width - 2 * pad);
    const sy = (v) => cv.height - pad - ((v - ymin) / (ymax - ymin || 1)) * (cv.height - 2 * pad);
    // Shaded band behind the curve, drawn before it -- 06_live_scope.py's
    // gold alpha span. The point of the spectrum panel is watching a peak
    // rise out of the 1/f background in a named place; unmarked, the viewer
    // has to read the axis to know whether the bump is in the right one.
    if (opts.shade) {
      const x0 = sx(tx(opts.shade[0])), x1 = sx(tx(opts.shade[1]));
      ctx.fillStyle = "rgba(240, 196, 25, 0.28)";
      ctx.fillRect(x0, pad * 0.5, Math.max(x1 - x0, 1), cv.height - pad * 1.5);
      ctx.fillStyle = "#8a6d00";
      ctx.font = "10px monospace";
      ctx.save();
      ctx.textAlign = "center";
      ctx.fillText(opts.shadeLabel || "", (x0 + x1) / 2, pad * 0.5 + 12);
      ctx.restore();
    }
    ctx.strokeStyle = COLORS.pen;
    ctx.lineWidth = 1.3;
    ctx.beginPath();
    xs2.forEach((x, i) => {
      const px = sx(x), py = sy(ys2[i]);
      if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    });
    ctx.stroke();
    ctx.strokeStyle = COLORS.pencil;
    ctx.strokeRect(pad, pad * 0.5, cv.width - 2 * pad, cv.height - pad * 1.5);
  }

  function wrapLabel(ctx, text, maxWidth) {
    const words = text.split(" ");
    const lines = [];
    let cur = "";
    for (const w of words) {
      const trial = cur ? cur + " " + w : w;
      if (cur && ctx.measureText(trial).width > maxWidth) {
        lines.push(cur);
        cur = w;
      } else {
        cur = trial;
      }
    }
    if (cur) lines.push(cur);
    return lines;
  }

  function drawBars(id, labels, values, colorFn) {
    const { cv, ctx } = ctxOf(id);
    const pad = 36;
    const n = Math.max(labels.length, 1);
    const bw = (cv.width - 2 * pad) / n;
    const maxV = Math.max(...values, 1e-6) * 1.25;
    ctx.font = "10px monospace";
    labels.forEach((lab, i) => {
      const v = values[i] || 0;
      const h = (v / maxV) * (cv.height - 2 * pad);
      const x = pad + i * bw;
      ctx.fillStyle = colorFn ? colorFn(lab, i) : COLORS.pen;
      ctx.fillRect(x + bw * 0.15, cv.height - pad - h, bw * 0.7, h);
      ctx.fillStyle = COLORS.ink;
      ctx.save();
      ctx.textAlign = "center";
      const lines = wrapLabel(ctx, lab, bw - 4);
      lines.forEach((line, li) => ctx.fillText(line, x + bw * 0.5, cv.height - pad + 12 + li * 11));
      ctx.restore();
      ctx.fillText(v.toFixed(2), x + bw * 0.5 - 10, cv.height - pad - h - 4);
    });
  }

  function drawMatrix(id, matrix, labels) {
    const { cv, ctx } = ctxOf(id);
    const n = labels.length;
    if (!n) return;
    const pad = 56;
    const cell = Math.min(cv.width - pad, cv.height - pad) / n;
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) {
        const v = matrix[i][j];
        const x = pad + j * cell, y = pad + i * cell;
        const c = Math.round(255 * (1 - v));
        ctx.fillStyle = `rgb(${c},${c},255)`;
        ctx.fillRect(x, y, cell, cell);
        ctx.strokeStyle = "#fff";
        ctx.strokeRect(x, y, cell, cell);
        if (cell > 26) {
          ctx.fillStyle = v > 0.55 ? "#fff" : "#000";
          ctx.font = "10px monospace";
          ctx.fillText(v.toFixed(2), x + cell * 0.15, y + cell * 0.6);
        }
      }
      ctx.fillStyle = COLORS.ink;
      ctx.font = "10px monospace";
      ctx.fillText(labels[i], 4, pad + i * cell + cell * 0.6);
    }
    for (let j = 0; j < n; j++) {
      ctx.save();
      ctx.translate(pad + j * cell + cell * 0.5, pad - 8);
      ctx.rotate(-Math.PI / 4);
      ctx.fillStyle = COLORS.ink;
      ctx.font = "10px monospace";
      ctx.fillText(labels[j], 0, 0);
      ctx.restore();
    }
  }

  function drawFocus(data) {
    const { cv, ctx } = ctxOf("cv-focus");
    const cx = cv.width / 2, cy = cv.height / 2, R = Math.min(cx, cy) - 24;
    ctx.strokeStyle = "#ddd";
    ctx.lineWidth = 16;
    ctx.beginPath();
    ctx.arc(cx, cy, R, 0, 2 * Math.PI);
    ctx.stroke();

    if (data.phase === "calibrating") {
      ctx.fillStyle = "#bbb";
      ctx.beginPath();
      ctx.arc(cx, cy, R * 0.42, 0, 2 * Math.PI);
      ctx.fill();
      ctx.fillStyle = COLORS.ink;
      ctx.font = "14px monospace";
      ctx.textAlign = "center";
      ctx.fillText(`settling in... ${data.remaining}s`, cx, cy + R + 20);
      return;
    }

    const frac = Math.max(0, Math.min(1, (data.charge || 0) / (data.hold || 1)));
    ctx.strokeStyle = data.cleared ? "#c9a800" : "#4c8bf5";
    ctx.lineWidth = 16;
    ctx.beginPath();
    ctx.arc(cx, cy, R, -Math.PI / 2, -Math.PI / 2 + frac * 2 * Math.PI);
    ctx.stroke();

    const g = Math.max(0, Math.min(1, data.focus || 0));
    const green = [40, 180, 90], gray = [200, 200, 200];
    const mix = green.map((c, i) => Math.round(gray[i] + (c - gray[i]) * g));
    ctx.fillStyle = `rgb(${mix.join(",")})`;
    ctx.beginPath();
    ctx.arc(cx, cy, R * 0.42, 0, 2 * Math.PI);
    ctx.fill();

    if (data.cleared) {
      ctx.fillStyle = COLORS.ink;
      ctx.font = "bold 16px monospace";
      ctx.textAlign = "center";
      ctx.fillText("ROUND CLEARED", cx, cy + R + 20);
    }
  }

  // Diverging blue -> pale yellow -> red, matching the RdYlBu_r colormap the
  // matplotlib topomap script (24_live_topomap.py) uses, so the two agree.
  const TOPOMAP_STOPS = [
    [0.00, [49, 54, 149]], [0.25, [69, 117, 180]], [0.50, [255, 255, 191]],
    [0.75, [252, 141, 89]], [1.00, [165, 0, 38]],
  ];
  function topomapColor(t) {
    for (let i = 0; i < TOPOMAP_STOPS.length - 1; i++) {
      const [t0, c0] = TOPOMAP_STOPS[i], [t1, c1] = TOPOMAP_STOPS[i + 1];
      if (t <= t1) {
        const f = (t - t0) / (t1 - t0 || 1);
        return c0.map((v, k) => Math.round(v + (c1[k] - v) * f));
      }
    }
    return TOPOMAP_STOPS[TOPOMAP_STOPS.length - 1][1];
  }

  // Inverse-distance-weighted interpolation over a head-shaped grid -- the
  // browser-side counterpart of 24_live_topomap.py's SciPy cubic
  // interpolation. IDW instead of cubic because it needs no library and is
  // cheap enough to redraw every poll; both are approximations for a quick
  // visual read, not a spherical-spline head model.
  function drawTopomap(id, names, positions, values) {
    const { cv, ctx } = ctxOf(id);
    if (!positions.length || !values.length) return;
    // Matches 24_live_topomap.py's head_radius: big enough that every
    // electrode (PO7/PO8 sit furthest out on an 8-channel Unicorn montage)
    // falls inside the drawn head, not just the fixed 10-20 "ideal" radius.
    const maxDist = Math.max(...positions.map(([x, y]) => Math.hypot(x, y)));
    const headRadius = Math.max(1.05, maxDist + 0.15);
    const size = Math.min(cv.width, cv.height) - 40;
    const cx = cv.width / 2, cy = cv.height / 2;
    const scale = (size / 2) / headRadius;
    const res = 64;
    const img = ctx.createImageData(res, res);
    let vmin = Math.min(...values), vmax = Math.max(...values);
    if (vmax - vmin < 1e-6) vmax = vmin + 1e-6;
    for (let iy = 0; iy < res; iy++) {
      const y = headRadius - (iy / (res - 1)) * 2 * headRadius;
      for (let ix = 0; ix < res; ix++) {
        const x = -headRadius + (ix / (res - 1)) * 2 * headRadius;
        const idx = (iy * res + ix) * 4;
        if (x * x + y * y > headRadius * headRadius) continue; // leave transparent
        let num = 0, den = 0, exact = null;
        for (let k = 0; k < positions.length; k++) {
          const dx = x - positions[k][0], dy = y - positions[k][1];
          const d2 = dx * dx + dy * dy;
          if (d2 < 1e-6) { exact = values[k]; break; }
          const w = 1 / d2;
          num += w * values[k];
          den += w;
        }
        const v = exact !== null ? exact : (den > 0 ? num / den : 0);
        const t = Math.max(0, Math.min(1, (v - vmin) / (vmax - vmin)));
        const [r, g, b] = topomapColor(t);
        img.data[idx] = r; img.data[idx + 1] = g; img.data[idx + 2] = b; img.data[idx + 3] = 255;
      }
    }
    const off = document.createElement("canvas");
    off.width = res; off.height = res;
    off.getContext("2d").putImageData(img, 0, 0);
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(off, cx - size / 2, cy - size / 2, size, size);

    ctx.strokeStyle = COLORS.ink;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(cx, cy, size / 2, 0, 2 * Math.PI);
    ctx.stroke();
    ctx.beginPath(); // nose
    ctx.moveTo(cx - size * 0.04, cy - size / 2);
    ctx.lineTo(cx, cy - size / 2 - size * 0.08);
    ctx.lineTo(cx + size * 0.04, cy - size / 2);
    ctx.stroke();
    [-1, 1].forEach((side) => { // ears
      ctx.beginPath();
      ctx.ellipse(cx + side * size / 2, cy, size * 0.03, size * 0.08, 0, 0, 2 * Math.PI);
      ctx.stroke();
    });

    ctx.fillStyle = COLORS.ink;
    ctx.font = "10px monospace";
    ctx.textAlign = "center";
    positions.forEach((p, i) => {
      const px = cx + p[0] * scale, py = cy - p[1] * scale;
      ctx.beginPath();
      ctx.arc(px, py, 3, 0, 2 * Math.PI);
      ctx.fillStyle = "#000";
      ctx.fill();
      ctx.fillStyle = COLORS.ink;
      ctx.fillText(names[i], px, py - 8);
    });
    ctx.textAlign = "left";
  }

  // -- channel/band selectors -------------------------------------------------

  function populateChannelSelects() {
    ["sel-channel-scope", "sel-channel-bands", "sel-channel-freq"].forEach((id) => {
      const sel = document.getElementById(id);
      sel.innerHTML = "";
      channels.forEach((name) => {
        const opt = document.createElement("option");
        opt.value = name;
        opt.textContent = name;
        sel.appendChild(opt);
      });
      sel.onchange = () => {
        ["sel-channel-scope", "sel-channel-bands", "sel-channel-freq"].forEach((id2) => {
          document.getElementById(id2).value = sel.value;
        });
        send({ cmd: "set_channel", channel: sel.value });
      };
    });
  }

  // -- message dispatch --------------------------------------------------------

  function handle(msg) {
    switch (msg.type) {
      case "hello":
        channels = msg.channels || [];
        if (msg.scale_uv) scaleUv = msg.scale_uv;
        if (msg.alpha_band) alphaBand = msg.alpha_band;
        document.getElementById("device-line").textContent =
          `${msg.device} @ ${msg.sfreq} Hz  —  ${channels.join(", ")}`;
        // Say where the trace comes from, always. A ReplaySource loops its file
        // back to sample 0 when it ends, so "the trace is moving" is not
        // evidence that anything is connected to a person.
        if (msg.source) {
          const band = document.getElementById("source-banner");
          if (msg.live === false) {
            band.hidden = false;
            band.textContent =
              `SIMULATED DATA — ${msg.source}. This is not a live brain signal; `
              + `a replayed recording loops back to its start when it ends.`;
          } else {
            band.hidden = true;
            document.getElementById("device-line").textContent +=
              `  —  live (${msg.source})`;
          }
        }
        populateChannelSelects();
        // The backend already selected the posterior channel (06_live_scope.py's
        // default); match the selects to it so the control agrees with what is
        // actually being plotted.
        if (msg.default_channel && channels.includes(msg.default_channel)) {
          ["sel-channel-scope", "sel-channel-bands", "sel-channel-freq"].forEach((id) => {
            document.getElementById(id).value = msg.default_channel;
          });
        }
        topoChannels = (msg.topomap && msg.topomap.channels) || [];
        topoPositions = (msg.topomap && msg.topomap.positions) || [];
        document.getElementById("topomap-note").textContent =
          topoPositions.length < 3
            ? "fewer than 3 channels have a resolvable 10-20 scalp position"
            : "";
        break;

      case "trace":
        // The scope and focus-recording traces mirror 06_live_scope.py and
        // 19_record_focus_states.py, so they use those scripts' fixed
        // microvolt scale; the generic record tab (13_record_and_label.py)
        // is left on the auto-scale it has always used.
        drawStacked("cv-trace", msg.channels, msg.data, { fixedScale: true });
        if (document.getElementById("cv-record-trace")) {
          drawStacked("cv-record-trace", msg.channels, msg.data);
        }
        if (document.getElementById("cv-focus-rec-trace")) {
          drawStacked("cv-focus-rec-trace", msg.channels, msg.data, { fixedScale: true });
        }
        break;

      case "quality": {
        // Kept for the fixed-scale traces to colour their channel labels with,
        // the way 06_live_scope.py colours its y-tick labels.
        if (msg.channels && msg.usable) {
          chanQuality = { channels: msg.channels, usable: msg.usable };
        }
        const bad = msg.n_usable < msg.n_channels;
        let text = `signal ${msg.mean_score.toFixed(2)}  ${msg.n_usable}/${msg.n_channels} usable`;
        if (bad && msg.advice && msg.advice.length) {
          // Group by message text (advice strings are "Channel: message") so
          // "same problem on every channel" shows once, not once per channel.
          const groups = new Map();
          msg.advice.forEach((a) => {
            const i = a.indexOf(": ");
            const channel = i >= 0 ? a.slice(0, i) : "?";
            const message = i >= 0 ? a.slice(i + 2) : a;
            if (!groups.has(message)) groups.set(message, []);
            groups.get(message).push(channel);
          });
          const parts = [...groups.entries()].map(([message, chans]) =>
            chans.length === msg.n_channels ? message : `${chans.join(",")}: ${message}`
          );
          text += "   |   " + parts.join("   |   ");
        }
        // Same threshold and wording as 06/19: below 1% the repair is
        // invisible, above it the amplitude metrics are already affected.
        if (msg.held_fraction >= 0.01) {
          text += `   |   Bluetooth: ${Math.round(100 * msg.held_fraction)}% of samples lost`;
        }
        const pill = document.getElementById("pill-quality");
        pill.dataset.state = bad ? "bad" : "on";
        pill.textContent = `signal ${msg.mean_score.toFixed(2)}  ${msg.n_usable}/${msg.n_channels} usable`;
        document.querySelectorAll("[data-quality]").forEach((el) => {
          el.dataset.state = bad ? "bad" : "on";
          el.textContent = text;
        });
        break;
      }

      case "scope": {
        drawLine("cv-psd", msg.psd_freqs, msg.psd_values,
          { logX: true, logY: true, shade: alphaBand, shadeLabel: "alpha" });
        drawBars("cv-rp", BAND_ORDER, BAND_ORDER.map((b) => msg.relative_power[b] || 0),
          (b) => BAND_COLORS[b]);
        const rpCh = document.getElementById("rp-channel");
        if (rpCh) rpCh.textContent = msg.channel || "";
        break;
      }

      case "bands": {
        const rows = BAND_ORDER.map((b) => (msg.series && msg.series[b]) || []);
        drawStackedIndependent("cv-bands", BAND_ORDER, rows, BAND_COLORS);
        break;
      }

      case "ica": {
        const status = document.getElementById("ica-status");
        const liveBadge = document.getElementById("live-classification");
        if (msg.error) {
          if (status) status.textContent = `ICA error: ${msg.error}`;
          if (liveBadge) { liveBadge.textContent = `error: ${msg.error}`; liveBadge.dataset.state = ""; }
          break;
        }
        if (document.getElementById("cv-ica-raw")) drawStacked("cv-ica-raw", msg.channels, msg.raw);
        if (msg.rejected) {
          if (status) status.textContent = `window rejected: amplitude too high `
            + `(${msg.n_rejected}/${msg.n_windows} rejected)`;
        } else if (document.getElementById("cv-ica-clean")) {
          drawStacked("cv-ica-clean", msg.channels, msg.cleaned);
          const label = msg.flagged.length
            ? msg.flagged.map((f) => `IC${f.component} ${f.reason}`).join(", ")
            : "none flagged";
          if (status) status.textContent = `components removed: ${label}`;
        }
        if (liveBadge) {
          liveBadge.textContent = msg.rejected ? "amplitude too high" : `detected: ${msg.live_label}`;
          liveBadge.dataset.state = msg.rejected ? "artifact"
            : (msg.live_label === "clean" ? "clean" : "artifact");
        }
        break;
      }

      case "time_features":
        drawBars("cv-amp", msg.channels, msg.amplitude);
        drawBars("cv-mad", msg.channels, msg.mad);
        drawBars("cv-zcr", msg.channels, msg.zcr);
        break;

      case "freq_features": {
        const hist = msg.entropy_history.map((v) => (v === null ? NaN : v));
        const xs = hist.map((_, i) => i);
        drawLine("cv-entropy", xs, hist.map((v) => (isNaN(v) ? 0 : v)));
        break;
      }

      case "focus":
        drawFocus(msg);
        document.getElementById("stat-round").textContent = msg.round ?? "—";
        document.getElementById("stat-threshold").textContent =
          msg.threshold !== undefined ? msg.threshold.toFixed(2) : "—";
        document.getElementById("stat-focus").textContent =
          msg.focus !== undefined ? msg.focus.toFixed(2) : "calibrating";
        break;

      case "sync":
        drawMatrix("cv-coh", msg.coherence, msg.channels);
        drawMatrix("cv-plv", msg.plv, msg.channels);
        break;

      case "topomap":
        drawTopomap("cv-topomap", topoChannels, topoPositions, msg.power || []);
        break;

      case "record_status": {
        activeLabel = msg.active_label;
        const badge = document.getElementById("rec-status");
        badge.dataset.state = msg.recording ? "on" : "off";
        badge.textContent = msg.recording
          ? `● recording -> ${msg.path} (${msg.elapsed}s)`
          : "not recording";
        document.getElementById("rec-spans").textContent =
          `${msg.n_spans} labelled span(s) so far` +
          (activeLabel ? `  |  active: ${activeLabel}` : "");
        const saved = document.getElementById("rec-saved");
        if (saved) {
          saved.textContent = msg.last_saved
            ? `last saved: ${msg.last_saved.path} (${msg.last_saved.n_samples} samples, `
              + `${msg.last_saved.n_spans} span(s))`
            : "";
        }
        document.querySelectorAll("#view-record [data-label]").forEach((btn) => {
          btn.classList.toggle("active", btn.dataset.label === activeLabel);
        });
        break;
      }

      case "focus_record_status": {
        const badge = document.getElementById("focus-rec-status");
        badge.dataset.state = msg.recording ? "on" : "off";
        badge.textContent = msg.recording
          ? `● recording -> ${msg.path} (${msg.elapsed}s)  session ${msg.session}`
          : "not recording";
        document.getElementById("focus-rec-error").textContent = msg.error || "";
        document.getElementById("focus-rec-spans").textContent =
          `${msg.n_spans} labelled span(s) so far` +
          (msg.active_label ? `  |  active: ${msg.active_label}` : "");
        const saved = document.getElementById("focus-rec-saved");
        if (saved) {
          saved.textContent = msg.last_saved
            ? `last saved: ${msg.last_saved.path} (${msg.last_saved.n_samples} samples, `
              + `${msg.last_saved.n_spans} span(s))`
            : "";
        }
        document.querySelectorAll("#view-record_focus [data-focus-label]").forEach((btn) => {
          btn.classList.toggle("active", btn.dataset.focusLabel === msg.active_label);
        });
        break;
      }

      case "four_trace": {
        drawChannelStack("cv-four-trace", msg);
        const head = document.getElementById("four-headline");
        if (head) head.textContent = msg.headline || "";
        const st = document.getElementById("four-status");
        if (st) {
          st.dataset.state = msg.stale ? "bad" : "on";
          st.textContent = msg.status || "";
        }
        break;
      }

      case "four_status": {
        const badge = document.getElementById("four-rec-status");
        badge.dataset.state = msg.recording ? "on" : "off";
        badge.textContent = msg.recording
          ? `● recording -> ${msg.path} (${msg.saved_seconds}s saved)`
            + (msg.truncated ? "  CAP REACHED, no longer recording" : "")
          : "not recording";
        document.getElementById("four-note").textContent = msg.note || "";
        const active = document.getElementById("four-active");
        active.textContent = msg.active_label
          ? `●  ${msg.active_label}   ${msg.active_seconds}s   (click it again to end)`
          : "no active label";
        active.style.color = msg.active_label ? COLORS.red : "";
        // Spans per class, as 33 prints them: an unbalanced set is easier to
        // fix while you are still wearing the headset than afterwards.
        document.getElementById("four-counts").textContent =
          "spans so far:   " + (msg.counts || [])
            .map((c) => `${c.short} ${c.n} (${c.seconds}s)`).join("   ");
        const saved = document.getElementById("four-saved");
        if (msg.last_saved) {
          const ls = msg.last_saved;
          let text = `last saved: ${ls.path} (${ls.n_samples} samples, ${ls.n_spans} span(s))`
            + `  |  csv: ${ls.csv}`;
          if (ls.problems && ls.problems.length) {
            text += "   |   " + ls.problems.join("; ");
          }
          saved.textContent = text;
        } else {
          saved.textContent = "";
        }
        document.querySelectorAll("#view-record_four [data-four-label]").forEach((btn) => {
          btn.classList.toggle("active", btn.dataset.fourLabel === msg.active_label);
        });
        break;
      }

      case "train_status": {
        const badge = document.getElementById("train-status-badge");
        badge.dataset.state = msg.status === "running" ? "on" : "off";
        badge.textContent = msg.status;
        document.getElementById("btn-focus-train").disabled = msg.status === "running";
        const log = document.getElementById("train-log");
        log.textContent = (msg.log || []).join("\n");
        log.scrollTop = log.scrollHeight;
        break;
      }

      case "clf_status": {
        const badge = document.getElementById("clf-status-badge");
        const err = document.getElementById("clf-error");
        if (msg.loaded) {
          badge.dataset.state = "on";
          badge.textContent = `${msg.model_name} (${(msg.classes || []).join(", ")})`;
          err.textContent = "";
        } else {
          badge.dataset.state = "off";
          badge.textContent = "no model loaded";
          err.textContent = msg.error || "";
        }
        break;
      }

      case "clf_result": {
        const note = document.getElementById("clf-artifact-note");
        if (!note) break;
        if (msg.phase === "calibrating") {
          note.textContent = `calibrating... ${msg.remaining}s left`;
          drawBars("cv-clf-probs", [], []);
        } else if (msg.phase === "predicting") {
          const classes = Object.keys(msg.probabilities || {});
          const values = classes.map((c) => msg.probabilities[c]);
          drawBars("cv-clf-probs", classes, values,
            (c) => (c === msg.prediction ? COLORS.green : COLORS.pen));
          note.textContent = `predicted: ${msg.prediction}   |   ${msg.artifact_note}`;
        } else {
          note.textContent = "";
          drawBars("cv-clf-probs", [], []);
        }
        break;
      }

      case "validate_result": {
        const note = document.getElementById("validate-note");
        const table = document.getElementById("validate-table");
        if (msg.error) {
          note.textContent = `error: ${msg.error}`;
          table.style.display = "none";
          break;
        }
        note.textContent = `results for ${msg.path}`;
        const tbody = table.querySelector("tbody");
        tbody.innerHTML = "";
        msg.rows.forEach((r) => {
          const tr = document.createElement("tr");
          const pct = r.total ? Math.round((100 * r.flagged) / r.total) : 0;
          tr.innerHTML = `<td>${r.label}</td><td>${r.flagged}</td><td>${r.total}</td><td>${pct}%</td>`;
          tbody.appendChild(tr);
        });
        table.style.display = "";
        break;
      }
    }
  }

  // -- UI wiring ----------------------------------------------------------------

  document.querySelectorAll("#tabs button").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll("#tabs button").forEach((b) => b.classList.remove("active"));
      document.querySelectorAll(".view").forEach((v) => v.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(`view-${btn.dataset.view}`).classList.add("active");
      currentView = btn.dataset.view;
    });
  });

  document.getElementById("sel-band-sync").addEventListener("change", (e) => {
    send({ cmd: "set_band", band: e.target.value });
  });
  document.getElementById("sel-band-topomap").addEventListener("change", (e) => {
    send({ cmd: "set_topo_band", band: e.target.value });
  });

  document.getElementById("btn-start-rec").addEventListener("click", () => {
    send({ cmd: "start_recording" });
  });
  document.getElementById("btn-stop-rec").addEventListener("click", () => {
    send({ cmd: "stop_recording" });
  });
  document.querySelectorAll("#view-record [data-label]").forEach((btn) => {
    btn.addEventListener("click", () => send({ cmd: "label", label: btn.dataset.label }));
  });

  document.getElementById("btn-validate").addEventListener("click", () => {
    const path = document.getElementById("validate-path").value.trim();
    if (!path) return;
    document.getElementById("validate-note").textContent = "running...";
    send({ cmd: "validate", path });
  });

  document.getElementById("btn-focus-start-rec").addEventListener("click", () => {
    const participant = document.getElementById("focus-participant").value.trim();
    if (!participant) return;
    send({ cmd: "focus_start_recording", participant });
  });
  document.getElementById("btn-focus-stop-rec").addEventListener("click", () => {
    send({ cmd: "focus_stop_recording" });
  });
  document.querySelectorAll("#view-record_focus [data-focus-label]").forEach((btn) => {
    btn.addEventListener("click", () => send({ cmd: "focus_label", label: btn.dataset.focusLabel }));
  });

  document.getElementById("btn-four-start-rec").addEventListener("click", () => {
    const participant = document.getElementById("four-participant").value.trim();
    if (!participant) return;
    send({ cmd: "four_start_recording", participant });
  });
  document.getElementById("btn-four-stop-rec").addEventListener("click", () => {
    send({ cmd: "four_stop_recording" });
  });
  document.querySelectorAll("#view-record_four [data-four-label]").forEach((btn) => {
    btn.addEventListener("click", () => send({ cmd: "four_label", label: btn.dataset.fourLabel }));
  });

  document.getElementById("btn-focus-train").addEventListener("click", () => {
    const sessionsRoot = document.getElementById("train-sessions-root").value.trim();
    const out = document.getElementById("train-out").value.trim();
    const cmd = { cmd: "focus_train" };
    if (sessionsRoot) cmd.sessions_root = sessionsRoot;
    if (out) cmd.out = out;
    send(cmd);
  });

  document.getElementById("btn-clf-load").addEventListener("click", () => {
    const path = document.getElementById("clf-model-path").value.trim();
    const cmd = { cmd: "clf_load" };
    if (path) cmd.path = path;
    send(cmd);
  });
  document.getElementById("btn-clf-stop").addEventListener("click", () => {
    send({ cmd: "clf_stop" });
  });

  connect();
})();
